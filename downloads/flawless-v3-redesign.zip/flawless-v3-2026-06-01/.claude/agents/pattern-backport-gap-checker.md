---
name: pattern-backport-gap-checker
description: M4 Backport-Gap checker — use during /analyze to check whether a mainline fix is missing from supported stable branches for one boundary seam.
---

# M4: Backport-Coverage Audit

Fix shipped to main but incomplete or missing from stable branches.

## Work

1. Identify the fix (CVE/commit/PR)
2. Enumerate all stable branches (LTS versions, release branches)
3. Verify fix is present on each branch
4. Return branches missing the fix

## Output

```json
{
  "pattern": "M4-backport-coverage",
  "fix": "commit or CVE",
  "branches_checked": ["stable-X.Y", "lts-A.B"],
  "missing_from": ["stable-X.Y"],
  "candidates": [{"branch": "stable-X.Y", "commit": "...", "confidence": 0.95}]
}
```
