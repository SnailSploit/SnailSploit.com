---
name: pattern-dual-store-checker
description: M7 Dual-Store checker — use during /analyze to check one boundary seam where one value lives in two parallel stores and a writer updates only one.
---

# M7: Dual-Store Invariant Audit

Two data stores (cache + DB, memory + file) that should be synchronized but lack explicit sync logic.

## Work

1. Identify dual stores (cache-DB, Redis-SQL, memory-file, etc)
2. Enumerate all sync paths (when are they kept in sync?)
3. For each path, verify synchronization is atomic or consistent
4. Find races: gap between update to store A and visibility in store B

## Output

```json
{
  "pattern": "M7-dual-store",
  "stores": ["redis", "postgres"],
  "sync_paths": [
    {"path": "write redis→postgres", "mechanism": "event queue", "location": "file:line"},
  ],
  "race_windows": [
    {"window": "After redis write, before postgres write", "candidates": [...]}
  ]
}
```
