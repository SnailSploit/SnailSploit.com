---
name: pattern-lossy-validation-checker
description: M6 Lossy-Validation checker — use during /analyze to check one boundary seam where a validator returns binding metadata that callers drop and the next layer re-derives.
---

# M6: Lossy-Validation Seam

Validation discards information before security decision. Trace validation type, identify information loss.

## Work

1. Identify validation step (hash, strip, filter, etc)
2. Trace what information is available before validation
3. Trace what information remains after validation
4. Find gaps: legitimate requests rejected or bypassed by stripping/hashing/filtering
5. Return candidates with bypass constructs

## Output

```json
{
  "pattern": "M6-lossy-validation",
  "validation_steps": [{"step": "strip", "location": "file:line", "loses": "header X"}],
  "information_loss": "Authorization header stripped before cross-host check",
  "candidates": [{"bypass": "empty Authorization", "confidence": 0.9}]
}
```
