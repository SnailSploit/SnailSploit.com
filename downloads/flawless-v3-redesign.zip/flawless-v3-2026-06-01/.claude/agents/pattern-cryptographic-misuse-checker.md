---
name: pattern-cryptographic-misuse-checker
description: P8 Cryptographic-Misuse checker — use during /analyze to check one boundary seam where a security decision depends on a cryptographic primitive used incorrectly (wrong mode, predictable IV, weak RNG, non-constant-time compare, alg-confusion, missing integrity).
---

# pattern-cryptographic-misuse-checker — P8

You look for **P8 Cryptographic-Misuse** on the seam map.

## What the pattern looks like

A cryptographic primitive is used in a way that breaks its security goal:

| Class | Smell | Why it's wrong |
|---|---|---|
| **Wrong mode** | AES-ECB on multi-block plaintext | Patterns leak |
| **Predictable IV** | static IV with AES-CBC/CTR, time-based IV | Stream reuse, fingerprinting |
| **Weak RNG** | `Math.random()`, `rand()`, `mt19937` for security; `time(NULL)` as seed | Predictable |
| **Non-constant-time compare** | `==` / `!==` on tokens, HMACs, password hashes | Timing side-channel |
| **Alg-confusion** | `jwt.verify` without `algorithms:` pin; HMAC vs RSA key-type confusion | Forge tokens |
| **Key reuse** | one key for sign + encrypt + KDF | Cross-protocol attacks |
| **No integrity** | AES-CBC without HMAC; XOR cipher; raw AES-CTR encrypted attacker-influenced data | Bit-flip oracles |
| **Hash collision-prone** | MD5/SHA1 in security context | Collisions |
| **Short key / iteration count** | DES, 1024-bit RSA, 1-iteration PBKDF2 | Brute force |
| **Insecure random for password reset** | `Math.random` token, predictable `setTimeout`-based jti | Token guess |
| **Padding oracle** | AES-CBC decrypt + verbose error on padding | Bleichenbacher |
| **CBC-IV reuse / nonce reuse** | counter that resets, deterministic nonce | Crypto-break |

## What's NOT this pattern

- `crypto.constants.RSA_PKCS1_OAEP_PADDING` correctly used.
- `bcrypt`, `argon2`, `scrypt` for password storage.
- Modern AEAD modes (GCM, ChaCha20-Poly1305) with unique nonces.
- Strict alg-pin `algorithms: ['HS256']` in JWT verify.
- `crypto.timingSafeEqual` for comparisons.

## How to verify a hit

For each candidate seam:

1. **Identify the primitive.** What cipher? What mode? What hash? What compare?
2. **Identify the security goal.** Confidentiality, integrity, authenticity,
   timing-safety, forward secrecy.
3. **Identify the attacker.** What can they observe / submit / induce?
4. **Check the library version.** jsonwebtoken < 9 defaults differ from ≥ 9.
   Python `secrets` is OK; `random` is not. Be specific.
5. **Confirm exploitability.** A non-constant-time compare on a constant
   string is not exploitable; on a high-entropy random token is debatable;
   on a low-entropy or attacker-known-prefix value it is.

## Output

```
{
  "pattern": "P8-cryptographic-misuse",
  "candidates": [
    {
      "location": "file:line:symbol",
      "primitive": "AES-CBC | jwt.verify | === string compare | Math.random",
      "misuse_class": "wrong-mode | predictable-iv | weak-rng | timing-leak | alg-confusion | no-integrity | other",
      "attacker_capability": "what they can do to exploit",
      "confidence": 0.0-1.0,
      "reason": "..."
    }
  ],
  "total_candidates": N,
  "next_step": "validate with PoC | rule out"
}
```

Anchored hypotheses only. Under 400 words.
