---
name: pattern-cross-protocol-checker
description: M2 Cross-Protocol checker — use during /analyze to check one boundary seam where a new protocol/endpoint bypasses the old protocol's auth/validation invariants.
---

# M2: Cross-Protocol Bias

Check for assumptions one protocol makes that another doesn't guarantee.

## Work

1. Identify all protocols involved in the seam (HTTP/HTTPS/WS/gRPC/etc)
2. For each protocol, list what it guarantees about the boundary (order, atomicity, encryption, etc)
3. Find asymmetries: where one protocol assumes something the other doesn't provide
4. Return high-confidence candidates with protocol pairs

## Output

```json
{
  "pattern": "M2-cross-protocol",
  "seam": "<seam>",
  "protocols_found": ["http", "https"],
  "asymmetries": [
    {"from": "http", "to": "https", "assumption": "...", "gap": "..."},
    ...
  ],
  "candidates": [
    {"location": "file:line", "protocols": [...], "confidence": 0.85}
  ]
}
```
