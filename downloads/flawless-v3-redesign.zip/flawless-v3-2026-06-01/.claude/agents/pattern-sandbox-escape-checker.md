---
name: pattern-sandbox-escape-checker
description: P9 Sandbox-Escape checker — use during /analyze to check one boundary seam where code running in a sandbox primitive (vm2, isolated-vm, V8 isolate, pyodide, eBPF, seccomp, AppArmor, AST-rewriting expression evaluator) reaches the host realm.
---

# pattern-sandbox-escape-checker — P9

You look for **P9 Sandbox-Escape** on the seam map.

## What the pattern looks like

User-supplied code runs in a sandbox abstraction and the sandbox has a known
escape class for its primitive:

| Sandbox primitive | Known escape class |
|---|---|
| `vm2` (Node.js) | Deprecated 2023; many published escapes |
| `isolated-vm` (Node.js) | Reference handle leaks, Promise-then escape |
| Node `vm` module | Not a security boundary — explicitly documented |
| V8 isolate (Chrome/Electron renderer) | Renderer RCE chains |
| `pyodide` / `pyiodide` | DOM access via JS-side bridge |
| `restricted_python` | AST rewrites bypassable via dunder chains |
| AST-rewriting JS evaluators (Tournament, riot-tmpl, mu-template) | Denylist incomplete; new JS features (Iterator helpers, decorators) bypass |
| `seccomp-bpf` | Syscall whitelist incomplete; ptrace, io_uring |
| `eBPF` map | Verifier bypass / unbounded loop |
| AppArmor / SELinux | Profile incomplete; tmpfile traversal |

## What's NOT this pattern

- A pure `eval` with no sandbox claim — that's just RCE, not sandbox-escape.
- Code that *legitimately* has host access (no sandbox in the threat model).
- A sandbox that DOES enforce its claimed boundary correctly.

## How to verify a hit

For each candidate seam, this is the **highest-false-positive pattern** —
verify carefully:

1. **Identify the sandbox primitive.** Don't just say "they use a sandbox" —
   name the exact library + version.
2. **Read the sandbox's known escape literature.** Has the maintainer
   deprecated it? (vm2 yes.) Are there published bypasses? (riot-tmpl yes,
   Tournament likely.)
3. **Check the sandbox's defense-in-depth layers.** AST-rewriting evaluators
   often have multiple layers (variable polyfill, prototype sanitizer,
   spread blocklist, identifier exemption list). Read ALL layers before
   claiming a bypass.
4. **Verify with the generated code, not the source.** For AST-rewriting
   sandboxes, the generated function body is what executes. Read it. The
   Tournament false positive (#dead-leads/2026-05-26 — n8n S1) was missed
   because the verifier didn't read `var global = {};` prepended by
   ExpressionBuilder.
5. **Confirm the escape path executes.** Build a minimal PoC that runs the
   expression in the actual sandbox and observe whether you reach the host
   realm. ANY claim without an executable PoC is REFUTED.

## Output

```
{
  "pattern": "P9-sandbox-escape",
  "candidates": [
    {
      "location": "file:line:symbol",
      "sandbox_primitive": "vm2 | isolated-vm | Tournament | restricted-python | ...",
      "sandbox_version": "...",
      "escape_class": "deprecated-unfixable | denylist-incomplete | reference-leak | new-language-feature | ...",
      "ast_rewrite_layers_checked": "list every layer you read",
      "executable_poc_path_described": "what the PoC would do",
      "confidence": 0.0-1.0,
      "reason": "..."
    }
  ],
  "total_candidates": N,
  "next_step": "validate with PoC | rule out"
}
```

If `ast_rewrite_layers_checked` is empty for an AST-rewriting sandbox, REFUTE
your own claim and return 0 candidates.

Anchored hypotheses only. Under 500 words.
