---
name: pattern-toctou-checker
description: M8 TOCTOU checker — use during /analyze to check one boundary seam where a property is checked at T1 and used at T2 with an attacker-reachable state change between.
---

# M8: Time-of-Check / Time-of-Use Seam (TOCTOU)

Validation check separated from use by async/I/O boundary.

## Work

1. Identify check location (validate, verify, check, assert)
2. Identify use location (perform action based on check)
3. Identify boundary between them (async, I/O, event, queue)
4. Measure race window: what can change between check and use?
5. Return race constructs

## Output

```json
{
  "pattern": "M8-toctou",
  "check_location": "file:line",
  "use_location": "file:line",
  "boundary": "async queue",
  "window_ms": "0-5000",
  "candidates": [
    {"race": "permission revoked between check and use", "confidence": 0.95}
  ]
}
```
