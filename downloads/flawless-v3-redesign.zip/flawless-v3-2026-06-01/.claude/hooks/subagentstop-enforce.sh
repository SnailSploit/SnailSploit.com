#!/usr/bin/env bash
# Flawless v3 — SubagentStop hook. Fires when any sub-agent finishes.
#
# Three jobs:
#   1. Reinforce: every candidate must carry file:line:symbol or be dropped.
#   2. Record: call finding_record_verdict so the calibration loop stays fed.
#   3. SAD trigger: at propagation boundaries, remind the orchestrator to
#      dispatch the SAD agent for consistency review before promoting
#      candidates or advancing the pipeline.
#
# Fail-open. Advisory only — nudges the orchestrator at the right moment.
set -u
raw="$(cat 2>/dev/null)"

echo "[flawless] subagent finished — before promoting any candidate:"
echo "  - drop any candidate without a file:line:symbol anchor"
echo "  - call finding_record_verdict(finding_id, pattern, verdict, confidence, skill_used)"
echo "  - if this was a gap sub-agent or pattern checker: dispatch SAD to review"
echo "    the output against the explanation before promoting candidates"
echo "  - if a pattern is live and you have not pulled its technique:"
echo "    skill_match(pattern, brg) then skill_get(name)"
exit 0
