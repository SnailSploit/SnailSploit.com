#!/bin/bash
# Flawless v3 — PostToolUse hook. One hashed line per tool call to
# pipeline/provenance.jsonl. Hashes I/O (does not store it) — proves what
# happened and in what order without retaining code/payloads. Unchanged from v1.
set -e
PROVENANCE_LOG="pipeline/provenance.jsonl"
mkdir -p "$(dirname "$PROVENANCE_LOG")"
TOOL_NAME="${TOOL_NAME:-unknown}"
TIMESTAMP=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
SESSION_ID="${SESSION_ID:-unknown}"
PHASE="${PHASE:-unknown}"
INPUT_HASH=$(echo "${TOOL_INPUT:-}" | sha256sum | cut -d' ' -f1 | cut -c1-8)
OUTPUT_HASH=$(echo "${TOOL_OUTPUT:-}" | sha256sum | cut -d' ' -f1 | cut -c1-8)
printf '{"timestamp":"%s","session_id":"%s","phase":"%s","tool":"%s","input_hash":"%s","output_hash":"%s","status":"%s"}\n' \
  "$TIMESTAMP" "$SESSION_ID" "$PHASE" "$TOOL_NAME" "$INPUT_HASH" "$OUTPUT_HASH" "${TOOL_STATUS:-unknown}" >> "$PROVENANCE_LOG"
exit 0
