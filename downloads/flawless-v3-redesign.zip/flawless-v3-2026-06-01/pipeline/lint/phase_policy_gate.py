#!/usr/bin/env python3
"""
Flawless phase-policy enforcer — PreToolUse hook.

Reads the active phase from pipeline/.phase and DENIES tools that
.claude/policy.yaml blocks for that phase. Honors `exemptions` (e.g. Bash:git,
Bash:grep always allowed).

Fail-open by design: if there is no active phase, or policy.yaml is missing, or
anything goes wrong, the tool is ALLOWED. The enforcer only constrains while a
finding workflow has explicitly set pipeline/.phase — it never bricks a normal
session. (Trust caveat: the agent can edit .phase/policy.yaml; this raises the
activation energy of drifting out of phase, it does not make it impossible.)
"""
import sys
import json
from pathlib import Path


def main():
    try:
        raw = sys.stdin.read()
        data = json.loads(raw) if raw.strip() else {}
    except Exception:
        sys.exit(0)

    try:
        root = Path(__file__).resolve().parents[2]
        phase_file = root / "pipeline" / ".phase"
        if not phase_file.exists():
            sys.exit(0)
        phase = phase_file.read_text().strip()
        if not phase:
            sys.exit(0)

        import yaml
        policy = yaml.safe_load((root / ".claude" / "policy.yaml").read_text()) or {}
        pconf = (policy.get("phases") or {}).get(phase)
        if not pconf:
            sys.exit(0)

        tool = data.get("tool_name") or data.get("tool") or ""
        tinput = data.get("tool_input") or {}

        tokens = {tool}
        if tool == "Bash":
            cmd = (tinput.get("command") or "").strip()
            first = cmd.split()[0].split("/")[-1] if cmd else ""
            if first:
                tokens.add(f"Bash:{first}")
            tokens.add("Bash:*")

        allowed = set(pconf.get("allowed_tools") or [])
        blocked = set(pconf.get("blocked_tools") or [])
        exempt = {ex.get("tool") for ex in (policy.get("exemptions") or [])
                  if ex.get("phase") in ("any", phase)}

        # ALLOW if explicitly allowed or exempt.
        if (tokens & allowed) or (tokens & exempt):
            sys.exit(0)

        # DENY if explicitly blocked (exact token, Bash:*, or catch-all *).
        deny_hit = next((tk for tk in tokens if tk in blocked), None)
        if deny_hit is None and "*" in blocked:
            deny_hit = "*"
        if deny_hit is None:
            sys.exit(0)

        reason = (
            f"Flawless phase-policy: '{tool}' is blocked in phase '{phase}' "
            f"(matched '{deny_hit}'). Allowed here: {sorted(allowed) or 'none'}. "
            f"Finish the phase or update pipeline/.phase to proceed."
        )
        print(json.dumps({
            "hookSpecificOutput": {
                "hookEventName": "PreToolUse",
                "permissionDecision": "deny",
                "permissionDecisionReason": reason,
            }
        }))
        sys.exit(0)
    except Exception:
        sys.exit(0)


if __name__ == "__main__":
    main()
