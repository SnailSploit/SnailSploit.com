#!/usr/bin/env bash
#
# check-finding-folder.sh
#
# Validates a single READY-TO-SHIP/NN-* folder against the
# concrete checks that make a finding ship-grade.  Returns 0 on
# pass, 1 on fail, with the failed check named on stderr.
#
# Designed to be called by the project-level PreToolUse hook
# (which intercepts `git commit` when staged files touch
# READY-TO-SHIP/) and also by humans who want to lint a single
# finding folder by hand.
#
# Usage:
#   pipeline/lint/check-finding-folder.sh <path-to-finding-folder>
#
# Examples:
#   pipeline/lint/check-finding-folder.sh \
#       pipeline/READY-TO-SHIP/13-gitlab-virtual-registry-upstream-cred-cross-host-leak/
#
# What it checks:
#   1. The folder has at least one of: poc/, advisory/, cve-request/.
#   2. There is at least one PoC source file (poc/legend-*.* or
#      poc/*.{rb,js,go,py,sh}) that is NOT a README.
#   3. There is at least one run-log (poc/run-log*.txt or
#      poc/*-log.txt).
#   4. The newest run-log is NOT older than the newest PoC source.
#      (catches "edited the PoC, forgot to re-run".)
#   5. At least one run-log contains a verdict line ("PASS",
#      "VULNERABLE", or "EXIT 0 = VULNERABLE").
#   6. Either advisory/DISCLOSURE.md OR cve-request/HACKERONE.md
#      OR cve-request/GHSA.md OR cve-request/EMAIL-DRAFT.txt
#      exists and is non-empty.
#   7. Every cited file:line in the disclosure / report (the
#      `file/path:LINE` and `file/path:LINE-LINE` patterns) that
#      points at a path under pipeline/recon/ or a snapshotted
#      file inside this finding folder resolves to a real file
#      that has at least the cited line number.  External cites
#      (gitlab-org/gitlab/..., cli/cli/..., third-party repo
#      paths) are skipped because we don't have the source on
#      disk.

set -euo pipefail

FAIL=0
note() { echo "  [fail] $*" >&2; FAIL=1; }
pass() { echo "  [ ok ] $*"; }

if [ $# -lt 1 ]; then
    echo "usage: $0 <finding-folder>" >&2
    exit 2
fi

DIR="$1"
if [ ! -d "$DIR" ]; then
    echo "$0: $DIR is not a directory" >&2
    exit 2
fi

echo "lint: $DIR"

# --- Check 1: subfolder structure --------------------------------------
if [ ! -d "$DIR/poc" ] && [ ! -d "$DIR/advisory" ] && [ ! -d "$DIR/cve-request" ]; then
    note "no poc/ advisory/ or cve-request/ subdir"
else
    pass "subdir structure present"
fi

# --- Check 2: PoC source file -----------------------------------------
poc_sources=$(find "$DIR/poc" -maxdepth 1 -type f \
    \( -name 'legend-*.go' -o -name 'legend-*.rb' -o -name 'legend-*.js' -o -name 'legend-*.mjs' \
       -o -name 'legend-*.py' -o -name 'legend-*.sh' -o -name 'legend-*.java' \
       -o -name 'legend-*.php' -o -name 'legend-*.pl' \
       -o -name 'legend-*.c' -o -name 'legend-*.cc' -o -name 'legend-*.cpp' -o -name 'legend-*.cxx' \
       -o -name 'legend-*.rs' -o -name 'legend-*.ts' -o -name 'legend-*.zig' \
       -o -name '*.go' -o -name '*.rb' -o -name '*.js' -o -name '*.mjs' -o -name '*.java' \
       -o -name '*.php' -o -name '*.pl' \
       -o -name '*.c' -o -name '*.cc' -o -name '*.cpp' -o -name '*.cxx' \
       -o -name '*.rs' -o -name '*.ts' -o -name '*.zig' \) \
    2>/dev/null | grep -v 'README\|run-log' || true)
if [ -z "$poc_sources" ]; then
    note "no PoC source file under poc/"
else
    pass "PoC source(s) present: $(echo "$poc_sources" | wc -l) file(s)"
fi

# --- Check 3: run-log ------------------------------------------------
run_logs=$(find "$DIR/poc" -maxdepth 1 -type f \
    \( -name 'run-log*.txt' -o -name '*-log.txt' \) 2>/dev/null || true)
if [ -z "$run_logs" ]; then
    note "no run-log under poc/"
else
    pass "run-log(s) present: $(echo "$run_logs" | wc -l) file(s)"
fi

# --- Check 4: run-log newer than PoC source --------------------------
# Portable mtime read: GNU coreutils stat uses `-c '%Y'`, BSD stat (macOS) uses
# `-f '%m'`. Detect once and reuse. `find -printf '%T@'` is GNU-only and silently
# dies on macOS without `findutils`, so we avoid it entirely.
if stat -c '%Y' / >/dev/null 2>&1; then
    _mtime() { stat -c '%Y' "$1"; }
else
    _mtime() { stat -f '%m' "$1"; }
fi

if [ -n "$poc_sources" ] && [ -n "$run_logs" ]; then
    newest_poc_t=0
    for f in $poc_sources; do
        t=$(_mtime "$f" 2>/dev/null || echo 0)
        [ "$t" -gt "$newest_poc_t" ] && newest_poc_t=$t
    done
    newest_log_t=0
    for f in $run_logs; do
        t=$(_mtime "$f" 2>/dev/null || echo 0)
        [ "$t" -gt "$newest_log_t" ] && newest_log_t=$t
    done
    if [ "$newest_poc_t" -gt 0 ] && [ "$newest_log_t" -gt 0 ]; then
        if [ "$newest_poc_t" -gt "$newest_log_t" ]; then
            note "PoC source modified AFTER newest run-log (re-run needed)"
        else
            pass "run-log newer than PoC source"
        fi
    fi
fi

# --- Check 5: verdict line in at least one run-log -------------------
verdict_found=0
for f in $run_logs; do
    if grep -Eq '\bPASS\b|\bVULNERABLE\b|EXIT 0' "$f"; then
        verdict_found=1
        break
    fi
done
if [ "$verdict_found" -eq 0 ] && [ -n "$run_logs" ]; then
    note "no run-log contains a PASS / VULNERABLE / EXIT 0 verdict line"
elif [ -n "$run_logs" ]; then
    pass "verdict line found in run-log"
fi

# --- Check 6: at least one report-form artifact ----------------------
if [ ! -s "$DIR/advisory/DISCLOSURE.md" ] \
&& [ ! -s "$DIR/cve-request/HACKERONE.md" ] \
&& [ ! -s "$DIR/cve-request/GHSA.md" ] \
&& [ ! -s "$DIR/cve-request/EMAIL-DRAFT.txt" ]; then
    note "no report artifact (DISCLOSURE.md / HACKERONE.md / GHSA.md / EMAIL-DRAFT.txt)"
else
    pass "report artifact present"
fi

# --- Check 7: file:line citations resolve (best-effort) --------------
# Looks for FILE:LINE or FILE:LINE-LINE patterns inside the
# DISCLOSURE.md / HACKERONE.md / GHSA.md.  Only resolves cites
# that point at files inside this finding folder OR inside
# pipeline/recon/.  External cites (gitlab-org/gitlab/...,
# cli/cli/..., etc.) are skipped because the source isn't on disk.
unresolved=0
for report in "$DIR/advisory/DISCLOSURE.md" "$DIR/cve-request/HACKERONE.md" \
              "$DIR/cve-request/GHSA.md"; do
    [ -s "$report" ] || continue
    # extract patterns like ` foo/bar.rb:42 ` or ` foo/bar.rb:42-50 `
    cites=$(grep -oE '[a-zA-Z0-9_/.-]+\.(rb|go|js|ts|py|sh|md):[0-9]+(-[0-9]+)?' "$report" \
            | sort -u || true)
    for cite in $cites; do
        path="${cite%:*}"
        lines="${cite##*:}"
        first_line="${lines%-*}"
        # Only check paths that exist relative to repo root or
        # under this finding folder.
        for prefix in "" "$DIR/" "pipeline/recon/"; do
            if [ -f "${prefix}${path}" ]; then
                total_lines=$(wc -l < "${prefix}${path}")
                if [ "$first_line" -gt "$total_lines" ]; then
                    note "anchor $cite in $(basename "$report") points past EOF (file has $total_lines lines)"
                    unresolved=$((unresolved+1))
                fi
                break
            fi
        done
        # Paths that resolve to nothing on disk are external; skip silently.
    done
done
if [ "$unresolved" -eq 0 ]; then
    pass "in-repo file:line citations resolve"
fi

if [ "$FAIL" -ne 0 ]; then
    echo
    echo "lint: $DIR -> FAIL"
    exit 1
fi
echo "lint: $DIR -> ok"
exit 0
