#!/usr/bin/env bash
# Flawless v3 — checker-count drift guard.
# Disk (the pattern-*-checker.md files) is the single source of truth. Any prose
# file that states a different count is stale and will mislead a fresh session
# (v1's verify.sh hard-coded n==11 and would FAIL a correct 14-checker tree).
set -u
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
AGENTS="$ROOT/.claude/agents"
N=$(ls "$AGENTS"/pattern-*-checker.md 2>/dev/null | wc -l | tr -d ' ')
rc=0
echo "checkers on disk: $N"
[ "$N" -ge 1 ] || { echo "  [FAIL] no pattern-*-checker.md files in $AGENTS"; exit 1; }
if [ -f "$ROOT/.claude/commands/analyze.md" ]; then
  if grep -Eq "\b$N\b" "$ROOT/.claude/commands/analyze.md"; then
    echo "  [ ok ] analyze.md references $N"
  else
    echo "  [FAIL] analyze.md does not state $N checkers"; rc=1
  fi
fi
if [ -f "$ROOT/CLAUDE.md" ]; then
  if grep -Eq "\b$N\b (subagents|pattern|checkers|checker)" "$ROOT/CLAUDE.md"; then
    echo "  [ ok ] CLAUDE.md count matches $N"
  else
    echo "  [warn] CLAUDE.md checker count may be stale (disk has $N)"
  fi
fi
exit $rc
