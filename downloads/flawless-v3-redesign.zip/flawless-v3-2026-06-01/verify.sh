#!/usr/bin/env bash
# Flawless v3 — one-shot proof the wired machinery works. Exercises the real
# backends directly (no Claude Code restart). Unlike v1, the checker count is
# DERIVED from disk, so this never fails a correct tree on a stale literal.
set -u
cd "$(dirname "$0")"
PY=infra/.venv/bin/python; [ -x "$PY" ] || PY=python3
pass=0; fail=0
ok(){ echo "  [PASS] $1"; pass=$((pass+1)); }
no(){ echo "  [FAIL] $1"; fail=$((fail+1)); }

echo "==================================================="
echo " FLAWLESS v3 VERIFICATION"
echo "==================================================="

# 1. deps (mcp/fastembed optional in some envs; numpy/yaml required)
if $PY -c "import numpy,yaml" 2>/dev/null; then ok "core deps (numpy, pyyaml)"; else no "core deps missing"; fi
$PY -c "import mcp" 2>/dev/null && ok "mcp present (MCP servers runnable)" || echo "  [info] mcp not installed in this env — install.sh sets it up on your machine"
$PY -c "import fastembed" 2>/dev/null && ok "fastembed present (semantic scope live)" || echo "  [info] fastembed not installed here — semantic scope builds on your machine"

# 2. config JSON valid
$PY -c "import json;json.load(open('.mcp.json'));json.load(open('.claude/settings.json'))" 2>/dev/null \
  && ok ".mcp.json + settings.json valid JSON" || no "config JSON invalid"

# 3. policy.yaml valid + has outcome phase
$PY -c "import yaml;d=yaml.safe_load(open('.claude/policy.yaml'));assert 'outcome' in d['phases']" 2>/dev/null \
  && ok "policy.yaml valid + outcome phase present" || no "policy.yaml invalid or missing outcome phase"

# 4. checker count DERIVED + prose matches (the v1 drift bug, fixed)
N=$(ls .claude/agents/pattern-*-checker.md 2>/dev/null | wc -l | tr -d ' ')
if [ "$N" -ge 1 ] && bash infra/lint/check-checker-count.sh >/dev/null 2>&1; then
  ok "$N pattern checkers on disk; prose counts match (no drift)"
else
  no "checker-count drift: disk has $N but a prose file disagrees"
fi
[ -f .claude/agents/pattern-verifier.md ] && ok "pattern-verifier present" || no "pattern-verifier missing"

# 5. finding-store: 9 tools registerable + full v3 round-trip (verdict, reason, outcome, stats)
if $PY - <<'PYEOF' 2>/dev/null
import sys; sys.path.insert(0,'infra/finding-store-mcp')
import server as s
s.init_db()
f=s.finding_create('vt','seam',['P3'],{}); 
s.finding_update(f['id'],'DISCOVERED→CANDIDATE',reason='r')
s.finding_record_verdict(f['id'],'P3','CONFIRMED',0.9,'offensive-toctou','w')
s.finding_record_outcome(f['id'],'accepted',cve='CVE-X')
g=s.finding_get(f['id'])
assert g['state_history'][0]['reason']=='r'
assert g['verdicts'][0]['skill_used']=='offensive-toctou'
assert g['outcomes'][0]['cve']=='CVE-X'
assert s.finding_verdict_stats('P3')['P3']['confirm_rate']==1.0
PYEOF
then ok "finding-store v3: verdict + transition_reason + outcome + stats round-trip"; else no "finding-store v3 round-trip failed"; fi

# 5b. finding-store MCP harness registers 8 tools (only if mcp installed)
if $PY -c "import mcp" 2>/dev/null; then
  if $PY - <<'PYEOF' 2>/dev/null
import asyncio,sys; sys.path.insert(0,'infra/finding-store-mcp')
import mcp_server as m
assert len(asyncio.run(m.mcp.list_tools()))==8
PYEOF
  then ok "finding-store MCP registers 8 tools"; else no "finding-store MCP tool count != 8"; fi
fi

# 6. skill-router: discovers + matches + get-by-name (against a temp skill)
if $PY - <<'PYEOF' 2>/dev/null
import sys,tempfile,os
d=tempfile.mkdtemp(); os.makedirs(d+'/offensive-toctou')
open(d+'/offensive-toctou/SKILL.md','w').write(
"---\nname: offensive-toctou\ndescription: race condition time of check use window concurrency toctou\n---\n# body widen the window\n")
os.environ['CLAUDE_SKILLS_DIR']=d
sys.path.insert(0,'infra/skill-router-mcp'); import server as r
assert r.router_status()['skills_discovered']>=1
m=r.skill_match('P3','race between check and use',2); assert m[0]['name']=='offensive-toctou'
assert 'widen the window' in r.skill_get('offensive-toctou')['body']
PYEOF
then ok "skill-router: discover + match(P3) + get-by-name"; else no "skill-router failed"; fi

# 7. contradiction gate present + executable
[ -x infra/lint/contradiction_gate.sh ] && ok "contradiction gate wired (contradiction_gate.sh)" || no "contradiction gate missing"

# 8. policy enforcer deny/allow (phase=validation blocks Write, allows Read)
if $PY -c "import mcp" >/dev/null 2>&1 || true; then
  echo validation > pipeline/.phase
  deny=$(printf '{"tool_name":"Write","tool_input":{}}' | $PY pipeline/lint/phase_policy_gate.py 2>/dev/null)
  allow=$(printf '{"tool_name":"Read","tool_input":{}}' | $PY pipeline/lint/phase_policy_gate.py 2>/dev/null)
  rm -f pipeline/.phase
  if echo "$deny" | grep -q '"deny"' && [ -z "$allow" ]; then ok "policy enforcer: blocks Write, allows Read in validation"; else no "policy enforcer logic off"; fi
fi

# 9. engine skill present in correct folder form
[ -f .claude/skills/flawless-engine/SKILL.md ] && ok "engine skill in folder form (loads as a skill)" || no "engine skill missing/flat"

# 10. hooks present + executable
hk=0; for h in sessionstart-boot subagentstop-enforce precompact-save-memory posttooluse-provenance; do
  [ -x ".claude/hooks/$h.sh" ] && hk=$((hk+1)); done
[ "$hk" -eq 4 ] && ok "4 hook scripts present + executable" || no "expected 4 hooks, found $hk executable"

echo "---------------------------------------------------"
if [ "$fail" -eq 0 ]; then
  echo " RESULT: ALL $pass CHECKS PASSED — Flawless v3 is wired."
  echo "==================================================="; exit 0
else
  echo " RESULT: $fail FAILED, $pass passed."
  echo "==================================================="; exit 1
fi
