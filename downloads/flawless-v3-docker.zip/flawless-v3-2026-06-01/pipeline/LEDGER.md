# LEDGER

Chronological log of shipped findings. Each entry appended on /close.

(Empty — initialized for new operator. Findings will be appended below as you ship them.)
