# Flawless Methodologies (v2 — 2026-05-26 refactor)

A methodology is a **pattern of code that produces a bug class**. Pattern
checkers look for the pattern's signature on a seam; the operator verifies
the claim against the actual code.

## v2 taxonomy: 9 core patterns

| ID | Name | One-line shape |
|---|---|---|
| P1 | **Invariant-Not-Enforced** | Validator/docs/types promise a property the implementation doesn't enforce. |
| P2 | **Parsing-Disagreement** | Two parsers see the same bytes differently; a security decision rides on one. |
| P3 | **TOCTOU** | Property checked at T1, used at T2, attacker-reachable state change in between. |
| P4 | **Dual-Store** | Same value lives in two stores; a writer updates only one; reader trusts the stale one. |
| P5 | **Fix-Did-Not-Propagate** | A known fix elsewhere isn't applied here. Subtypes: SIBLING, FRESH-FEATURE, BACKPORT, UNASSIGNED-CVE. |
| P6 | **Error-Semantic** | Two components disagree on the meaning of an error; the lenient side carries a security decision. |
| P7 | **Unsafe-Deserialization** | Deserializer is Turing-complete (pickle, marshal, YAML !!python/*, BSON code-fields, Java ObjectInputStream); input crosses a trust boundary. |
| P8 | **Cryptographic-Misuse** | Wrong primitive (ECB, predictable IV, weak RNG), missing constant-time compare, alg-confusion, key reuse, no integrity-then-encrypt. |
| P9 | **Sandbox-Escape** | Code in a sandbox primitive (vm2, isolated-vm, V8 isolate, pyodide, eBPF, seccomp policy) reaches the host realm. |

## Mapping from legacy M1–M12

The 198 SHIPPED findings predating this refactor are tagged with the original
M numbers. Mapping is preserved for git-archaeology:

| Legacy | New | Notes |
|---|---|---|
| M1 Incomplete-Fix | **P5.SIBLING** | sibling of a fixed CVE that remains unfixed |
| M2 Cross-Protocol | **P2** | parsing/decoding disagreement at a protocol boundary |
| M3 Fresh-Feature | **P5.FRESH-FEATURE** | new field on recently-fixed surface bypasses fix's validator |
| M4 Backport-Gap | **P5.BACKPORT** | mainline fix missing from stable branch |
| M5 Unassigned-CVE | **P5.UNASSIGNED-CVE** | security fix shipped without CVE; pattern recurs elsewhere |
| M6 Lossy-Validation | **P1** | validator returns OK; binding metadata is dropped |
| M7 Dual-Store | **P4** | unchanged |
| M8 TOCTOU | **P3** | unchanged |
| M9 Implicit-Contract | **P1** | docs/spec promise a guarantee the impl doesn't enforce |
| M10 Parsing-Oracle | **P2** | unchanged shape (two parsers, same input) |
| M11 (never assigned) | — | the gap is now closed; numbering went M1–M10, then M12 |
| M12 Error-Semantic | **P6** | unchanged |

Findings shipped this session (2026-05-26):

| # | Legacy | New | Notes |
|---|---|---|---|
| #296 | M10 | P2 | think-tag streaming vs batch parser |
| #297 | M6 | P1 | broken bound check (unsigned underflow) |
| #298 | M9+M12 | P1+P6 | cross-origin Auth redirect; opt-in safety, opt-out leak |
| #299 | M9+M6 | P1 | OIDC missing email_verified |
| #300 | M6+M10 | P1+P2 | uint32 overflow → small alloc + large write |
| #301 | M6 | P1 | missing newRoleName gate |
| #302 | M9+M3 | P1+P5.FRESH-FEATURE | SSO bolted onto password world |
| #303 | M6+M10 | P1+P2 | no bound on fnameLen for stack buffer |
| #304 | M9+M10 | P1+P2 | 4-byte buffer without NUL terminator |
| #305 | M9+M10 | P1 | MCP server text into agent system prompt |
| #306 | M9+M10 | **P7** | bundle deserializer is cloudpickle on attacker bytes |

#306 is the clearest case where the old taxonomy was wrong — it's textbook
**Unsafe-Deserialization (P7)**, not parsing-oracle or implicit-contract.
The refactor makes that classification natural.

## Per-pattern dispatch

`/analyze` dispatches one checker subagent per pattern in parallel
(`.claude/agents/pattern-*-checker.md`). Subagent files for P1–P6 cover the
old M-set. New for v2:

- `.claude/agents/pattern-unsafe-deserialization-checker.md` (P7)
- `.claude/agents/pattern-cryptographic-misuse-checker.md` (P8)
- `.claude/agents/pattern-sandbox-escape-checker.md` (P9)

Plus the verifier:

- `.claude/agents/pattern-verifier.md` — confirms or refutes each candidate
  by re-reading the cited anchor and checking for missed defenses.

## What this taxonomy is NOT

- Not a CWE mapping. CWE is for advisory writing; P1–P9 are for *discovery*.
- Not exhaustive. New patterns get added when a real finding doesn't fit any
  of the 9. New methodologies emerge from real findings, not from theory.
- Not strict. A single seam can stack multiple patterns (e.g., P1+P2 is
  common). Stacking is a confidence signal — more stacked patterns =
  stronger candidate.
