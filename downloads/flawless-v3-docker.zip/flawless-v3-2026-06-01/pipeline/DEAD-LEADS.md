# DEAD-LEADS

Candidates that *looked* like findings during discovery/analyze but turned out
to be wrong on closer inspection. Auto-populated by the pattern-verifier agent
when it REFUTES a candidate.

Format per entry (verifier provides this on each REFUTE):

```
## YYYY-MM-DD | target | seam-id | claimed by
**Claim**: what the agent said
**Reality**: what the code actually does (file:line)
**Why the agent was wrong**: short explanation
**Recurrence prevention**: pattern to look for in future runs
```

See `DEAD-LEADS.md.example` for sample entries from the original operator's session.
