# DEAD-ENDS

Candidates ruled out at the /poc or /validate stage with evidence and reopen criteria.

(Empty — initialized for new operator.)
