#!/usr/bin/env bash
# check-sad-review.sh — verify SAD review artifact exists with required sections.
# SAD is not a reminder. It is a blocking gate.
set -euo pipefail

FAIL=0
note() { echo "  [SAD] $*" >&2; FAIL=1; }
pass() { echo "  [SAD] $*"; }

if [ $# -lt 1 ]; then echo "usage: $0 <finding-folder>" >&2; exit 2; fi
DIR="$1"

SAD_FILE="$DIR/analysis/sad-review.md"

if [ ! -s "$SAD_FILE" ]; then
    note "missing analysis/sad-review.md — SAD review is required before promotion"
    exit 1
fi
pass "sad-review.md present"

# Check required sections
for section in "Candidate Promotion" "PoC Verdict" "Validation Outcome" "Ship Readiness"; do
    if grep -qi "## $section" "$SAD_FILE" 2>/dev/null; then
        pass "section '$section' present"
    else
        note "missing section '## $section' in sad-review.md"
    fi
done

# Check for verdicts
verdict_count=$(grep -Eic '\b(CONFIRM|REFUTE|DOWNGRADE|NEEDS-EVIDENCE)\b' "$SAD_FILE" 2>/dev/null || echo 0)
if [ "$verdict_count" -ge 1 ]; then
    pass "$verdict_count SAD verdict(s) recorded"
else
    note "no SAD verdicts (CONFIRM/REFUTE/DOWNGRADE/NEEDS-EVIDENCE) in sad-review.md"
fi

# Check for REFUTE or NEEDS-EVIDENCE that should block
if grep -Eiq '\bNEEDS-EVIDENCE\b' "$SAD_FILE" 2>/dev/null; then
    note "SAD says NEEDS-EVIDENCE — candidate cannot advance until evidence supplied"
fi

if [ "$FAIL" -eq 0 ]; then
    echo "SAD: $DIR -> review complete"
fi
exit $FAIL
