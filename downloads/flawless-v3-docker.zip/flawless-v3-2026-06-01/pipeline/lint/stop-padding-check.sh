#!/usr/bin/env bash
#
# stop-padding-check.sh
#
# Project-level Stop hook for the LEGEND repo.  Greps the most
# recent commit message for rhetorical-inflation words this
# session demonstrated:
#
#   "compounding"      I padded session totals across rolls.
#   "comprehensive"    Generic positive-feel adjective.
#   "robust"           Same.
#   "elegant"          Same.
#   "seamless"         Same.
#
# Soft warning: prints to stderr but exits 0 (does not block
# session close).  The point is to nudge future-self that the
# pattern showed up, not to refuse the commit.  The git-state
# check (already in user-level ~/.claude/stop-hook-git-check.sh)
# is the hard gate; this is the soft companion.
#
# Wiring: registered in .claude/settings.json as a Stop hook.

set -euo pipefail

# Bail if not in a git repo.
if ! git rev-parse --git-dir >/dev/null 2>&1; then
    exit 0
fi

# Read the most recent commit message; fail open if there's no
# commit yet (e.g., empty repo).
last_msg=$(git log -1 --pretty=%B 2>/dev/null || true)
if [ -z "$last_msg" ]; then
    exit 0
fi

# Patterns that flagged this session.  Word-boundary regex so
# "comprehensively" matches but "comprised" does not.
forbidden_re='\b(compounding|comprehensive|comprehensively|robust|elegant|seamless)\b'

if echo "$last_msg" | grep -Eiq "$forbidden_re"; then
    echo "stop-padding-check: most recent commit message contains" >&2
    echo "  rhetorical-inflation words.  Pattern caught:" >&2
    echo "$last_msg" | grep -Ei "$forbidden_re" --color=never >&2
    echo "" >&2
    echo "  This is a soft warning, not a block.  Future commits" >&2
    echo "  should prefer literal counts and concrete claims." >&2
fi

exit 0
