#!/usr/bin/env bash
# check-agent-plan.sh — enforce agent-plan.json contract.
# No subagent runs unless it appears in analysis/agent-plan.json.
# Stage A: one per BRG gap. Stage B: only uncovered seams.
set -euo pipefail

FAIL=0
note() { echo "  [plan] $*" >&2; FAIL=1; }
pass() { echo "  [plan] $*"; }

if [ $# -lt 1 ]; then echo "usage: $0 <finding-folder>" >&2; exit 2; fi
DIR="$1"

PLAN="$DIR/analysis/agent-plan.json"
BRG="$DIR/brg.md"
CANDIDATES="$DIR/analysis/candidates.md"

# Plan must exist
if [ ! -s "$PLAN" ]; then
    note "missing analysis/agent-plan.json — no subagent dispatch without a plan"
    exit 1
fi
pass "agent-plan.json present"

# Validate JSON
if ! python3 -c "import json; json.load(open('$PLAN'))" 2>/dev/null; then
    note "agent-plan.json is not valid JSON"
    exit 1
fi
pass "agent-plan.json valid JSON"

# Check that stage_a seam IDs exist in brg.md
if [ -f "$BRG" ]; then
    stage_a_seams=$(python3 -c "
import json
plan = json.load(open('$PLAN'))
for entry in plan.get('stage_a', []):
    print(entry.get('seam_id', ''))
" 2>/dev/null || true)
    for sid in $stage_a_seams; do
        [ -z "$sid" ] && continue
        if ! grep -qi "$sid" "$BRG" 2>/dev/null; then
            note "stage_a references $sid but brg.md has no $sid"
        fi
    done
    pass "stage_a seam IDs trace to brg.md"
fi

# Check that stage_b only runs on uncovered seams
covered=$(python3 -c "
import json
plan = json.load(open('$PLAN'))
for s in plan.get('covered_seams', []):
    print(s)
" 2>/dev/null || true)

stage_b_seams=$(python3 -c "
import json
plan = json.load(open('$PLAN'))
for entry in plan.get('stage_b', []):
    print(entry.get('seam_id', ''))
" 2>/dev/null || true)

for sid in $stage_b_seams; do
    [ -z "$sid" ] && continue
    if echo "$covered" | grep -q "$sid"; then
        note "stage_b runs on covered seam $sid (should only run on uncovered)"
    fi
done
[ -n "$stage_b_seams" ] && pass "stage_b seams are uncovered"

if [ "$FAIL" -eq 0 ]; then
    echo "plan: $DIR -> valid"
fi
exit $FAIL
