#!/usr/bin/env python3
"""FLAWLESS v3 phase-policy gate (PreToolUse hook).

While pipeline/.phase is set to a valid phase, unknown tools are DENIED.
Fail-open ONLY when:
  - pipeline/.phase is missing
  - pipeline/.phase is empty
  - policy.yaml is unreadable
  - hook input is malformed

If a valid phase is active: default deny.
"""
import json, sys, yaml
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent
PHASE_FILE = ROOT / "pipeline" / ".phase"
POLICY_FILE = ROOT / ".claude" / "policy.yaml"

# Read hook input
try:
    hook_input = json.loads(sys.stdin.read())
    tool_name = hook_input.get("tool_name", "")
except Exception:
    sys.exit(0)  # malformed input -> fail-open

# Read phase
try:
    phase = PHASE_FILE.read_text().strip()
except FileNotFoundError:
    sys.exit(0)  # no phase set -> fail-open
if not phase:
    sys.exit(0)  # empty phase -> fail-open

# Read policy
try:
    policy = yaml.safe_load(POLICY_FILE.read_text())
except Exception:
    sys.exit(0)  # unreadable policy -> fail-open

phases = policy.get("phases", {})
if phase not in phases:
    sys.exit(0)  # unknown phase -> fail-open (may be custom)

phase_config = phases[phase]
allowed = set(phase_config.get("allowed_tools", []))
blocked = set(phase_config.get("blocked_tools", []))

# Exempt tools (always allowed regardless of phase)
EXEMPT = {"Read", "Grep", "Glob", "LS", "Agent"}

# Check
if tool_name in EXEMPT:
    sys.exit(0)  # always allowed

if tool_name in blocked:
    print(f"[phase-gate] BLOCKED: '{tool_name}' is blocked in phase '{phase}'", file=sys.stderr)
    sys.exit(1)

if tool_name in allowed:
    sys.exit(0)  # explicitly allowed

# DEFAULT DENY while phase is active
print(f"[phase-gate] DENIED: '{tool_name}' not in allowed_tools for phase '{phase}'", file=sys.stderr)
sys.exit(1)
