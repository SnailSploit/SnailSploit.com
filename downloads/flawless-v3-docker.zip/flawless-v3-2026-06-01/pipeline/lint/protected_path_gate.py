#!/usr/bin/env python3
"""FLAWLESS v3 protected-path gate (PreToolUse hook).

Blocks writes to protected paths unless phase is 'maintenance'.
Protected paths:
  .claude/settings.json, .claude/policy.yaml, .claude/hooks/,
  .claude/agents/, pipeline/lint/, pipeline/.phase
"""
import json, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent
PHASE_FILE = ROOT / "pipeline" / ".phase"

PROTECTED = [
    ".claude/settings.json",
    ".claude/policy.yaml",
    ".claude/hooks/",
    ".claude/agents/",
    "pipeline/lint/",
    "pipeline/.phase",
]

WRITE_TOOLS = {"Write", "Edit", "Bash"}

try:
    hook_input = json.loads(sys.stdin.read())
    tool_name = hook_input.get("tool_name", "")
    tool_input = hook_input.get("tool_input", {})
except Exception:
    sys.exit(0)

if tool_name not in WRITE_TOOLS:
    sys.exit(0)  # reads are always fine

# Check phase
try:
    phase = PHASE_FILE.read_text().strip()
except FileNotFoundError:
    phase = ""

if phase == "maintenance":
    sys.exit(0)  # maintenance mode allows everything

# For Write/Edit, check the path
target_path = tool_input.get("file_path", "") or tool_input.get("path", "")

for protected in PROTECTED:
    if target_path and (target_path.startswith(protected) or protected.startswith(target_path)):
        print(f"[protected-path] BLOCKED: cannot modify '{target_path}' outside maintenance phase", file=sys.stderr)
        sys.exit(1)

# For Bash, check if command touches protected paths
if tool_name == "Bash":
    command = tool_input.get("command", "")
    for protected in PROTECTED:
        for write_cmd in ["rm ", "mv ", "cp ", "> ", ">> ", "chmod ", "tee "]:
            if write_cmd in command and protected in command:
                print(f"[protected-path] BLOCKED: bash command modifies protected path '{protected}'", file=sys.stderr)
                sys.exit(1)

sys.exit(0)
