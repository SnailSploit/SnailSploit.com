#!/usr/bin/env bash
# check-chain-lineage.sh — verify analysis/chains.md when >1 candidate survives.
# Each chain must reference real candidate IDs and reach a sink+oracle.
set -euo pipefail

FAIL=0
note() { echo "  [chain] $*" >&2; FAIL=1; }
pass() { echo "  [chain] $*"; }

if [ $# -lt 1 ]; then echo "usage: $0 <finding-folder>" >&2; exit 2; fi
DIR="$1"

CANDIDATES="$DIR/analysis/candidates.md"
CHAINS="$DIR/analysis/chains.md"

# Count surviving candidates
cand_count=0
[ -f "$CANDIDATES" ] && cand_count=$(grep -cE 'CAND-[0-9]+|candidate[_-][0-9]+' "$CANDIDATES" 2>/dev/null || echo 0)

# chains.md required if >1 candidate
if [ "$cand_count" -gt 1 ]; then
    if [ ! -s "$CHAINS" ]; then
        note "missing analysis/chains.md ($cand_count candidates survived — chain analysis required)"
        exit 1
    fi
    pass "chains.md present for $cand_count candidates"

    # Each chain must have a path with E and O
    if ! grep -qE 'E-[0-9]+|Entry' "$CHAINS"; then
        note "chains.md has no Entry node"
    fi
    if ! grep -qE 'O-[0-9]+|Oracle' "$CHAINS"; then
        note "chains.md has no Oracle node"
    fi
    # Must have a ChainScore
    if ! grep -qi 'ChainScore' "$CHAINS"; then
        note "chains.md has no ChainScore"
    else
        pass "ChainScore present"
    fi
    # Must have a PoC decision
    if grep -qiE 'POC-WORTHY|HOLD|DEAD-END' "$CHAINS"; then
        pass "PoC decision present"
    else
        note "chains.md has no PoC decision (POC-WORTHY/HOLD/DEAD-END)"
    fi
else
    pass "single candidate — chains.md optional"
fi

if [ "$FAIL" -eq 0 ]; then
    echo "chain: $DIR -> valid"
fi
exit $FAIL
