#!/usr/bin/env bash
#
# precommit-ship-gate.sh
#
# Project-level PreToolUse hook for the LEGEND repo.  Runs before
# every Bash tool call.  Most calls are passed through silently;
# the hook only intervenes when the agent is about to `git commit`
# AND the staged set touches `pipeline/READY-TO-SHIP/`.  In that
# case it runs the per-finding lint and blocks the commit if any
# finding folder fails its concrete checks.
#
# This catches the failure modes demonstrated this session:
#   * line-number drift in cited anchors (#09 cited :96, real :100)
#   * over-claim where the PoC was edited after the disclosure was
#     written but never re-run
#   * shipping a folder that's missing the run-log or the PoC
#
# Trust-asymmetry caveat: the agent that this hook is enforcing
# against is the same actor that can edit the hook.  This raises
# the activation energy of skipping but does not make skipping
# impossible.  Documented openly.
#
# Wiring: registered in .claude/settings.json as a PreToolUse
# hook with matcher "Bash".

set -euo pipefail

# Read the JSON sent on stdin by the harness.
input=$(cat)

# Bail if jq isn't available — but WARN, don't silently pass (jq is in install.sh deps).
if ! command -v jq >/dev/null 2>&1; then
    echo "  [warn] ship-gate: jq not installed — gate cannot run, commit NOT linted. Install jq." >&2
    exit 0
fi

# Pull the command being run and the cwd.
cmd=$(echo "$input" | jq -r '.tool_input.command // ""')
cwd=$(echo "$input" | jq -r '.cwd // ""')

# Pass-through: anything that isn't a `git commit` is none of
# our business.  Match the `git commit` token specifically; the
# agent often runs compound shell pipelines so we use a regex
# rather than a string-prefix check.
if ! echo "$cmd" | grep -Eq '(^|[;&|()[:space:]])git[[:space:]]+commit([[:space:]]|$)'; then
    exit 0
fi

# Find the repo root from cwd; bail if we're not inside one.
if [ -n "$cwd" ] && [ -d "$cwd" ]; then
    repo_root=$(cd "$cwd" && git rev-parse --show-toplevel 2>/dev/null || true)
else
    repo_root=$(git rev-parse --show-toplevel 2>/dev/null || true)
fi
if [ -z "$repo_root" ]; then
    exit 0
fi

# Bail if this isn't the LEGEND repo (recognised by the presence
# of pipeline/lint/ alongside pipeline/READY-TO-SHIP/).  Keeps the
# hook from misfiring if the operator runs the agent in another
# repo with the same hooks copied over.
if [ ! -d "$repo_root/pipeline/SHIPPED" ] || \
   [ ! -d "$repo_root/pipeline/lint" ]; then
    exit 0
fi

# Find the staged finding folders.  We use `git diff --cached
# --name-only` so we get exactly what's about to be committed.
staged=$(cd "$repo_root" && git diff --cached --name-only 2>/dev/null || true)

# Anything under pipeline/READY-TO-SHIP/NN-* triggers the lint.
finding_folders=$(echo "$staged" \
    | grep -oE '^pipeline/READY-TO-SHIP/[a-z0-9][a-z0-9-]*-[0-9]{14}/' \
    | sort -u || true)

# Pass-through if the commit doesn't touch any finding folder.
if [ -z "$finding_folders" ]; then
    exit 0
fi

# Run the lint on each touched finding folder.  Collect failures.
# Skip folders that no longer exist on disk: a fully-deleted folder
# in the staged diff is a withdrawal (Invariant 9, honest yields),
# not a ship-grade artefact, and there is nothing for the lint to
# check.  The withdrawal record belongs in
# pipeline/notes/STATUS-OF-NON-SHIPPING.md, which the operator
# updates separately.
failed_folders=""
all_messages=""
for folder in $finding_folders; do
    if [ ! -d "$repo_root/$folder" ]; then
        continue
    fi
    if ! lint_out=$("$repo_root/pipeline/lint/check-finding-folder.sh" \
                    "$repo_root/$folder" 2>&1); then
        failed_folders="$failed_folders $folder"
        all_messages="$all_messages
$lint_out"
    fi
done

# All clean -> allow the commit through.
if [ -z "$failed_folders" ]; then
    exit 0
fi

# Block the commit and report the failures back to the agent.
# Per the harness contract, return JSON with permissionDecision
# "deny" plus the reason.
reason="LEGEND ship-gate: lint failures in:$failed_folders

$all_messages

To bypass (only when intentional, e.g., committing a deliberately
incomplete WIP folder), unstage the affected paths and commit them
separately, or fix the lint failures listed above first.

This hook is at pipeline/lint/precommit-ship-gate.sh.  The lint
script is at pipeline/lint/check-finding-folder.sh."

# Emit the deny JSON on stdout (per Claude Code hook contract).
jq -n \
    --arg reason "$reason" \
    '{
        hookSpecificOutput: {
            hookEventName: "PreToolUse",
            permissionDecision: "deny",
            permissionDecisionReason: $reason
        }
    }'
exit 0
