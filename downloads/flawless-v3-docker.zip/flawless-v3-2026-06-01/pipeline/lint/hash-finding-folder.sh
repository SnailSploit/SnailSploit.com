#!/usr/bin/env bash
# hash-finding-folder.sh — compute a deterministic SHA-256 over a finding folder.
# Excludes FINDING.sha256 itself to avoid circular dependency.
# Usage: pipeline/lint/hash-finding-folder.sh <finding-folder>
set -euo pipefail

if [ $# -lt 1 ]; then
    echo "usage: $0 <finding-folder>" >&2
    exit 2
fi

DIR="$1"
[ -d "$DIR" ] || { echo "$0: $DIR is not a directory" >&2; exit 2; }

HASHFILE="$DIR/FINDING.sha256"

# Deterministic: sort by name, exclude the hash file itself, hash content only
HASH=$(find "$DIR" -type f ! -name 'FINDING.sha256' -print0 \
    | sort -z \
    | xargs -0 sha256sum \
    | sha256sum \
    | awk '{print $1}')

echo "$HASH" > "$HASHFILE"
echo "FINDING.sha256: $HASH"
