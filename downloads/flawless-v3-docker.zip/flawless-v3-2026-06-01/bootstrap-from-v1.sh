#!/usr/bin/env bash
# Optional: refresh carried-forward components (agents, memory-router, unchanged
# lint scripts, base commands, corpus docs) FROM a v1 portable checkout. v3 ships
# with these already included; use this only to re-sync from a newer v1.
# Never modifies v1.
set -eu
V1="${1:?usage: bootstrap-from-v1.sh /path/to/flawless-portable-vX}"
cd "$(dirname "$0")"
cp "$V1"/.claude/agents/*.md .claude/agents/
cp -r "$V1"/infra/memory-router/* infra/memory-router/
for s in phase_policy_gate.py precommit-ship-gate.sh check-finding-folder.sh stop-padding-check.sh; do
  cp "$V1/pipeline/lint/$s" pipeline/lint/ 2>/dev/null || true
done
for c in intake discover analyze poc validate ship close status flawless INDEX; do
  cp "$V1/.claude/commands/$c.md" .claude/commands/ 2>/dev/null || true
done
echo "re-synced from $V1 (v3-specific files untouched)"
