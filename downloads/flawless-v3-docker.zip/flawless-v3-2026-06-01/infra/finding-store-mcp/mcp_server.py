#!/usr/bin/env python3
"""
Flawless Finding Store (v3) — MCP server (FastMCP over the CRUD logic in server.py).

Run by Claude Code via .mcp.json. Exposes 9 tools (v1 had 5):
  finding_create, finding_update, finding_get, finding_list_by_state, finding_query,
  finding_record_verdict (NEW), finding_record_outcome (NEW),
  finding_verdict_stats (NEW)

The +3 v3 tools close the loop v1 left open: verdicts and vendor outcomes are now
persisted and queryable, and confirm/refute rates are computable per pattern.
"""

import sys
from pathlib import Path
from typing import Optional

sys.path.insert(0, str(Path(__file__).parent))
import server as store  # noqa: E402

from mcp.server.fastmcp import FastMCP  # noqa: E402

store.init_db()
mcp = FastMCP("flawless-finding-store")


@mcp.tool()
def finding_create(target: str, seam: str, patterns: list, b_r_g: dict) -> dict:
    """Create a new finding in DISCOVERED state. Returns the finding record."""
    return store.finding_create(target, seam, patterns, b_r_g)


@mcp.tool()
def finding_update(finding_id: str, state_transition: str,
                   artifacts: Optional[dict] = None, reason: Optional[str] = None) -> dict:
    """Transition a finding's state (e.g. 'CANDIDATE→VALIDATED'). v3: pass `reason` to record WHY the transition happened."""
    return store.finding_update(finding_id, state_transition, artifacts, reason)


@mcp.tool()
def finding_record_verdict(finding_id: str, pattern: str, verdict: str,
                           confidence: Optional[float] = None,
                           skill_used: Optional[str] = None,
                           notes: Optional[str] = None) -> dict:
    """v3: record a checker/verifier verdict (CONFIRMED|REFUTED) + confidence + which Claude-Red skill primed it. Call once per candidate after the verifier runs."""
    return store.finding_record_verdict(finding_id, pattern, verdict, confidence, skill_used, notes)


@mcp.tool()
def finding_record_outcome(finding_id: str, disposition: str,
                           vendor_severity: Optional[str] = None,
                           cve: Optional[str] = None, channel: Optional[str] = None,
                           note: Optional[str] = None) -> dict:
    """v3: record the vendor's verdict (accepted|rejected|duplicate|wontfix|pending) — the ground-truth label. Called by /outcome when a disclosure resolves."""
    return store.finding_record_outcome(finding_id, disposition, vendor_severity, cve, channel, note)


@mcp.tool()
def finding_get(finding_id: str) -> dict:
    """Get one finding by id with state history (incl. reasons), verdicts (incl. skill_used), artifacts, and outcomes."""
    return store.finding_get(finding_id)


@mcp.tool()
def finding_list_by_state(state: str) -> list:
    """List findings in a state: DISCOVERED, CANDIDATE, POC-READY, VALIDATED, SHIPPED, DEFENDED, DEAD-END."""
    return store.finding_list_by_state(state)


@mcp.tool()
def finding_query(target: Optional[str] = None, state: Optional[str] = None,
                  pattern: Optional[str] = None) -> list:
    """Query findings by any of: target, state, pattern (P1..P9)."""
    return store.finding_query(target, state, pattern)


@mcp.tool()
def finding_verdict_stats(pattern: Optional[str] = None) -> dict:
    """v3: confirm/refute counts and confirm_rate per pattern — the calibration readout. >0.85 may be rubber-stamping; <0.60 may be too loose."""
    return store.finding_verdict_stats(pattern)


if __name__ == "__main__":
    mcp.run()
