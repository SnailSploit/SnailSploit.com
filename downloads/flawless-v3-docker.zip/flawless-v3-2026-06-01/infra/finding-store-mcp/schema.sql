-- Flawless Finding Store Schema (v3)
-- v3 deltas vs v1:
--   finding_states.transition_reason  is now WRITTEN (v1 left it NULL)
--   finding_patterns.skill_used        new column — which Claude-Red skill primed the verdict
--   finding_patterns is now WRITTEN by finding_record_verdict (v1 never wrote it)

CREATE TABLE IF NOT EXISTS findings (
    id TEXT PRIMARY KEY,
    target TEXT NOT NULL,
    seam TEXT NOT NULL,
    state TEXT NOT NULL DEFAULT 'DISCOVERED',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    b_r_g_json TEXT,
    patterns_json TEXT,
    artifacts_json TEXT,
    metadata_json TEXT
);

CREATE TABLE IF NOT EXISTS finding_states (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    finding_id TEXT NOT NULL,
    from_state TEXT,
    to_state TEXT NOT NULL,
    timestamp TEXT NOT NULL,
    transition_reason TEXT,
    FOREIGN KEY (finding_id) REFERENCES findings(id)
);

CREATE TABLE IF NOT EXISTS finding_patterns (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    finding_id TEXT NOT NULL,
    pattern_name TEXT NOT NULL,
    verdict TEXT,
    confidence REAL,
    skill_used TEXT,
    notes TEXT,
    timestamp TEXT NOT NULL,
    FOREIGN KEY (finding_id) REFERENCES findings(id)
);

CREATE TABLE IF NOT EXISTS finding_artifacts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    finding_id TEXT NOT NULL,
    artifact_type TEXT NOT NULL,
    artifact_path TEXT NOT NULL,
    created_at TEXT NOT NULL,
    metadata_json TEXT,
    FOREIGN KEY (finding_id) REFERENCES findings(id)
);

-- v3: outcomes table — the ground-truth loop. /outcome writes the vendor verdict here.
CREATE TABLE IF NOT EXISTS finding_outcomes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    finding_id TEXT NOT NULL,
    disposition TEXT NOT NULL,       -- accepted | rejected | duplicate | wontfix | pending
    vendor_severity TEXT,
    cve TEXT,
    channel TEXT,
    note TEXT,
    timestamp TEXT NOT NULL,
    FOREIGN KEY (finding_id) REFERENCES findings(id)
);

CREATE INDEX IF NOT EXISTS idx_findings_target ON findings(target);
CREATE INDEX IF NOT EXISTS idx_findings_state ON findings(state);
CREATE INDEX IF NOT EXISTS idx_findings_seam ON findings(seam);
CREATE INDEX IF NOT EXISTS idx_finding_states_finding_id ON finding_states(finding_id);
CREATE INDEX IF NOT EXISTS idx_finding_patterns_finding_id ON finding_patterns(finding_id);
CREATE INDEX IF NOT EXISTS idx_finding_patterns_verdict ON finding_patterns(verdict);
CREATE INDEX IF NOT EXISTS idx_finding_artifacts_finding_id ON finding_artifacts(finding_id);
CREATE INDEX IF NOT EXISTS idx_finding_outcomes_finding_id ON finding_outcomes(finding_id);
CREATE INDEX IF NOT EXISTS idx_finding_outcomes_disposition ON finding_outcomes(disposition);
