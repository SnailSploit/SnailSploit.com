#!/usr/bin/env python3
"""
Flawless Finding Store (v3) — CRUD + state machine over SQLite.

v3 deltas vs v1 (the dead-wiring fixes):
  - finding_update now accepts `reason` and writes finding_states.transition_reason
  - finding_record_verdict (NEW) writes finding_patterns: pattern, verdict,
    confidence, skill_used, notes  (v1 computed verdicts and threw them away)
  - finding_record_outcome (NEW) writes finding_outcomes: the vendor verdict,
    closing the ground-truth loop
  - finding_verdict_stats (NEW) — confirm/refute counts per pattern, the
    calibration readout v1 had no way to produce

The MCP harness (mcp_server.py) wraps these. They are import-safe and need no
MCP runtime, so verify.sh exercises them directly.
"""

import json
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Optional


def get_db_path():
    pipeline_dir = Path(__file__).parent.parent.parent / "pipeline"
    pipeline_dir.mkdir(exist_ok=True)
    return pipeline_dir / "findings.db"


def init_db():
    conn = sqlite3.connect(get_db_path())
    with open(Path(__file__).parent / "schema.sql") as f:
        conn.executescript(f.read())
    conn.commit()
    conn.close()


def finding_create(target: str, seam: str, patterns: list, b_r_g: dict) -> dict:
    finding_id = f"{target}-{seam.replace(' ', '-')}-{datetime.now().strftime('%Y%m%d%H%M%S')}"
    now = datetime.now().isoformat()
    conn = sqlite3.connect(get_db_path())
    conn.execute(
        """INSERT INTO findings (id, target, seam, state, created_at, updated_at, b_r_g_json, patterns_json)
           VALUES (?, ?, ?, 'DISCOVERED', ?, ?, ?, ?)""",
        (finding_id, target, seam, now, now, json.dumps(b_r_g), json.dumps(patterns)),
    )
    conn.commit()
    conn.close()
    return {"id": finding_id, "target": target, "seam": seam,
            "state": "DISCOVERED", "patterns": patterns, "created_at": now}


def finding_update(finding_id: str, state_transition: str,
                   artifacts: Optional[dict] = None, reason: Optional[str] = None) -> dict:
    """Transition state. v3: `reason` is persisted to finding_states.transition_reason."""
    now = datetime.now().isoformat()
    from_state, to_state = state_transition.split("→")
    conn = sqlite3.connect(get_db_path())
    conn.execute(
        """INSERT INTO finding_states (finding_id, from_state, to_state, timestamp, transition_reason)
           VALUES (?, ?, ?, ?, ?)""",
        (finding_id, from_state, to_state, now, reason),
    )
    conn.execute("UPDATE findings SET state = ?, updated_at = ? WHERE id = ?",
                 (to_state, now, finding_id))
    if artifacts:
        for atype, apath in artifacts.items():
            conn.execute(
                """INSERT INTO finding_artifacts (finding_id, artifact_type, artifact_path, created_at)
                   VALUES (?, ?, ?, ?)""",
                (finding_id, atype, apath, now),
            )
    conn.commit()
    row = conn.execute("SELECT id, target, seam, state FROM findings WHERE id = ?",
                       (finding_id,)).fetchone()
    conn.close()
    if not row:
        return {"error": f"Finding {finding_id} not found"}
    return {"id": row[0], "target": row[1], "seam": row[2],
            "state": row[3], "updated_at": now, "reason": reason}


def finding_record_verdict(finding_id: str, pattern: str, verdict: str,
                           confidence: Optional[float] = None,
                           skill_used: Optional[str] = None,
                           notes: Optional[str] = None) -> dict:
    """v3 NEW: persist a checker/verifier verdict. This is the signal v1 discarded.

    verdict   : CONFIRMED | REFUTED
    skill_used: the Claude-Red skill that primed the analysis, if any
    """
    now = datetime.now().isoformat()
    conn = sqlite3.connect(get_db_path())
    conn.execute(
        """INSERT INTO finding_patterns
           (finding_id, pattern_name, verdict, confidence, skill_used, notes, timestamp)
           VALUES (?, ?, ?, ?, ?, ?, ?)""",
        (finding_id, pattern, verdict, confidence, skill_used, notes, now),
    )
    conn.commit()
    conn.close()
    return {"finding_id": finding_id, "pattern": pattern, "verdict": verdict,
            "confidence": confidence, "skill_used": skill_used, "recorded_at": now}


def finding_record_outcome(finding_id: str, disposition: str,
                           vendor_severity: Optional[str] = None,
                           cve: Optional[str] = None, channel: Optional[str] = None,
                           note: Optional[str] = None) -> dict:
    """v3 NEW: the ground-truth loop. /outcome writes the vendor verdict here.

    disposition: accepted | rejected | duplicate | wontfix | pending
    """
    now = datetime.now().isoformat()
    conn = sqlite3.connect(get_db_path())
    conn.execute(
        """INSERT INTO finding_outcomes
           (finding_id, disposition, vendor_severity, cve, channel, note, timestamp)
           VALUES (?, ?, ?, ?, ?, ?, ?)""",
        (finding_id, disposition, vendor_severity, cve, channel, note, now),
    )
    conn.commit()
    conn.close()
    return {"finding_id": finding_id, "disposition": disposition,
            "cve": cve, "recorded_at": now}


def finding_get(finding_id: str) -> dict:
    conn = sqlite3.connect(get_db_path())
    row = conn.execute(
        "SELECT id, target, seam, state, created_at, updated_at, b_r_g_json, patterns_json FROM findings WHERE id = ?",
        (finding_id,)).fetchone()
    if not row:
        conn.close()
        return {"error": f"Finding {finding_id} not found"}
    states = conn.execute(
        "SELECT from_state, to_state, timestamp, transition_reason FROM finding_states WHERE finding_id = ? ORDER BY timestamp",
        (finding_id,)).fetchall()
    verdicts = conn.execute(
        "SELECT pattern_name, verdict, confidence, skill_used, notes FROM finding_patterns WHERE finding_id = ? ORDER BY timestamp",
        (finding_id,)).fetchall()
    artifacts = conn.execute(
        "SELECT artifact_type, artifact_path FROM finding_artifacts WHERE finding_id = ?",
        (finding_id,)).fetchall()
    outcomes = conn.execute(
        "SELECT disposition, vendor_severity, cve, channel, note, timestamp FROM finding_outcomes WHERE finding_id = ? ORDER BY timestamp",
        (finding_id,)).fetchall()
    conn.close()
    return {
        "id": row[0], "target": row[1], "seam": row[2], "state": row[3],
        "created_at": row[4], "updated_at": row[5],
        "b_r_g": json.loads(row[6]) if row[6] else {},
        "patterns": json.loads(row[7]) if row[7] else [],
        "state_history": [{"from": s[0], "to": s[1], "at": s[2], "reason": s[3]} for s in states],
        "verdicts": [{"pattern": v[0], "verdict": v[1], "confidence": v[2],
                      "skill_used": v[3], "notes": v[4]} for v in verdicts],
        "artifacts": {a[0]: a[1] for a in artifacts},
        "outcomes": [{"disposition": o[0], "vendor_severity": o[1], "cve": o[2],
                      "channel": o[3], "note": o[4], "at": o[5]} for o in outcomes],
    }


def finding_list_by_state(state: str) -> list:
    conn = sqlite3.connect(get_db_path())
    rows = conn.execute(
        "SELECT id, target, seam, state, created_at FROM findings WHERE state = ? ORDER BY created_at DESC",
        (state,)).fetchall()
    conn.close()
    return [{"id": r[0], "target": r[1], "seam": r[2], "state": r[3], "created_at": r[4]} for r in rows]


def finding_query(target: Optional[str] = None, state: Optional[str] = None,
                  pattern: Optional[str] = None) -> list:
    conn = sqlite3.connect(get_db_path())
    if target and state:
        q = "SELECT id, target, seam, state, created_at FROM findings WHERE target = ? AND state = ? ORDER BY created_at DESC"
        params = (target, state)
    elif target:
        q = "SELECT id, target, seam, state, created_at FROM findings WHERE target = ? ORDER BY created_at DESC"
        params = (target,)
    elif state:
        q = "SELECT id, target, seam, state, created_at FROM findings WHERE state = ? ORDER BY created_at DESC"
        params = (state,)
    else:
        q = "SELECT id, target, seam, state, created_at FROM findings ORDER BY created_at DESC"
        params = ()
    rows = conn.execute(q, params).fetchall()
    results = []
    for r in rows:
        rec = {"id": r[0], "target": r[1], "seam": r[2], "state": r[3], "created_at": r[4]}
        if pattern:
            pr = conn.execute("SELECT patterns_json FROM findings WHERE id = ?", (r[0],)).fetchone()
            if pr and pattern in json.loads(pr[0] or "[]"):
                results.append(rec)
        else:
            results.append(rec)
    conn.close()
    return results


def finding_verdict_stats(pattern: Optional[str] = None) -> dict:
    """v3 NEW: calibration readout — confirm/refute counts per pattern.

    This is the metric v1 could not produce because verdicts were never stored.
    A pattern confirming at >85% may be rubber-stamping; <60% may be too loose.
    """
    conn = sqlite3.connect(get_db_path())
    if pattern:
        rows = conn.execute(
            "SELECT pattern_name, verdict, COUNT(*) FROM finding_patterns WHERE pattern_name = ? GROUP BY pattern_name, verdict",
            (pattern,)).fetchall()
    else:
        rows = conn.execute(
            "SELECT pattern_name, verdict, COUNT(*) FROM finding_patterns GROUP BY pattern_name, verdict").fetchall()
    conn.close()
    agg = {}
    for name, verdict, n in rows:
        agg.setdefault(name, {"CONFIRMED": 0, "REFUTED": 0})
        if verdict in ("CONFIRMED", "REFUTED"):
            agg[name][verdict] += n
    for name, d in agg.items():
        total = d["CONFIRMED"] + d["REFUTED"]
        d["confirm_rate"] = round(d["CONFIRMED"] / total, 3) if total else None
        d["total"] = total
    return agg


def main():
    init_db()
    print("Finding Store (v3) initialized at", get_db_path())


if __name__ == "__main__":
    main()
