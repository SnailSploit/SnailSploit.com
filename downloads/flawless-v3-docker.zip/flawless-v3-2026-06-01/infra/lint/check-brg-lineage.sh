#!/usr/bin/env bash
# check-brg-lineage.sh — verify BRG lineage chain from seam-map through validation.
# Every candidate must trace back to a SEAM-ID in brg.md.
# Chain: seam-map.md -> brg.md -> candidates.md -> run-log.md -> validation-report.md
set -euo pipefail

FAIL=0
note() { echo "  [lineage] $*" >&2; FAIL=1; }
pass() { echo "  [lineage] $*"; }

if [ $# -lt 1 ]; then
    echo "usage: $0 <finding-folder>" >&2
    exit 2
fi

DIR="$1"

# Extract SEAM-IDs from brg.md
if [ ! -f "$DIR/brg.md" ]; then
    note "missing brg.md — no lineage possible"
    exit 1
fi

seam_ids=$(grep -oE 'Seam[- ][0-9]+|SEAM[- ][0-9]+|seam[_-][0-9]+' "$DIR/brg.md" | sort -u || true)
if [ -z "$seam_ids" ]; then
    note "brg.md contains no identifiable SEAM-IDs"
    exit 1
fi
pass "brg.md contains $(echo "$seam_ids" | wc -l) SEAM-IDs"

# Check candidates.md cites at least one SEAM-ID from brg.md
if [ -f "$DIR/analysis/candidates.md" ]; then
    found=0
    while IFS= read -r sid; do
        if grep -qi "$sid" "$DIR/analysis/candidates.md" 2>/dev/null; then
            found=1
            break
        fi
    done <<< "$seam_ids"
    if [ "$found" -eq 1 ]; then
        pass "candidates.md traces to brg.md SEAM-ID"
    else
        note "candidates.md does not cite any SEAM-ID from brg.md"
    fi
fi

# Check run-log cites a SEAM-ID
for rl in "$DIR/poc/run-log.md" "$DIR/poc/run-log.txt"; do
    if [ -f "$rl" ]; then
        found=0
        while IFS= read -r sid; do
            if grep -qi "$sid" "$rl" 2>/dev/null; then
                found=1; break
            fi
        done <<< "$seam_ids"
        if [ "$found" -eq 1 ]; then
            pass "$(basename "$rl") traces to brg.md SEAM-ID"
        else
            note "$(basename "$rl") does not cite any SEAM-ID from brg.md"
        fi
        break
    fi
done

# Check validation-report.md
if [ -f "$DIR/validation-report.md" ]; then
    found=0
    while IFS= read -r sid; do
        if grep -qi "$sid" "$DIR/validation-report.md" 2>/dev/null; then
            found=1; break
        fi
    done <<< "$seam_ids"
    if [ "$found" -eq 1 ]; then
        pass "validation-report.md traces to brg.md SEAM-ID"
    else
        note "validation-report.md does not cite any SEAM-ID from brg.md"
    fi
fi

if [ "$FAIL" -eq 0 ]; then
    echo "lineage: $DIR -> clean chain"
fi
exit $FAIL
