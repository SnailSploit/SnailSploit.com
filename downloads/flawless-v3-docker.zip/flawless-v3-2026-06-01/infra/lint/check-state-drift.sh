#!/usr/bin/env bash
# check-state-drift.sh — detect deprecated or unknown state names across docs/config.
# Canonical states: DISCOVERED, CANDIDATE, POC-READY, VALIDATED, SHIPPED, CLOSED, DEAD-END, STOP, BLOCKED
set -euo pipefail

CANONICAL="DISCOVERED|CANDIDATE|POC-READY|VALIDATED|SHIPPED|CLOSED|DEAD-END|STOP|BLOCKED"

# Legacy/deprecated terms that should not appear in current docs
DEPRECATED="READY-TO-SHIP|feasibility|LEGEND|READY_TO_SHIP"

FAIL=0
note() { echo "  [drift] $*" >&2; FAIL=1; }

FILES=(
    CLAUDE.md
    README.md
    .claude/commands/*.md
    .claude/policy.yaml
    pipeline/lint/*.sh
)

echo "state-drift: scanning for deprecated state names..."
for f in ${FILES[@]}; do
    [ -f "$f" ] || continue
    hits=$(grep -Eon "\b($DEPRECATED)\b" "$f" 2>/dev/null || true)
    if [ -n "$hits" ]; then
        while IFS= read -r line; do
            note "$f: $line"
        done <<< "$hits"
    fi
done

if [ "$FAIL" -eq 0 ]; then
    echo "state-drift: clean — no deprecated state names found"
fi
exit $FAIL
