#!/usr/bin/env bash
# Flawless v3 — checker-count drift guard.
# Disk (the pattern-*-checker.md files) is the single source of truth.
set -u
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
AGENTS="$ROOT/.claude/agents"
N=$(ls "$AGENTS"/pattern-*-checker.md 2>/dev/null | wc -l | tr -d ' ')
rc=0
echo "checkers on disk: $N"
[ "$N" -ge 1 ] || { echo "  [FAIL] no pattern-*-checker.md files in $AGENTS"; exit 1; }

# Scan these files for count consistency
FILES=(
    "$ROOT/.claude/commands/analyze.md"
    "$ROOT/.claude/commands/INDEX.md"
    "$ROOT/CLAUDE.md"
    "$ROOT/README.md"
)

for f in "${FILES[@]}"; do
    [ -f "$f" ] || continue
    bn=$(basename "$f")
    if grep -Eq "\b$N\b" "$f"; then
        echo "  [ ok ] $bn references $N"
    else
        echo "  [warn] $bn may not reference $N checkers (disk has $N)"
        # Only fail on analyze.md (the dispatch source)
        [ "$bn" = "analyze.md" ] && rc=1
    fi
done

# Fail on known stale claims
for f in "${FILES[@]}"; do
    [ -f "$f" ] || continue
    if grep -qiE 'there is no M11|\b14 checker|\b9 conceptual' "$f" 2>/dev/null; then
        echo "  [FAIL] $(basename "$f") contains a stale count claim (no M11 / 14 checkers / 9 conceptual)"
        rc=1
    fi
done
exit $rc
