#!/usr/bin/env bash
# Flawless v3 — semantic prior-art gate. Wraps memory-router's contradict.py
# (which exists in v1 but was never wired). Run before promoting a finding to
# CANDIDATE: if the gap semantically matches a recorded dead-end or a
# marked-clean surface, stop and reconcile.
#
# Usage: contradiction_gate.sh <finding-folder>   (expects <folder>/BRG.md)
# Exit:  0 clear · 1 contradiction (reconcile or DEAD-END) · 2 index stale/missing (warn, do not block)
set -u
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
PY="$ROOT/infra/.venv/bin/python"; [ -x "$PY" ] || PY=python3
CONTRADICT="$ROOT/infra/memory-router/backends/vector/contradict.py"
DIR="${1:-}"
[ -n "$DIR" ] || { echo "usage: $0 <finding-folder>"; exit 2; }
BRG="$DIR/BRG.md"
[ -f "$BRG" ] || { echo "  [warn] no BRG.md at $BRG — nothing to check"; exit 0; }
[ -f "$CONTRADICT" ] || { echo "  [warn] contradict.py not present (bootstrap memory-router from v1); skipping"; exit 2; }

"$PY" "$CONTRADICT" --file "$BRG" -k 6
rc=$?
case $rc in
  0) echo "  [ ok ] no semantic contradiction — clear to CANDIDATE";;
  1) echo "  [STOP] gap matches a dead-end / marked-clean surface — reconcile (add reopen evidence) or /close DEAD-END";;
  2) echo "  [warn] semantic index missing/stale — run build.py, treating as non-blocking";;
esac
exit $rc
