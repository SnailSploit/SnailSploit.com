#!/usr/bin/env python3
"""
Flawless Skill Router (v3 NEW) — MCP server (FastMCP over server.py).

Run by Claude Code via .mcp.json. Bridges FLAWLESS to Claude-Red (or any
SKILL.md library under CLAUDE_SKILLS_DIR). Tools:
  skill_match   — router picks: rank skills matching a pattern + B/R/G
  skill_get     — agent picks: pull a skill body by exact name
  skill_list    — enumerate discovered skills
  router_status — roots + count + Claude-Red presence

Skills still load natively by description-match; this server makes the match
deterministic, auditable (provenance), and gives the agent an explicit pull
path when it already knows the skill name.
"""

import sys
from pathlib import Path
from typing import Optional

sys.path.insert(0, str(Path(__file__).parent))
import server as router  # noqa: E402

from mcp.server.fastmcp import FastMCP  # noqa: E402

mcp = FastMCP("flawless-skill-router")


@mcp.tool()
def skill_match(pattern: Optional[str] = None, brg: str = "", k: int = 3) -> list:
    """Rank skills whose description matches a gap. Pass a FLAWLESS pattern (P1..P9) and/or Belief/Reality/Gap text. Returns ranked {name, score, description, path}. Logged to provenance."""
    return router.skill_match(pattern, brg, k)


@mcp.tool()
def skill_get(name: str) -> dict:
    """Pull a skill's full SKILL.md body by exact name — the deterministic path when you already know which skill you want. Logged to provenance."""
    return router.skill_get(name)


@mcp.tool()
def skill_list() -> list:
    """List every discovered skill {name, description, path} under the configured roots (CLAUDE_SKILLS_DIR, ~/.claude/skills, ./.claude/skills)."""
    return router.skill_list()


@mcp.tool()
def router_status() -> dict:
    """Report skill roots, count discovered, and whether a Claude-Red library is present."""
    return router.router_status()


if __name__ == "__main__":
    mcp.run()
