#!/usr/bin/env python3
"""
Flawless Skill Router (v3 NEW) — discover and match SKILL.md skills for a seam.

The bridge between FLAWLESS and Claude-Red. It does NOT replace Claude Code's
native description-match loading; it sharpens and audits it:

  - skill_match(pattern, brg, k)  : rank skills whose frontmatter description
                                     matches the gap. The router PICKS.
  - skill_get(name)               : return a skill's SKILL.md body by name.
                                     The AGENT PICKS — the deterministic pull
                                     path for "call a specific skill if needed".
  - skill_list()                  : enumerate every discovered skill.

Every skill_match / skill_get call appends one line to pipeline/provenance.jsonl,
so "which skill primed this finding" is auditable later.

Discovery is description-driven, not name-hardcoded: it scans every SKILL.md
under the configured roots and reads (name, description) from YAML frontmatter.
Point it at Claude-Red and it indexes whatever 38 skills are there today — and
whatever you add tomorrow — with no code change.

Roots, in order:
  $CLAUDE_SKILLS_DIR (if set), ~/.claude/skills, ./.claude/skills
"""

import hashlib
import json
import os
import re
from datetime import datetime
from pathlib import Path
from typing import Optional


# Pattern → seed terms. Boosts matching for FLAWLESS's P1–P9 taxonomy so a
# bare pattern id still routes well even before B/R/G text is added. NOT a
# hardcoded skill list — just query expansion.
PATTERN_SEEDS = {
    "P1": "invariant validation bypass authorization access control missing check",
    "P2": "parsing differential decode normalization url path smuggling oracle",
    "P3": "toctou race condition time of check window concurrency async",
    "P4": "cache database dual store stale read consistency desync",
    "P5": "incomplete fix patch bypass sibling backport regression variant",
    "P6": "error handling semantic divergence fallback recovery lenient",
    "P7": "deserialization pickle yaml unsafe gadget rce object injection",
    "P8": "crypto misuse jwt signature constant time iv ecb algorithm confusion",
    "P9": "sandbox escape vm isolate ast evaluator prototype host realm",
}

FRONTMATTER_RE = re.compile(r"^---\s*\n(.*?)\n---\s*\n", re.DOTALL)


def _roots():
    out = []
    env = os.environ.get("CLAUDE_SKILLS_DIR")
    if env:
        out.append(Path(env).expanduser())
    out.append(Path("~/.claude/skills").expanduser())
    out.append(Path(".claude/skills"))
    seen, uniq = set(), []
    for r in out:
        rp = r.resolve()
        if rp not in seen and rp.exists():
            seen.add(rp)
            uniq.append(rp)
    return uniq


def _parse_frontmatter(text: str) -> dict:
    m = FRONTMATTER_RE.match(text)
    if not m:
        return {}
    block, out, key = m.group(1), {}, None
    for line in block.splitlines():
        fm = re.match(r"^([A-Za-z0-9_-]+):\s*(.*)$", line)
        if fm:
            key = fm.group(1).strip()
            out[key] = fm.group(2).strip()
        elif key and line.strip():
            out[key] = (out.get(key, "") + " " + line.strip()).strip()
    return out


def _discover() -> list:
    skills = []
    for root in _roots():
        for p in root.rglob("SKILL.md"):
            try:
                text = p.read_text(encoding="utf-8", errors="replace")
            except Exception:
                continue
            fm = _parse_frontmatter(text)
            name = fm.get("name") or p.parent.name
            desc = fm.get("description", "")
            body = FRONTMATTER_RE.sub("", text, count=1)
            skills.append({"name": name, "description": desc,
                           "path": str(p), "body": body})
    # de-dup by name, first root wins
    seen, uniq = set(), []
    for s in skills:
        if s["name"] in seen:
            continue
        seen.add(s["name"])
        uniq.append(s)
    return uniq


def _tokens(s: str) -> set:
    return set(re.findall(r"[a-z0-9]{3,}", (s or "").lower()))


def _provenance(event: str, payload: dict):
    log = Path("pipeline/provenance.jsonl")
    try:
        log.parent.mkdir(parents=True, exist_ok=True)
        rec = {"timestamp": datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"),
               "tool": f"skill-router.{event}",
               "input_hash": hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()[:8]}
        with log.open("a", encoding="utf-8") as f:
            f.write(json.dumps(rec) + "\n")
    except Exception:
        pass


def skill_list() -> list:
    return [{"name": s["name"], "description": s["description"][:200], "path": s["path"]}
            for s in _discover()]


def skill_match(pattern: Optional[str] = None, brg: str = "", k: int = 3) -> list:
    """Rank skills by description overlap with (pattern seeds + B/R/G text)."""
    query = " ".join(filter(None, [PATTERN_SEEDS.get((pattern or "").upper(), ""), brg]))
    qt = _tokens(query)
    if not qt:
        return [{"error": "empty query — supply a pattern (P1..P9) or B/R/G text"}]
    scored = []
    for s in _discover():
        dt = _tokens(s["description"]) | _tokens(s["name"])
        if not dt:
            continue
        overlap = len(qt & dt)
        if overlap == 0:
            continue
        score = overlap / (len(qt) ** 0.5)
        scored.append({"name": s["name"], "score": round(score, 3),
                       "description": s["description"][:200], "path": s["path"]})
    scored.sort(key=lambda x: -x["score"])
    out = scored[:max(1, k)]
    _provenance("match", {"pattern": pattern, "k": k, "returned": [o["name"] for o in out]})
    return out or [{"note": "no skill matched — proceed with the checker prompt alone"}]


def skill_get(name: str) -> dict:
    """Return a skill's SKILL.md body by exact name. The deterministic pull path."""
    for s in _discover():
        if s["name"] == name:
            _provenance("get", {"name": name})
            return {"name": s["name"], "description": s["description"],
                    "path": s["path"], "body": s["body"]}
    return {"error": f"skill '{name}' not found under {[str(r) for r in _roots()]}"}


def router_status() -> dict:
    roots = [str(r) for r in _roots()]
    n = len(_discover())
    return {"roots": roots, "skills_discovered": n,
            "claude_red_present": any("claude-red" in r.lower() or "claude_red" in r.lower() for r in roots) or n > 0}


def main():
    st = router_status()
    print(f"Skill Router (v3) — roots {st['roots']}; discovered {st['skills_discovered']} skills")


if __name__ == "__main__":
    main()
