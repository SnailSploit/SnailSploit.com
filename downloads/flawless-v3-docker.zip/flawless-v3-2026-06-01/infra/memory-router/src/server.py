#!/usr/bin/env python3
"""
Flawless Memory Router — semantic / episodic / working memory scopes.

Wraps the real vector backend (backends/vector/{build,recall,contradict}.py).
The MCP harness (../mcp_server.py) exposes query/write/recall/check_dead_end.

Scopes:
  working   — in-process dict, always live, no backend.
  semantic  — cosine search over the corpus index built from
              LEDGER / METHODOLOGIES / DEAD-ENDS / SHIPPED markdown.
              Live once `build.py` has produced data/embeddings.npy.
              Read-only: it is a derived artefact; rebuild from sources.
  episodic  — session-history index; not built yet (honest: reports unavailable).

Degrades gracefully: missing fastembed or an unbuilt index never crashes the
server; the affected scope returns an actionable error instead.
"""

import sys
from pathlib import Path
from typing import Optional, Dict, Any, List

# Vector backend lives in a sibling directory.
sys.path.insert(0, str(Path(__file__).parent.parent / "backends" / "vector"))

try:
    import numpy as np
    import recall as _recall      # load_index(), embed_query()
    import build as _build        # corpus builder (index status / rebuild)
    try:
        import contradict as _contradict
    except Exception:
        _contradict = None
    _BACKEND_OK = True
    _BACKEND_ERR = None
except Exception as e:  # fastembed/numpy missing, etc.
    np = None
    _recall = _build = _contradict = None
    _BACKEND_OK = False
    _BACKEND_ERR = str(e)
    print(f"Warning: vector backend unavailable: {e}", file=sys.stderr)


class MemoryRouter:
    """Routes memory queries/writes across semantic, episodic, working scopes."""

    SCOPES = ["semantic", "episodic", "working"]

    def __init__(self):
        self.working_memory: Dict[str, str] = {}   # in-session only
        self.session_id = None
        self._index = None                          # cached (vecs, meta)
        # Truthy marker if the semantic corpus index is on disk and usable.
        self.semantic_index = "ready" if self._semantic_available() else None
        self.episodic_index = None                  # not built

    # ---- backend helpers -------------------------------------------------
    def _semantic_available(self) -> bool:
        return bool(
            _BACKEND_OK
            and _recall is not None
            and _recall.EMB_PATH.exists()
            and _recall.META_PATH.exists()
        )

    def _load(self):
        if self._index is None:
            self._index = _recall.load_index()
        return self._index

    # ---- tools -----------------------------------------------------------
    def query(self, scope: str, query_text: str, k: int = 5) -> List[Dict[str, Any]]:
        """Query memory by scope. Returns up to k relevant memories."""
        if scope not in self.SCOPES:
            return [{"error": f"Invalid scope: {scope}. Use one of {self.SCOPES}"}]

        if scope == "working":
            matches = [
                {"id": mid, "content": c, "score": 1.0}
                for mid, c in self.working_memory.items()
                if query_text.lower() in c.lower()
            ]
            return matches[:k]

        if scope == "episodic":
            return [{"error": "episodic index not built (only the semantic corpus index exists)."}]

        # semantic
        if not self._semantic_available():
            if not _BACKEND_OK:
                return [{"error": f"semantic backend unavailable: {_BACKEND_ERR}. "
                                  f"pip install fastembed numpy into infra/.venv."}]
            return [{"error": "semantic index not built. Run: "
                              "infra/.venv/bin/python infra/memory-router/backends/vector/build.py"}]

        vecs, meta = self._load()
        q = _recall.embed_query(query_text)
        scores = vecs @ q  # both L2-normalised -> cosine
        k = max(1, min(k, len(meta)))
        top = np.argpartition(-scores, k - 1)[:k]
        top = top[np.argsort(-scores[top])]
        return [
            {
                "id": meta[int(i)].get("id") or meta[int(i)].get("anchor"),
                "source": meta[int(i)].get("source"),
                "anchor": meta[int(i)].get("anchor"),
                "score": float(scores[int(i)]),
                "content": meta[int(i)].get("text", "")[:600],
            }
            for i in top
        ]

    def write(self, scope: str, content: str, metadata: Optional[Dict[str, Any]] = None) -> Dict[str, str]:
        """Write to memory. Returns memory_id (working scope) or guidance (derived scopes)."""
        if scope not in self.SCOPES:
            return {"error": f"Invalid scope: {scope}"}

        if scope == "working":
            import uuid
            from datetime import datetime
            mid = f"working-{uuid.uuid4().hex[:8]}"
            self.working_memory[mid] = content
            return {"id": mid, "scope": "working", "timestamp": datetime.now().isoformat()}

        # semantic/episodic are derived artefacts, not write targets.
        return {"error": f"scope '{scope}' is read-only (derived from markdown sources). "
                         f"Edit the source docs and rebuild with build.py; use scope 'working' "
                         f"for session-local notes."}

    def recall(self, session_id: str) -> Dict[str, Any]:
        """Recall episodic context for a session. Episodic index is not built yet."""
        return {
            "session_id": session_id,
            "working_memories": len(self.working_memory),
            "note": "episodic index not built; only working-scope session memory is available.",
        }

    def check_dead_end(self, hypothesis: str) -> Dict[str, Any]:
        """Check whether a hypothesis conflicts with recorded DEAD-ENDS (semantic backend)."""
        if not self._semantic_available():
            return {"checked": False, "reason": "semantic index not built; run build.py"}
        try:
            vecs, meta = self._load()
            q = _recall.embed_query(hypothesis)
            scores = vecs @ q
            top = int(np.argmax(scores))
            row = meta[top]
            is_dead_end = (row.get("source") == "dead-ends") and float(scores[top]) >= 0.80
            return {
                "hypothesis": hypothesis,
                "checked": True,
                "is_dead_end": bool(is_dead_end),
                "closest": {"source": row.get("source"), "anchor": row.get("anchor"),
                            "score": float(scores[top])},
            }
        except Exception as e:
            return {"error": str(e), "checked": False}

    def backend_status(self) -> Dict[str, Any]:
        return {
            "backend_import_ok": _BACKEND_OK,
            "backend_error": _BACKEND_ERR,
            "semantic_index_built": self._semantic_available(),
            "episodic": False,
            "working": True,
            "scopes": self.SCOPES,
        }


def main():
    router = MemoryRouter()
    st = router.backend_status()
    print(f"Memory Router — scopes {router.SCOPES}; semantic index built: {st['semantic_index_built']}; "
          f"backend ok: {st['backend_import_ok']}")


if __name__ == "__main__":
    main()
