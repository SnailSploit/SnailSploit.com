"""Contradiction-check: cross-checks a new finding's seam against the corpus.

A new finding contradicts the corpus if the top-k semantic neighbours fall into
any of these categories:
  - DEAD-ENDS without a recorded reopen-evidence note
  - Surfaces previously tagged as `marked-clean` in LEDGER / METHODOLOGIES

If any hit fires, this script exits 1 and prints the conflicting anchors so
the operator can either:
  - update DEAD-ENDS.md with reopen evidence, or
  - amend the "audited surfaces marked clean" count in STATE.md, or
  - drop the finding (Invariant 6: hypotheses are anchored, dropped not softened).

Run:
  python contradict.py --seam "JWT iss-claim validation in <component>"
  python contradict.py --file pipeline/READY-TO-SHIP/NN-foo/REPORT.md

Exit codes:
  0  no contradictions in top-k
  1  contradictions found (printed)
  2  index missing / inconsistent (see build.py)
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
RECALL = HERE / "recall.py"

CONTRADICTION_TAGS = {"dead-end", "marked-clean"}
DEFAULT_K = 6


def recall(query: str, k: int) -> list[dict]:
    proc = subprocess.run(
        [sys.executable, str(RECALL), query, "-k", str(k)],
        capture_output=True,
        text=True,
        check=False,
    )
    if proc.returncode != 0:
        sys.stderr.write(proc.stderr)
        sys.exit(proc.returncode)
    return [json.loads(ln) for ln in proc.stdout.splitlines() if ln.strip()]


def conflicting(row: dict) -> str | None:
    tags = set(row.get("tags", []))
    if "dead-end" in tags and "reopened" not in tags:
        return "dead-end (no reopen evidence)"
    if "marked-clean" in tags:
        return "previously marked clean"
    return None


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    src = ap.add_mutually_exclusive_group(required=True)
    src.add_argument("--seam", help="one-sentence seam description")
    src.add_argument("--file", type=Path, help="markdown file to extract seam from")
    ap.add_argument("-k", type=int, default=DEFAULT_K)
    args = ap.parse_args()

    if args.file:
        query = args.file.read_text(encoding="utf-8", errors="replace")[:4000]
    else:
        query = args.seam

    hits = recall(query, args.k)
    conflicts = [(h, c) for h in hits if (c := conflicting(h))]

    if not conflicts:
        print(f"OK: no contradictions in top-{args.k}")
        return 0

    print(f"FAIL: {len(conflicts)} contradiction(s) in top-{args.k}")
    for h, why in conflicts:
        print(f"  - {why}: {h['anchor']}  (score={h['score']:.3f})")
        first_line = h["text"].splitlines()[0] if h.get("text") else ""
        if first_line:
            print(f"      {first_line[:120]}")
    print(
        "\nReconcile before shipping (Invariant 6): either update DEAD-ENDS.md "
        "with reopen evidence, amend the marked-clean list, or drop the finding."
    )
    return 1


if __name__ == "__main__":
    sys.exit(main())
