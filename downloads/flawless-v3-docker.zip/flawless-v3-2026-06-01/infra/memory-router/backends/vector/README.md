# Memory Router · vector backend (semantic scope)

Status: **spike** on `claude/vector-index-spike`.

A read-only semantic index over LEGEND's corpus. The git-tracked markdown
remains the source of truth; this directory's output is a derived artefact,
rebuildable at any time.

## Why this exists

Corpus has grown past the point where grep over LEDGER + READY-TO-SHIP catches
cross-vendor structural similarities (empty-key HMAC alone spans 6+ vendor rows
across rubies / node / perl). Three concrete jobs this enables:

1. **Cross-vendor similarity recall.** "Show me prior seams structurally
   similar to this new theory" — a query the existing tooling can't answer.
2. **Contradiction detection.** Before a finding ships, verify its seam is
   not already in DEAD-ENDS without reopen evidence, or on the "audited
   surfaces marked clean" list. See `contradict.py`.
3. **Theory → skill routing.** Given a new theory's prose, nearest-neighbour
   over methodology / class descriptions picks the closest methodology and
   (eventually) the skill the router dispatches to.

## How it fits the architecture

- **Invariant 5 (Memory Router: 3 tools / 3 scopes; backends multiply).**
  This *is* a backend. It exposes no new tools. When the Memory Router MCP
  shell ships (`infra/memory-router/src/`), its `semantic` scope subprocesses
  `recall.py` here. Zero migration.
- **Invariant 2 (no exfiltration).** Embedder is local ONNX (`fastembed` →
  `BAAI/bge-small-en-v1.5`). No outbound network calls at any stage.
- **Invariant 3 (hooks are scripts).** No daemon, no service, no class
  hierarchy. Three Python files, one requirements.txt.
- **Invariant 10 (one observability surface).** Output is gitignored under
  `infra/memory-router/data/`, deletable at any time. Git remains the
  authoritative record.
- **Invariant 7 (no CVE pattern matching).** Corpus indexed is LEDGER /
  METHODOLOGIES / DEAD-ENDS / READY-TO-SHIP only — none of which are CVE
  signatures. Findings inform the index as gap-class exemplars per D6 / D12.

## Files

| File              | Purpose                                                        |
|-------------------|----------------------------------------------------------------|
| `build.py`        | Walks corpus, chunks by markdown heading, embeds, writes index |
| `recall.py`       | `python recall.py "query" -k 8 [--filter source=…]`            |
| `contradict.py`   | `python contradict.py --seam "…"` — fails non-zero on conflict |
| `requirements.txt`| `fastembed`, `numpy`                                            |

Index lives at `infra/memory-router/data/{embeddings.npy, metadata.jsonl, build.stamp}` (gitignored).

## Setup

```sh
cd infra/memory-router/backends/vector
python -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt
python build.py               # first run downloads ~130MB ONNX model
```

Subsequent rebuilds reuse the cached model. `build.py --check` exits non-zero
if the corpus has drifted from the indexed snapshot — wire into
`session-start.sh` once the spike is approved.

## Usage examples

```sh
# Top-8 semantic neighbours
python recall.py "empty-key HMAC across language SDKs"

# Limit to DEAD-ENDS scope
python recall.py "rsa-pkcs1-v1_5 padding oracle" --filter source=dead-ends

# Before shipping a new finding, contradiction-check it
python contradict.py --file ../../../../pipeline/READY-TO-SHIP/30-foo/REPORT.md
```

## Out of scope (deliberate)

- No vector DB engine (sqlite-vec, chromadb, qdrant, etc.). Numpy matrix
  multiplication is faster than any of them up to ≈100K vectors and adds zero
  deps. The corpus has <1K chunks today.
- No hybrid BM25 + vector fusion. Ripgrep already serves keyword search; the
  router can RRF-merge if/when a query genuinely needs both.
- No re-ranker / cross-encoder. Premature for current scale.
- No web UI / viewer. Inv. 10.
- No cloud embeddings. Inv. 2.

## What gets wired in next (only after spike approval)

1. `pipeline/session-start.sh` runs `build.py --check` and warns on stale.
2. `pipeline/session-end.sh` runs `contradict.py` on each new `READY-TO-SHIP/NN-*/REPORT.md`.
3. The Memory Router MCP shell (when built) routes `memory.query` with
   `scope=semantic` to `recall.py` over a subprocess.

None of those are wired by this branch — they each deserve their own review.
