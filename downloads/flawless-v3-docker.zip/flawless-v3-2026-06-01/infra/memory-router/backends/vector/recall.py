"""Recall top-k chunks from the semantic-scope vector index.

CLI shape (the eventual Memory Router shell will subprocess this):

  python recall.py "empty-key HMAC across Ruby and Node" -k 8
  python recall.py "X" --filter source=dead-ends
  python recall.py "X" --filter tag=marked-clean

Output is JSONL on stdout, one match per line, ranked by descending cosine.
Each line: {score, source, anchor, tags, text}
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
DATA = ROOT / "infra/memory-router/data"
EMB_PATH = DATA / "embeddings.npy"
META_PATH = DATA / "metadata.jsonl"

EMBED_MODEL = "BAAI/bge-small-en-v1.5"


def load_index() -> tuple[np.ndarray, list[dict]]:
    if not EMB_PATH.exists() or not META_PATH.exists():
        print(
            "ERROR: index not built. Run `python build.py` first.",
            file=sys.stderr,
        )
        sys.exit(2)
    vecs = np.load(EMB_PATH).astype(np.float32)
    meta = [json.loads(ln) for ln in META_PATH.read_text(encoding="utf-8").splitlines() if ln.strip()]
    if vecs.shape[0] != len(meta):
        print(
            f"ERROR: index inconsistent ({vecs.shape[0]} vectors vs {len(meta)} meta rows). Rebuild.",
            file=sys.stderr,
        )
        sys.exit(2)
    return vecs, meta


def embed_query(query: str) -> np.ndarray:
    try:
        from fastembed import TextEmbedding  # type: ignore
    except ImportError:
        print("ERROR: fastembed not installed (see build.py).", file=sys.stderr)
        sys.exit(2)
    embedder = TextEmbedding(model_name=EMBED_MODEL)
    v = next(iter(embedder.embed([query]))).astype(np.float32)
    n = np.linalg.norm(v)
    return v / (n if n else 1.0)


def parse_filters(items: list[str]) -> dict[str, str]:
    out: dict[str, str] = {}
    for it in items:
        if "=" not in it:
            print(f"ERROR: filter must be key=value, got {it!r}", file=sys.stderr)
            sys.exit(2)
        k, v = it.split("=", 1)
        out[k.strip()] = v.strip()
    return out


def apply_filter(meta: list[dict], filters: dict[str, str]) -> np.ndarray:
    mask = np.ones(len(meta), dtype=bool)
    for k, v in filters.items():
        if k == "tag":
            mask &= np.array([v in m.get("tags", []) for m in meta])
        elif k == "source":
            mask &= np.array([m.get("source") == v for m in meta])
        else:
            print(f"ERROR: unknown filter key {k!r} (allowed: source, tag)", file=sys.stderr)
            sys.exit(2)
    return mask


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("query", help="natural-language query")
    ap.add_argument("-k", type=int, default=8, help="number of results (default 8)")
    ap.add_argument(
        "--filter",
        action="append",
        default=[],
        metavar="KEY=VALUE",
        help="repeatable; e.g. --filter source=dead-ends --filter tag=marked-clean",
    )
    args = ap.parse_args()

    vecs, meta = load_index()
    q = embed_query(args.query)
    scores = vecs @ q  # both L2-normalised → cosine

    mask = apply_filter(meta, parse_filters(args.filter))
    if not mask.any():
        return 0
    masked_scores = np.where(mask, scores, -np.inf)
    k = min(args.k, int(mask.sum()))
    top_idx = np.argpartition(-masked_scores, k - 1)[:k]
    top_idx = top_idx[np.argsort(-masked_scores[top_idx])]

    for i in top_idx:
        row = meta[int(i)]
        out = {
            "score": float(scores[int(i)]),
            "source": row.get("source"),
            "anchor": row.get("anchor"),
            "tags": row.get("tags", []),
            "text": row.get("text", "")[:600],
        }
        print(json.dumps(out, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
