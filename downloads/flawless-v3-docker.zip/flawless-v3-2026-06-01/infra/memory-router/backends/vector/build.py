"""Build the semantic-scope vector index from the LEGEND corpus.

This is a derived artefact (Invariant 10: one observability surface — git stays
authoritative). The index can be deleted and rebuilt at any time from the
markdown sources below.

Corpus walked:
  pipeline/LEDGER.md
  pipeline/METHODOLOGIES.md
  pipeline/DEAD-ENDS.md
  pipeline/READY-TO-SHIP/**/*.md

Output (gitignored, lives under infra/memory-router/data/):
  embeddings.npy     float32 matrix [N, D]
  metadata.jsonl     one line per row: {id, source, anchor, text, tags}

Per Invariant 5, this is a backend behind the Memory Router. The router exposes
memory.query/write/recall; this file does not. When the router shell ships,
its `semantic` scope wires to recall.py in this directory.

Run:
  python build.py            # full rebuild
  python build.py --check    # exit non-zero if index is stale vs sources

No network calls. Embedder is local (fastembed / ONNX). Invariant 2 honoured.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from dataclasses import dataclass, asdict
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[4]
DATA = ROOT / "infra/memory-router/data"
EMB_PATH = DATA / "embeddings.npy"
META_PATH = DATA / "metadata.jsonl"
STAMP_PATH = DATA / "build.stamp"

EMBED_MODEL = "BAAI/bge-small-en-v1.5"  # 384-dim, ~130MB ONNX, CPU-fine
CHUNK_TARGET_CHARS = 1200
CHUNK_OVERLAP_CHARS = 120

CORPUS = [
    ("ledger",         "pipeline/LEDGER.md"),
    ("methodologies",  "pipeline/METHODOLOGIES.md"),
    ("dead-ends",      "pipeline/DEAD-ENDS.md"),
]
READY_TO_SHIP_GLOB = "pipeline/SHIPPED/**/*.md"


@dataclass
class Chunk:
    id: str
    source: str         # tag like "ledger", "dead-ends", "ready-to-ship/04"
    anchor: str         # relpath:line:heading (best effort)
    text: str
    tags: list[str]     # ["marked-clean"], ["dead-end"], ["methodology:M3"], ...


def sha16(*parts: str) -> str:
    return hashlib.sha256("|".join(parts).encode()).hexdigest()[:16]


def split_by_heading(text: str, max_chars: int = CHUNK_TARGET_CHARS) -> list[tuple[int, str, str]]:
    """Split markdown by H2/H3 headings, then by target size.

    Returns (start_line, heading_or_empty, chunk_text).
    """
    lines = text.splitlines()
    sections: list[tuple[int, str, list[str]]] = []
    cur_heading = ""
    cur_start = 1
    cur_buf: list[str] = []
    for i, ln in enumerate(lines, start=1):
        if re.match(r"^#{1,3} ", ln):
            if cur_buf:
                sections.append((cur_start, cur_heading, cur_buf))
            cur_heading = ln.lstrip("#").strip()
            cur_start = i
            cur_buf = [ln]
        else:
            cur_buf.append(ln)
    if cur_buf:
        sections.append((cur_start, cur_heading, cur_buf))

    out: list[tuple[int, str, str]] = []
    for start, head, buf in sections:
        body = "\n".join(buf).strip()
        if not body:
            continue
        if len(body) <= max_chars:
            out.append((start, head, body))
            continue
        i = 0
        while i < len(body):
            piece = body[i : i + max_chars]
            out.append((start, head, piece))
            i += max_chars - CHUNK_OVERLAP_CHARS
    return out


def tag_for(source: str, text: str) -> list[str]:
    tags = [source]
    low = text.lower()
    if "marked clean" in low or "audited clean" in low:
        tags.append("marked-clean")
    if "reopen" in low and source == "dead-ends":
        tags.append("reopened")
    if source == "dead-ends":
        tags.append("dead-end")
    for m in re.finditer(r"\bM([1-9]\d?)\b", text):
        tags.append(f"methodology:M{m.group(1)}")
    if "READY-TO-SHIP" in source.upper() or source.startswith("ready-to-ship"):
        tags.append("ready-to-ship")
    return sorted(set(tags))


def collect_chunks() -> list[Chunk]:
    chunks: list[Chunk] = []

    for tag, relpath in CORPUS:
        p = ROOT / relpath
        if not p.exists():
            continue
        text = p.read_text(encoding="utf-8", errors="replace")
        for start_line, head, body in split_by_heading(text):
            chunks.append(
                Chunk(
                    id=sha16(relpath, str(start_line), body[:64]),
                    source=tag,
                    anchor=f"{relpath}:{start_line}:{head or '_'}",
                    text=body,
                    tags=tag_for(tag, body),
                )
            )

    for p in sorted(ROOT.glob(READY_TO_SHIP_GLOB)):
        relpath = p.relative_to(ROOT).as_posix()
        text = p.read_text(encoding="utf-8", errors="replace")
        finding_id = p.parent.name  # e.g. "04-pulsar-multi-roles-unsigned-jwt"
        src_tag = f"ready-to-ship/{finding_id}"
        for start_line, head, body in split_by_heading(text):
            chunks.append(
                Chunk(
                    id=sha16(relpath, str(start_line), body[:64]),
                    source=src_tag,
                    anchor=f"{relpath}:{start_line}:{head or '_'}",
                    text=body,
                    tags=tag_for(src_tag, body),
                )
            )

    seen: set[str] = set()
    deduped: list[Chunk] = []
    for c in chunks:
        if c.id in seen:
            continue
        seen.add(c.id)
        deduped.append(c)
    return deduped


def corpus_fingerprint() -> str:
    """Hash of (path, size, mtime) over the indexed corpus. Cheap staleness check."""
    h = hashlib.sha256()
    paths: list[Path] = []
    for _, rel in CORPUS:
        p = ROOT / rel
        if p.exists():
            paths.append(p)
    paths.extend(sorted(ROOT.glob(READY_TO_SHIP_GLOB)))
    for p in sorted(paths):
        st = p.stat()
        h.update(f"{p.relative_to(ROOT)}|{st.st_size}|{int(st.st_mtime)}".encode())
    return h.hexdigest()[:16]


def embed_texts(texts: list[str]) -> np.ndarray:
    try:
        from fastembed import TextEmbedding  # type: ignore
    except ImportError:
        print(
            "ERROR: fastembed not installed.\n"
            "  python -m venv .venv && . .venv/bin/activate && pip install -r requirements.txt",
            file=sys.stderr,
        )
        sys.exit(2)
    embedder = TextEmbedding(model_name=EMBED_MODEL)
    vecs = np.vstack(list(embedder.embed(texts))).astype(np.float32)
    norms = np.linalg.norm(vecs, axis=1, keepdims=True)
    norms[norms == 0] = 1.0
    return vecs / norms  # store L2-normalised; query is then a dot product


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--check", action="store_true",
                    help="exit 1 if index is stale vs sources (no rebuild)")
    args = ap.parse_args()

    fp = corpus_fingerprint()
    if args.check:
        if not STAMP_PATH.exists():
            print(f"stale: no index built yet (corpus fingerprint {fp})")
            return 1
        prev = STAMP_PATH.read_text().strip()
        if prev != fp:
            print(f"stale: corpus {fp} != index {prev}")
            return 1
        print(f"fresh: {fp}")
        return 0

    DATA.mkdir(parents=True, exist_ok=True)
    chunks = collect_chunks()
    if not chunks:
        print("no chunks collected; nothing to do", file=sys.stderr)
        return 1

    print(f"embedding {len(chunks)} chunks with {EMBED_MODEL}…", file=sys.stderr)
    vecs = embed_texts([c.text for c in chunks])

    np.save(EMB_PATH, vecs)
    with META_PATH.open("w", encoding="utf-8") as f:
        for c in chunks:
            f.write(json.dumps(asdict(c), ensure_ascii=False) + "\n")
    STAMP_PATH.write_text(fp)

    print(f"wrote {EMB_PATH.name} ({vecs.shape}) + {META_PATH.name} ({len(chunks)} rows)", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
