#!/usr/bin/env python3
"""
Flawless Memory Router — MCP server (FastMCP harness over MemoryRouter in src/server.py).

Scopes:
  - working   : in-process, always live (no backend needed)
  - semantic  : LEDGER / METHODOLOGIES / DEAD-ENDS  (needs vector backend: fastembed)
  - episodic  : session history / findings          (needs vector backend: fastembed)

Run by Claude Code via .mcp.json. Degrades gracefully: if the vector backend
(fastembed) isn't installed, the working scope still works and the semantic/
episodic tools report the backend as unavailable instead of crashing.
"""

import sys
from pathlib import Path
from typing import Optional

sys.path.insert(0, str(Path(__file__).parent / "src"))
import server as mr  # noqa: E402  (the MemoryRouter implementation)

from mcp.server.fastmcp import FastMCP  # noqa: E402

router = mr.MemoryRouter()
mcp = FastMCP("flawless-memory-router")


@mcp.tool()
def memory_query(scope: str, query: str, k: int = 5) -> list:
    """Query memory. scope = semantic | episodic | working. Returns up to k relevant memories."""
    return router.query(scope, query, k)


@mcp.tool()
def memory_write(scope: str, content: str, metadata: Optional[dict] = None) -> dict:
    """Write a memory into a scope (semantic | episodic | working). Returns the new memory id."""
    return router.write(scope, content, metadata)


@mcp.tool()
def memory_recall(session_id: str) -> dict:
    """Recall episodic context (recent findings + decisions) for a session id."""
    return router.recall(session_id)


@mcp.tool()
def memory_check_dead_end(hypothesis: str) -> dict:
    """Check whether a hypothesis conflicts with recorded DEAD-ENDS (uses the semantic backend)."""
    return router.check_dead_end(hypothesis)


@mcp.tool()
def memory_backend_status() -> dict:
    """Report which memory backends are live. semantic/episodic require the vector backend (fastembed)."""
    return {
        "semantic": router.semantic_index is not None,
        "episodic": router.episodic_index is not None,
        "working": True,
        "scopes": router.SCOPES,
    }


if __name__ == "__main__":
    mcp.run()
