# Flawless v3 — boot file (agenda-less semantic vulnerability engine)

> **BOOT: type `/flawless`** — the SessionStart hook has already printed the
> ground truth on disk (checker count, index freshness, skill-router status).
> Trust that output over any number written in prose anywhere.

## What Flawless is

A vulnerability-research engine that audits **boundary seams** — join points
where two components share state and each carries unstated, divergent
assumptions. Method = **Belief / Reality / Gap**: what A believes B guarantees,
what B actually does, where they diverge. The full method lives in the
`flawless-engine` skill (`.claude/skills/flawless-engine/SKILL.md`), which loads
on demand.

## Core principle — agenda-less discovery

Do NOT name a seam or bug class up front. Entry IS discovery: open the target,
map every boundary seam semantically, write B/R/G for each. Patterns (P1–P9)
attach *after*, emerging from what the seams show. The per-gap sub-agents and
pattern checkers are lenses, not the platform. Gaps from the BRG audit drive
Stage A; patterns fill uncovered seams in Stage B. Treat agent output as
hypotheses, not verdicts — read the cited anchor and confirm before promoting.

## The flow — auto-chained

```
/intake <target>
   ↓ (auto)
/discover   (≥6 seams)         → SUCCESS auto → /analyze   | <6 → /close DEAD-END
/analyze    (gap sub-agents +     → ≥1 match auto → /poc       | 0   → /close DEAD-END
             verifier/candidate)
/poc        (build+run+oracle) → VULNERABLE auto → /validate | no-repro → /close DEAD-END
/validate   (6 hostile checks)         → 6/6 auto → /ship           | fail → /close DEAD-END
/ship       (mechanical gate)  → 7/7 auto → /close          | block → STOP
/close      (terminal)         → STOP. "Ready. /intake <next>"
/outcome    (out-of-band)      → record vendor verdict when a disclosure resolves
```

## What's wired (v3)

- **3 MCP servers** via `.mcp.json` (approve once):
  - `flawless-finding-store` — finding state machine (SQLite). **8 tools** (v1 had 5):
    create / update / get / list_by_state / query, plus v3:
    `finding_record_verdict`, `finding_record_outcome`, `finding_verdict_stats`.
  - `flawless-memory-router` — semantic recall over the LEDGER/METHODOLOGIES/
    DEAD-ENDS/SHIPPED index. `working` live; rebuild semantic with
    `infra/.venv/bin/python infra/memory-router/backends/vector/build.py`.
  - `flawless-skill-router` (NEW) — discovers SKILL.md skills (Claude-Red et al.)
    under `CLAUDE_SKILLS_DIR`. `skill_match` (router picks by pattern+B/R/G),
    `skill_get` (agent pulls a body by name), `skill_list`, `router_status`.
- **20 subagents** in `.claude/agents/`: 18 pattern-checkers + `pattern-verifier` + `sad` (Skeptical Analysis Daemon),
  dispatched by `.claude/commands/analyze.md`. (Disk is authoritative; the
  SessionStart hook asserts prose matches disk.)
- **Hooks** (`.claude/settings.json`): SessionStart (boot integrity),
  PreToolUse×2 (ship-gate on commit + phase-policy gate), PostToolUse
  (provenance, hashes I/O), SubagentStop (anchor + verdict reminder), PreCompact
  (working-state snapshot), Stop (anti-inflation).
- **Semantic prior-art gate** — `infra/lint/contradiction_gate.sh` wraps
  `contradict.py`; run it before promoting a finding to CANDIDATE.

## v3 deltas vs v1 (why this exists)

1. **Count drift fixed.** v1's `verify.sh` hard-coded `n==11` and would FAIL a
   correct 14-checker tree; CLAUDE.md said 11, policy said 8, analyze said 14.
   v3 derives the count from disk and asserts prose matches it.
2. **Dead wiring connected.** v1 computed verdicts and threw them away;
   `finding_patterns` / `transition_reason` were never written. v3 writes both
   and adds `finding_verdict_stats` for confirm/refute calibration.
3. **Ground-truth loop.** `/outcome` + `finding_outcomes` record the vendor
   verdict; a rejection becomes a DEAD-LEADS refutation.
4. **`contradict.py` wired.** The semantic prior-art gate existed in v1 but was
   never called; v3 wraps it as a gate.
5. **Skills, properly.** v1's skill was a flat file that doesn't load. v3 ships
   `flawless-engine/SKILL.md` (correct folder form) and the skill-router MCP to
   reach Claude-Red technique skills on demand.
6. **New hook events.** SessionStart / SubagentStop / PreCompact, which v1 left unused.

## First thing this session

```sh
bash verify.sh        # expect: ALL CHECKS PASSED
```

## Methodologies

P1 Invariant-Not-Enforced · P2 Parsing-Disagreement · P3 TOCTOU · P4 Dual-Store ·
P5 Fix-Did-Not-Propagate (SIBLING/FRESH-FEATURE/BACKPORT/UNASSIGNED-CVE) ·
P6 Error-Semantic · P7 Unsafe-Deserialization · P8 Cryptographic-Misuse ·
P9 Sandbox-Escape. Full taxonomy in `pipeline/METHODOLOGIES.md`; checker→skill
map in `.claude/skills/flawless-engine/references/claude-red-map.md`.

## Claude-Red (technique depth)

```sh
git clone https://github.com/SnailSploit/Claude-Red ~/.claude/skills/claude-red
export CLAUDE_SKILLS_DIR=~/.claude/skills
```
The skill-router indexes whatever skills are present — no code change to add more.
