# Flawless v3 — CHANGELOG (2026-06-01)

Standalone successor to `flawless-portable-2026-05-26`. **v1 is not modified.**
v3 includes its own copies of everything; the carried-forward components were
copied from v1 (never edited in place).

## Verification status

`bash verify.sh` → **ALL 11 CHECKS PASSED** in the build sandbox.

- **Verified headless (proven here):** finding-store v3 round-trip (verdict +
  transition_reason + outcome + verdict_stats), skill-router (discover + match +
  get-by-name + provenance), checker-count drift guard, contradiction-gate
  wiring, policy.yaml validity + outcome phase, config JSON, engine-skill folder
  form, hook presence, phase-policy deny/allow.
- **Built to spec, fire on your machine (no Claude Code runtime in the sandbox):**
  the 4 hooks as Claude Code events (SessionStart/SubagentStop/PreCompact/
  PostToolUse), the 3 MCP servers under the live MCP runtime, semantic-index
  build (needs `fastembed`), and the `/outcome` command end to end.
- Two `[info]` lines in verify.sh (`mcp`, `fastembed` not installed in sandbox)
  resolve after `install.sh` on your machine; server *logic* is verified directly.

## NEW files (net-new in v3)

- `infra/skill-router-mcp/server.py` + `mcp_server.py` — **new MCP.** Discovers
  SKILL.md skills (Claude-Red et al.) under `CLAUDE_SKILLS_DIR`; `skill_match`
  (router picks by pattern+B/R/G), `skill_get` (agent pulls a body by name),
  `skill_list`, `router_status`. Logs selections to provenance.
- `.claude/commands/outcome.md` — ground-truth loop: records vendor verdict;
  rejection → DEAD-LEADS refutation + REFUTED verdict.
- `.claude/hooks/sessionstart-boot.sh` — boot integrity into context (kills v1
  count-drift at the root). Replaces v1's archived manual `session-start.sh`.
- `.claude/hooks/subagentstop-enforce.sh` — anchor-or-drop + record-verdict +
  pull-a-skill reminder when a checker/verifier finishes.
- `.claude/hooks/precompact-save-memory.sh` — snapshots working state before the
  context compacts (v1 lost it).
- `infra/lint/check-checker-count.sh` — derives the checker count from disk and
  fails if a prose file disagrees.
- `infra/lint/contradiction_gate.sh` — wraps v1's never-called `contradict.py`
  as a pre-CANDIDATE semantic prior-art gate.
- `.claude/skills/flawless-engine/SKILL.md` (+ `references/patterns.md`,
  `references/claude-red-map.md`) — the engine method in correct **folder** form
  (v1's skill was a flat file that doesn't load). Counts de-staled to 14.
- `install.sh`, `bootstrap-from-v1.sh`, `package.json`, this CHANGELOG, `README.md`.

## CHANGED vs v1 (rewritten, same role)

- `infra/finding-store-mcp/{server.py,mcp_server.py,schema.sql}` — **5 tools → 8.**
  Writes `finding_states.transition_reason` (v1 left NULL); adds
  `finding_record_verdict` → `finding_patterns` (v1 never wrote it), now with a
  `skill_used` column; adds `finding_record_outcome` → new `finding_outcomes`;
  adds `finding_verdict_stats` (confirm/refute calibration).
- `verify.sh` — checker count **derived from disk** (v1 hard-coded `n==11` and
  would FAIL a correct 14-checker tree); checks 8 finding-store tools,
  skill-router, contradiction gate, outcome phase, engine-skill folder, hooks.
- `.claude/settings.json` — hook events **4 → 6** (adds SessionStart,
  SubagentStop, PreCompact).
- `.claude/policy.yaml` — adds `outcome` phase; fixes the stale "8 pattern
  checkers" comment to 14.
- `.claude/settings.local.json.template` — adds the +3 finding-store tools, the
  4 skill-router tools, and `flawless-skill-router` to enabled servers.
- `.mcp.json` — registers the third server (`flawless-skill-router`).
- `CLAUDE.md` — correct counts (14, 8 tools, 3 MCPs) from the start; documents
  the v3 deltas and the skill-router/Claude-Red wiring.

## CARRIED FORWARD from v1 (copied, unchanged)

- `.claude/agents/` — 14 pattern checkers + `pattern-verifier` (copied verbatim;
  I did not rewrite agents I had not fully read — that would be fabrication).
- `infra/memory-router/` — semantic/episodic/working scopes + `contradict.py`
  (good as-is; now actually wired via the gate).
- `pipeline/lint/{phase_policy_gate.py,precommit-ship-gate.sh,check-finding-folder.sh,stop-padding-check.sh}`.
- `.claude/commands/{intake,discover,analyze,poc,validate,ship,close,status,flawless,INDEX}.md`.
- `pipeline/{DEAD-LEADS.md,DEAD-ENDS.md,LEDGER.md,METHODOLOGIES.md,DEAD-LEADS.md.example}`.

## Command wiring (done in v3 — no tails)

The carried commands are now wired to the v3 backends:

- `analyze.md` **Step 0** — runs `contradiction_gate.sh` before dispatch (semantic prior-art; exit 1 stops, exit 2 warns).
- `analyze.md` **Step 3.5** — passes `DEAD-LEADS.md` to each verifier as a prior-FP corpus; calls `skill_match`/`skill_get` to pull the live pattern's Claude-Red technique; records every verdict via `finding_record_verdict`.
- `pattern-verifier.md` — checks each candidate against the prior-FP corpus first; empirical check is now MANDATORY for P1-overflow / P8-timing / P9-sandbox (REFUTE if it cannot be run).
- `close.md` **Step 7/8** — rebuilds the semantic index when stale; hands off to `/outcome` for the ground-truth loop.

## Operator option (your call, not blocking)

- Pin the verifier to a different model than the checkers (settings) so the
  precision agent does not share a hallucination with the recall agents.
