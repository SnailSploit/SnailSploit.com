#!/usr/bin/env bash
# flawless-init.sh — FLAWLESS v3 first-run wizard.
# Idempotent. Configures the Claude Code side to talk to the containerized
# stdio MCP servers. Writes .mcp.json + .claude/settings.json and prints the
# exact run line. Safe to re-run — it backs up existing config first.
set -euo pipefail

BOLD=$(tput bold 2>/dev/null || true); RST=$(tput sgr0 2>/dev/null || true)
say()  { printf "%s\n" "$*"; }
ask()  { local p="$1" d="${2:-}"; local r; read -rp "$p ${d:+[$d] }" r; echo "${r:-$d}"; }
yn()   { local p="$1"; local r; read -rp "$p [y/N] " r; [[ "$r" =~ ^[Yy]$ ]]; }

ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

say "${BOLD}FLAWLESS v3 — first-run wizard${RST}"
say "This wires Claude Code to the containerized MCP servers. Local, stdio, fail-closed."
say ""

# --- 1. work dir ---
WORK=$(ask "Work directory to mount (your targets + scratch):" "./work")
mkdir -p "$WORK"
WORK_ABS="$(cd "$WORK" && pwd)"
say "  work dir: $WORK_ABS"

# --- 2. skill library (Claude-Red) ---
SKILLS=$(ask "Skill-library path (Claude-Red repo the skill-router reads):" "${HOME}/.claude/skills")
say "  skills:   $SKILLS"

# --- 3. optional recon tokens ---
SHODAN=""; GH=""
if yn "Wire optional recon MCPs (Shodan / GitHub)?"; then
    SHODAN=$(ask "  Shodan API key (blank to skip):" "")
    GH=$(ask "  GitHub token (blank to skip):" "")
fi

# --- 4. memory scope ---
say ""
say "Memory scope:"
say "  local  — per-operator state in a named volume (ships now, simplest)"
say "  shared — hosted DB + vector store, team learning loop (configure later)"
SCOPE=$(ask "Choose memory scope:" "local")
[[ "$SCOPE" == "shared" ]] || SCOPE="local"
say "  scope:    $SCOPE"

# --- write .env for compose ---
{
  echo "FLAWLESS_MEMORY_SCOPE=$SCOPE"
  [ -n "$SHODAN" ] && echo "SHODAN_API_KEY=$SHODAN"
  [ -n "$GH" ] && echo "GITHUB_TOKEN=$GH"
} > docker/.env
say ""
say "wrote docker/.env"

# --- write .mcp.json pointed at the container over `docker compose exec` ---
# Claude Code launches each server as a stdio subprocess that execs into the
# running container. No ports, no network boundary — the gate stays local.
backup() { [ -f "$1" ] && cp "$1" "$1.bak.$(date +%s)" && say "  backed up $1"; }
backup .mcp.json

EXEC='docker'
COMPOSE_ARGS='compose -f docker/docker-compose.yml exec -T flawless'

cat > .mcp.json <<JSON
{
  "mcpServers": {
    "flawless-finding-store": {
      "command": "$EXEC",
      "args": ["$COMPOSE_ARGS", "infra/.venv/bin/python", "infra/finding-store-mcp/mcp_server.py"]
    },
    "flawless-memory-router": {
      "command": "$EXEC",
      "args": ["$COMPOSE_ARGS", "infra/.venv/bin/python", "infra/memory-router/mcp_server.py"]
    },
    "flawless-skill-router": {
      "command": "$EXEC",
      "args": ["$COMPOSE_ARGS", "infra/.venv/bin/python", "infra/skill-router-mcp/mcp_server.py"],
      "env": { "CLAUDE_SKILLS_DIR": "$SKILLS" }
    }
  }
}
JSON
# Note: args is written as space-joined for readability; normalize to a proper array:
python3 - <<'PY'
import json
exec_bin = "docker"
base = "compose -f docker/docker-compose.yml exec -T flawless".split()
skills = json.load(open(".mcp.json"))["mcpServers"]["flawless-skill-router"]["env"]["CLAUDE_SKILLS_DIR"]
cfg = {"mcpServers": {
  "flawless-finding-store": {"command": exec_bin, "args": base + ["infra/.venv/bin/python","infra/finding-store-mcp/mcp_server.py"]},
  "flawless-memory-router": {"command": exec_bin, "args": base + ["infra/.venv/bin/python","infra/memory-router/mcp_server.py"]},
  "flawless-skill-router": {"command": exec_bin, "args": base + ["infra/.venv/bin/python","infra/skill-router-mcp/mcp_server.py"], "env": {"CLAUDE_SKILLS_DIR": skills}},
}}
json.dump(cfg, open(".mcp.json","w"), indent=2)
PY
say "wrote .mcp.json (stdio over docker compose exec — no network boundary)"

# --- ensure .claude/settings.json exists (hooks already shipped in repo) ---
mkdir -p .claude
if [ ! -f .claude/settings.json ]; then
    echo '{ "hooks": {} }' > .claude/settings.json
    say "created .claude/settings.json stub (repo ships the real hooks)"
else
    say ".claude/settings.json present (repo hooks intact)"
fi

say ""
say "${BOLD}Done. Start the engine:${RST}"
say "  docker compose -f docker/docker-compose.yml up -d --build"
say ""
say "Then in Claude Code, from this directory:"
say "  /flawless          # boots, runs verify.sh, shows status"
say "  /intake <target>   # starts the auto-chained hunt"
say ""
say "Health:  docker ps   (healthy = 13/13 verify checks pass inside the container)"
