#!/usr/bin/env bash
# Flawless v3 — installer. Sets up the venv, installs deps for all 3 MCP servers,
# builds the semantic index, and (optionally) clones Claude-Red for technique skills.
set -eu
cd "$(dirname "$0")"
echo "[1/5] venv"
python3 -m venv infra/.venv
PY=infra/.venv/bin/python
$PY -m pip install --quiet --upgrade pip
echo "[2/5] deps (mcp, numpy, fastembed, pyyaml)"
$PY -m pip install --quiet mcp numpy fastembed pyyaml

# jq is required by the ship-gate (pipeline/lint/precommit-ship-gate.sh). It's a system
# binary, not a pip package — install via your OS package manager if missing.
if ! command -v jq >/dev/null 2>&1; then
  echo "  [warn] jq not found — ship-gate will not run until you install it (apt install jq / brew install jq)"
fi
echo "[3/5] init finding-store db"
$PY infra/finding-store-mcp/server.py
echo "[4/5] build semantic index (memory-router)"
$PY infra/memory-router/backends/vector/build.py || echo "  (index build skipped — corpus may be empty; rebuild later)"
echo "[5/5] Claude-Red (optional technique skills)"
if [ ! -d "${HOME}/.claude/skills/claude-red" ]; then
  echo "  not found. To enable per-pattern technique depth:"
  echo "    git clone https://github.com/SnailSploit/Claude-Red ~/.claude/skills/claude-red"
  echo "    export CLAUDE_SKILLS_DIR=~/.claude/skills"
else
  echo "  found at ~/.claude/skills/claude-red"
fi
echo
echo "Done. Verify:  bash verify.sh"
echo "Then open this dir in Claude Code and run /flawless"
