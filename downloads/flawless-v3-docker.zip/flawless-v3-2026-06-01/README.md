# Flawless v3

Agenda-less semantic vulnerability engine. Audits boundary seams via
Belief/Reality/Gap, dispatches 14 pattern checkers + a verifier, builds real
executable PoCs, and ships through a mechanical gate. v3 adds a skill-router MCP
(reaches Claude-Red technique skills on demand), a ground-truth loop, a
drift-proof boot, and connects the verdict/outcome wiring v1 left dead.

This is a **standalone** package. It does not modify v1.

## Install

```sh
bash install.sh        # venv + deps (mcp, numpy, fastembed, pyyaml) + db + index
bash verify.sh         # expect: ALL CHECKS PASSED
# optional technique depth:
git clone https://github.com/SnailSploit/Claude-Red ~/.claude/skills/claude-red
export CLAUDE_SKILLS_DIR=~/.claude/skills
```

Then open this directory in Claude Code (it auto-loads `.mcp.json`, the hooks,
and the `flawless-engine` skill) and run `/flawless`.

## What's where

- `CLAUDE.md` — boot file, the flow, the v3 deltas.
- `.claude/skills/flawless-engine/SKILL.md` — the B/R/G method (loads on demand).
- `.claude/agents/` — 14 pattern checkers + `pattern-verifier`.
- `.claude/commands/` — the pipeline phases + `/outcome`.
- `.claude/hooks/` — SessionStart, SubagentStop, PreCompact, PostToolUse.
- `infra/finding-store-mcp/` — finding state machine, 8 tools.
- `infra/skill-router-mcp/` — Claude-Red bridge (NEW).
- `infra/memory-router/` — semantic/working memory + `contradict.py`.
- `infra/lint/` — `check-checker-count.sh`, `contradiction_gate.sh`.
- `CHANGELOG.md` — full file-level diff vs v1 + verification status.

## The three MCPs

1. **finding-store** — create/update/get/list/query findings, plus v3:
   `finding_record_verdict`, `finding_record_outcome`, `finding_verdict_stats`.
2. **memory-router** — semantic recall + the `contradict.py` prior-art check.
3. **skill-router** — `skill_match` (router picks a Claude-Red skill by
   pattern+B/R/G), `skill_get` (agent pulls a body by name), `skill_list`,
   `router_status`. Description-driven: indexes whatever SKILL.md files exist
   under `CLAUDE_SKILLS_DIR` — add skills, no code change.

Built by Kai Aizen (SnailSploit). v1 untouched; v3 is the connected version.
