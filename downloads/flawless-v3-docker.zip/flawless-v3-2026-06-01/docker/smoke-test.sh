#!/usr/bin/env bash
# docker/smoke-test.sh — build the image and confirm the engine is wired.
# Not a full hunt; a fast gate that the container boots and verify passes.
set -euo pipefail
cd "$(dirname "$0")/.."

echo "[smoke] building image..."
docker compose -f docker/docker-compose.yml build

echo "[smoke] starting container..."
docker compose -f docker/docker-compose.yml up -d

echo "[smoke] waiting for healthcheck..."
for i in $(seq 1 20); do
    status=$(docker inspect --format '{{.State.Health.Status}}' flawless 2>/dev/null || echo "starting")
    echo "  attempt $i: $status"
    [ "$status" = "healthy" ] && break
    sleep 5
done

echo "[smoke] running verify.sh inside container..."
docker compose -f docker/docker-compose.yml exec -T flawless bash verify.sh | tail -3

echo "[smoke] confirming MCP servers launch over stdio..."
docker compose -f docker/docker-compose.yml exec -T flawless \
    infra/.venv/bin/python -c "import sys; sys.path.insert(0,'infra/finding-store-mcp'); import mcp_server; print('[smoke] finding-store importable')"

echo "[smoke] PASS — image built, healthy, verify green, MCPs launch"
echo "[smoke] tearing down..."
docker compose -f docker/docker-compose.yml down
