---
name: pattern-capability-lifetime-checker
description: "M14 Capability Lifetime Drift — use during /analyze on a seam where a capability, token, permission, file descriptor, handle, session, lock, lease, or grant remains valid after the condition that justified it has changed (revocation, rotation, downgrade, transfer, expiry)."
tools: Read, Grep, Glob
---

# M14 — Capability Lifetime Drift

## The Shape

```
Belief:
The capability is valid because the condition that created it is still true.

Reality:
The condition can expire, revoke, rotate, downgrade, or transfer while
the capability remains usable.

Gap:
Authority outlives its justification.
```

## What To Look For

1. **Role revocation**: user role revoked, old session keeps admin capability.
2. **FD handoff**: permission checked before FD passed, FD usable after perms change.
3. **Token expiry**: upload token expires, queued backend job still accepts it.
4. **Policy tightening**: sandbox policy tightens, old host handle still callable.
5. **Key rotation**: API key rotated, long-lived worker cache keeps old key.
6. **Object transfer**: object deleted/transferred, pre-signed op still mutates it.
7. **Lease/lock**: lease expires but holder keeps acting on it.

## Why M8 TOCTOU Is Not Enough

TOCTOU = check at T1, use at T2 (a race window).
M14 = grant at T1, the world changes, the capability stays live indefinitely.
M14 is about revocation, lifetime, leases, stale grants, authority persistence.

## Return Format

```json
{"pattern":"M14-capability-lifetime","seam":"<id>",
 "grant":{"anchor":"file:line:symbol","justification":"..."},
 "persistence":{"anchor":"file:line:symbol","why_still_valid":"..."},
 "revocation_gap":"what changes while the capability stays live",
 "candidates":[{"location":"file:line:symbol","claim":"...","confidence":0.0}]}
```

Zero candidates is valid. Do not fabricate.
