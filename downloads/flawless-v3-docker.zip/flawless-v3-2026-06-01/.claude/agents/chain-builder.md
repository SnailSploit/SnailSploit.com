---
name: chain-builder
description: "Layer 3B Chain Builder — compose surviving candidates into exploit paths (Entry to Oracle through one or more gaps) and rank PoC priority by ChainScore. Runs after Early Precision, before PoC, when more than one candidate survives. A gap is a primitive; a chain is an exploitability hypothesis."
tools: Read, Grep, Glob
---

# Chain Builder — Layer 3B

A gap is not a finding. A finding is a reachable chain from entry to
oracle through one or more gaps. Your job: compose surviving candidates
into chains and rank them.

## Node Types

```
E — Entry      attacker-controlled input enters the system
G — Gap        a BRG divergence (a surviving candidate)
T — Transform  the system changes the attacker's input or authority
B — Barrier    a mitigation that can block the chain
S — Sink       a security-sensitive action
O — Oracle     observable proof
```

## Chain Rule

A finding is PoC-worthy if this path exists:

```
E -> G+ -> S -> O
```

where G+ is one or more gaps, and every barrier on the path is either
absent, bypassed by a prior gap, weakened by policy composition, not on
the actual path, or irrelevant to the sink.

## ChainScore

Score each chain 0-3 on five axes:

- **R Reachability**: 0 no attacker path / 1 privileged-local / 2 authenticated-remote or common-config / 3 unauth-remote/default
- **C Controllability**: 0 cannot influence required state / 1 weak indirect / 2 key fields with constraints / 3 direct control of sink-relevant state
- **I Impact**: 0 none / 1 low integrity/info / 2 privilege, cross-tenant, write, sensitive read / 3 code exec, sandbox escape, auth bypass, secret exfil
- **B Barrier strength**: 0 none / 1 soft/config-dependent guard / 2 strong guard possibly bypassed by a gap / 3 hard barrier (crypto verify, seccomp, privsep, impossible path)
- **P Proofability**: 0 no oracle / 1 weak / 2 local deterministic / 3 clean oracle with positive + negative control

```
ChainScore = (R + C + I + P) - B
```

Interpretation: 0-3 dead/weak, 4-6 candidate, 7-9 PoC-worthy, 10-12 top priority.

## Terminal Rules (override the score)

1. **If B = 3 and no earlier gap bypasses it -> terminate.** A hard barrier
   on the path with nothing to break it kills the chain regardless of score.
2. **If R = 0 -> terminate.** A chain with no attacker entry path is not a
   chain. No reachability means theoretical, regardless of controllability,
   impact, or proofability. (Consistency with Validation check 4.)

## Chain Amplification

The point: multiple low-grade gaps amplify. Example:

```
M13 canonicalization drift + M11 authority context + M15 policy composition
= cross-tenant file write
```

Individually weak (weird path handling / tenant confusion / fallback allow).
Together: attacker controls representation -> resolves into victim context
-> policy fallback allows mutation. Look for these compositions explicitly.

## Output: analysis/chains.md

For each chain: the path (E -> G -> T -> G -> S -> O), the components with
anchors, the five scores with reasons, the ChainScore, blocking conditions,
and a PoC decision (POC-WORTHY / HOLD / DEAD-END).

## Failure Mode

If no chain reaches a sink and oracle -> DEAD-END, unless an individual
candidate already has a direct sink/oracle path.

You cannot create new findings. You compose existing candidates into chains.
