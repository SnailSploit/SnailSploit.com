---
name: pattern-canonicalization-drift-checker
description: "M13 Canonicalization Drift — use during /analyze on a seam where a value is validated in one representation but consumed in another. Two layers normalize, decode, resolve, lowercase, clean, join, or canonicalize the same value differently, so the checked representation and the consumed representation are not the same object."
tools: Read, Grep, Glob
---

# M13 — Canonicalization Drift

## The Shape

```
Belief:
The normalized value used for validation is equivalent to the value
later consumed by the sink.

Reality:
Different layers normalize, decode, resolve, lowercase, clean, join,
parse, or canonicalize the value differently.

Gap:
The checked representation and the consumed representation are not the
same object.
```

## What To Look For

1. **Path**: validator checks raw/lexical path, sink opens decoded/realpath.
2. **Symlink/mount**: lexical path check vs kernel realpath resolution.
3. **Unicode**: auth checks lowercase/ASCII, lookup preserves confusables.
4. **URL/host**: parser validates host A, HTTP client connects to host B.
5. **Extension**: filter checks "file.jpg", decoder handles "file.jpg.php".
6. **Double-decode**: one layer decodes once, another decodes twice.
7. **Slash/dot normalization**: router collapses `//` and `../`, FS resolver differs.

## Why M10 Is Not Enough

M10 parsing-oracle = two parsers read **syntax** differently.
M13 = two layers resolve **identity** differently. Broader: path traversal,
SSRF, upload validation, authz, package managers, sandboxing, multi-tenant.

## Return Format

```json
{"pattern":"M13-canonicalization-drift","seam":"<id>",
 "checked_repr":{"anchor":"file:line:symbol","form":"..."},
 "consumed_repr":{"anchor":"file:line:symbol","form":"..."},
 "divergence":"how the two representations differ",
 "candidates":[{"location":"file:line:symbol","claim":"...","confidence":0.0}]}
```

Zero candidates is valid. Do not fabricate.
