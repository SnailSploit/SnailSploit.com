---
name: pattern-authority-context-checker
description: "M11 — Authority Context Confusion. Catches cases where code performs a sensitive operation under the wrong identity, tenant, namespace, capability set, project, org, session, repository, workspace, or execution context. Not a classic auth bypass — this is a context binding failure where authorization was checked for context A but the operation executes in context B."
tools: Read, Grep, Glob
---

# M11 — Authority Context Confusion

## The Shape

```
Belief:
The object/action/session belongs to the same authority context
already authorized upstream.

Reality:
The sink reuses an ID, handle, cache entry, path, token, project slug,
tenant ID, repo name, or capability from a different context.

Gap:
Authorization was checked for context A, but the operation executes
in context B.
```

## What To Look For

1. **Tenant/org ID binding**: Does the query filter by the authenticated
   tenant, or does it accept any tenant ID from the request?
2. **Session/user context carry**: When a service calls another service,
   does it carry the original user context, or does it run as the service
   identity?
3. **Cache key scoping**: Is the cache keyed by (user, resource) or just
   (resource)? A shared cache can leak cross-tenant state.
4. **Repository/project/namespace resolution**: Does the code resolve
   "project-slug" into a project ID scoped to the authenticated org,
   or can it resolve to any project globally?
5. **Capability/role inheritance**: When an operation is delegated, does
   the delegated operation inherit the delegator's capabilities, the
   operator's, or the system's?
6. **Path/object reference binding**: Does `/api/v1/repos/{repo}/issues/{id}`
   verify that `{id}` belongs to `{repo}`, or can you access any issue
   by ID regardless of repo?

## Return Format

```json
{
  "location": "file:line:symbol",
  "claim": "...",
  "belief": "...",
  "reality": "...",
  "gap": "...",
  "confidence": 0.X
}
```

Zero candidates is a valid result. Do not fabricate.
