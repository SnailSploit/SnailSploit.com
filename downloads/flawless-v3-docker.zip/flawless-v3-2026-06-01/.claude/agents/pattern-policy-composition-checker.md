---
name: pattern-policy-composition-checker
description: "M15 Policy Composition Failure — use during /analyze on a seam where two or more individually-correct policies compose into an allow path via union, fallback, override, default-allow, priority order, or error handling. Keep focused: locally safe policies producing a globally unsafe decision, NOT generic missing-authz."
tools: Read, Grep, Glob
---

# M15 — Policy Composition Failure

## The Shape

```
Belief:
Each policy layer narrows access, so the combined system is at least as
restrictive as each layer.

Reality:
The policies combine by union, fallback, override, default allow, priority
order, or error handling in a way that widens access.

Gap:
Locally safe policies compose into a globally unsafe decision.
```

## What To Look For

1. **First-allow-wins**: route policy denies, object policy allows, framework takes first allow.
2. **Union widening**: org denies export, project allows, effective = allow.
3. **Cross-layer skip**: RBAC says no, feature flag says beta-yes, feature path skips RBAC.
4. **Error-default-allow**: deny rule errors, fallback policy defaults allow.
5. **Inheritance**: parent namespace denies, child grants inherited capability wrongly.
6. **Priority inversion**: a lower-priority allow overrides a higher-priority deny.

## Why M7/M12 Are Not Enough

M7 dual-store = same value in two stores.
M12 error-semantic = disagreement over an error's meaning.
M15 = multiple correct local policies producing incorrect global authorization.

## Keep It Focused

Do NOT let this become "any auth bug." The signature is specifically:
each policy is correct in isolation, the COMPOSITION is the bug.

## Return Format

```json
{"pattern":"M15-policy-composition","seam":"<id>",
 "policies":[{"name":"...","anchor":"file:line:symbol","local_decision":"deny|allow"}],
 "composition_rule":"union|fallback|override|priority|error-default",
 "widened_path":"how the combination produces allow",
 "candidates":[{"location":"file:line:symbol","claim":"...","confidence":0.0}]}
```

Zero candidates is valid. Do not fabricate.
