---
name: pattern-fresh-feature-checker
description: M3 Fresh-Feature checker — use during /analyze to check one boundary seam where a new field/feature on a recently-fixed surface bypasses the fix's validator.
tools: Read, Grep, Glob
---

# M3: Fresh-Feature Regression

New feature shipped without auditing interactions with old subsystems.

## Work

1. Identify the fresh feature (recent additions, version bumps, new config)
2. Map feature to all subsystems it touches
3. For each subsystem, verify old invariants still hold
4. Return candidates where feature broke an old assumption

## Output

```json
{
  "pattern": "M3-fresh-feature",
  "seam": "<seam>",
  "feature_name": "...",
  "broken_invariants": ["..."],
  "candidates": [{"location": "file:line", "invariant": "..."}]
}
```
