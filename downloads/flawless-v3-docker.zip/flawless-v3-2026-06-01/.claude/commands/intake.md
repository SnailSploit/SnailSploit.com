---
description: Start work on a target — record it, check prior work, go to discovery
---

# `/intake <target>` — Start On A Target

Enter the **Intake** phase. Flawless is **agenda-less**: you point at a
target and discovery maps the seams. You do NOT name a seam, pick a
methodology, or rank up front.

## Usage

```
/intake openssh-portable
/intake https://github.com/owner/repo
/intake <target>
```

## What this does

1. **Search prior work** — query the Finding Store and grep
   `pipeline/DEAD-ENDS.md` / `pipeline/LEDGER.md` for the target.
2. **Show existing findings** on this target (any state).
3. **Make the source available** (clone/locate it).
4. **Record the finding** (Finding Store, state DISCOVERED).
5. Hand off to discovery.

**There is NO intake gate.** Naming a seam, mapping a methodology, and
ranking happen LATER — they emerge from the seam-map, not before it. (The
old "Intake Guard / forbidden regular auditing" rule is archived in
`legacy/` and is not in force.)

## Output

```
Target:     <target>
Prior work: <N findings / none>
State:      DISCOVERED
Next:       /discover   (map every boundary seam + Belief/Reality/Gap)
```

## Tips

- Target already has findings → hunt siblings (same seam class, different code path).
- Target in DEAD-ENDS → confirm reopen evidence before re-running.
- New target → just start; discovery is the entry, no gate.

---

## CHAIN POLICY

`/intake` is the chain entry. The operator does NOT approve subsequent phases.

On completion:
- **SUCCESS** (target recorded, source available, no shipped duplicate) → **immediately invoke `/discover`**. No prompt, no confirmation.
- **BLOCKED** (target not locatable, or already in SHIPPED and operator did not explicitly ask to hunt siblings) → STOP and report.

---

## Implementation notes

- `finding_query(target=...)` via the Finding Store MCP (or call the venv
  backend directly).
- Optionally `finding_create(...)` to register the finding.
- Then auto-invoke `/discover` (no approval).
