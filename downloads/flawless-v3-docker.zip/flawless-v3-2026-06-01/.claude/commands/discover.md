---
description: Enumerate seams, audit Belief/Reality/Gap for each, apply candidate quality gate
---

# `/discover` — Seam-Map + B/R/G Audit

Enter the **Discovery** phase. Enumerate all boundary seams and write
Belief/Reality/Gap for each. Apply a quality gate to candidate seeds.

This is Layer 1 of the FLAWLESS architecture.

## What This Does

1. **Seam enumeration**: Identify boundary seams (typically 8-15) where
   components interact over shared state.
2. **Belief/Reality/Gap**: For each seam, document:
   - **Belief**: What does component A assume component B guarantees?
   - **Reality**: What does component B actually do/guarantee?
   - **Gap**: Where are they out of sync? What is the invariant violation?
3. **Candidate quality gate**: Filter gaps that are not security-relevant
   or not falsifiable.
4. **Write SEAM-MAP.md**: Enumerate all seams, one-liner per seam.
5. **Write BRG.md**: Detailed B/R/G per seam (semantic reading, not grep).
6. **Update state**: Mark finding as DISCOVERED.

## Seam Categories

Typical seam categories to look for:

- user input -> parser
- parser -> semantic interpreter
- request -> authentication
- authentication -> authorization
- validator -> sink
- config -> runtime behavior
- cache -> database
- patch -> sibling implementation
- serializer -> deserializer
- API promise -> caller assumption
- error -> recovery path
- sandbox policy -> host operation
- internal state -> external interface

## Discipline

> This is semantic work. Do not grep and declare victory.

For each seam:
- Trace the code path (what actually happens at runtime)
- Identify the boundary (where does control/state transfer)
- Write what each side assumes (even if implicit)
- Identify the gap (where assumptions diverge)
- Anchor to `file:line:symbol`

## Candidate Quality Gate

Each gap must pass a quality gate before it becomes a candidate seed.

A gap survives only if:

1. It is anchored to `file:line:symbol`
2. The belief is explicit or strongly implied by the code
3. The belief is falsifiable (can be tested by execution)
4. The reality is supported by reading the actual source
5. The gap is an actual divergence, not a defended condition
6. The suspected impact is security-relevant
7. The path appears reachable enough to justify deeper analysis

Gaps that fail this gate are dropped with a one-line reason.

## Low-Surface Targets

If fewer than six seams are found, the engine classifies the target as
**low-surface** rather than immediately worthless.

The target proceeds only if the discovered seams are security-dense
enough to justify analysis. This prevents the engine from throwing away
small but important targets: parsers, sandbox wrappers, auth middleware,
compression utilities, deserializers, focused CLI tools.

If the seams are not security-dense, terminate as DEAD-END.

## Output

```
Finding: [ID]
Seams identified: N
Candidate seeds (post quality gate): M
SEAM-MAP.md written
BRG.md written
State: DISCOVERED
Next: /analyze
```

## Files Generated

```
finding-<id>/
  seam-map.md          (one-liner per seam, all boundaries found)
  brg.md               (detailed Belief/Reality/Gap per seam)
  notes/               (working notes, discovery process)
  poc/                 (will be populated by /poc phase)
```

## CHAIN POLICY

The operator does NOT approve subsequent phases.

On completion:
- **SUCCESS** (seams found, quality gate passed, SEAM-MAP.md + BRG.md
  written, state DISCOVERED) -> **immediately invoke `/analyze`**. No prompt.
- **DEAD-END** (no meaningful seams, or all gaps fail quality gate) ->
  invoke `/close` with `status=DEAD-END, reason="target too simple or
  no falsifiable gaps"`.
