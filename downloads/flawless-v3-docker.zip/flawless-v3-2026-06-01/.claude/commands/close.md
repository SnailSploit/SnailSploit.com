---
description: Close finding — cleanup, archive, LEDGER/PATTERNS updates
---

# `/close` — Close Finding & Archive

Exit the finding workflow. Update LEDGER, PATTERNS, cleanup worktree.

## What This Does

1. **Update LEDGER.md**: Append chronological entry (date, finding ID, outcome, seam, pattern)
2. **Update PATTERNS.md**: If new pattern discovered, document it
3. **Update DEAD-ENDS.md**: If finding was ruled out, record with reopen evidence
4. **Git commit**: "close: finding-[ID], state=[SHIPPED|DEAD-END]"
5. **Exit worktree**: Clean up isolated branch (merge to main if shipped, discard if dead-end)
6. **Task cleanup**: Mark task as COMPLETED in Task system

## Outcome States

### SHIPPED Finding

```
Finding ID: [ID]
State: SHIPPED
Outcome: ✓ ready for disclosure

Actions:
  1. Append to LEDGER.md:
     - Date shipped
     - Finding title + seam
     - Pattern (P1-P9)
     - CVSS + verdict
     - Advisory path

  2. Append to PATTERNS.md (if new pattern):
     - Pattern name
     - Definition
     - Worked examples
     - Anti-patterns

  3. Merge worktree branch to main
  4. Archive finding in pipeline/SHIPPED/
  5. Task → COMPLETED

Example LEDGER entry:
  2026-05-25 | #177 OpenSSH ssh_valid_ruser $-bypass | M1 (incomplete-fix)
             | CVSS 8.1 (ProxyCommand injection) | VULNERABLE
             | advisory/DISCLOSURE.md + run-log verified
```

### DEAD-END Finding

```
Finding ID: [ID]
State: DEAD_END
Reason: [not reachable | not a bug | duplicate]

Actions:
  1. Append to DEAD-ENDS.md:
     - Date investigated
     - Hypothesis + seam
     - What was checked
     - Conclusion
     - Reopen evidence (if any)

  2. Discard worktree branch
  3. Archive finding in pipeline/DEAD-ENDS/notes/
  4. Task → COMPLETED

Example DEAD-ENDS entry:
  2026-05-25 | openssh-portable | ssh_valid_ruser integer-overflow
             | Check: integer-wrap, modulo arithmetic, upstream commit 9facc7c
             | Conclusion: Fixed in upstream 8.5p1, not a vulnerability
             | Reopen: Only if regression discovered in future versions
```

---

## Cleanup Checklist

Before running `/close`:

- [ ] Finding is in SHIPPED or DEAD-END state (confirmed via `/status`)
- [ ] All artifacts are committed (PoC, run-log, DISCLOSURE.md, etc.)
- [ ] VALIDATION-REPORT.md is written (for shipped) or reasoning is clear (for dead-end)
- [ ] No uncommitted changes in worktree

## Output

```
Finding: [ID]
State: SHIPPED | DEAD_END
LEDGER.md updated
PATTERNS.md updated (if new pattern)
DEAD-ENDS.md updated (if ruled out)
Worktree cleaned up
Task completed

Example git commit:
  commit 3f8e9a2c
  Author: Kai Aizen
  Date: 2026-05-25

    close: finding-177-openssh-bypass (SHIPPED)

    - M1 (incomplete-fix) pattern validated
    - CVSS 8.1 (ProxyCommand injection)
    - Run-log: VULNERABLE (100% reproducible)
    - Appended to LEDGER.md

Session-end ritual:
  ./pipeline/session-end.sh
```

---

## Session Continuity

After `/close`, the finding is completely archived:
- State persisted in LEDGER.md + SHIPPED/ directory
- Worktree branch either merged or discarded
- Task system has final state

Next session can:
- Start a new finding (different target)
- Resume a finding in progress (different state)
- Query LEDGER.md to see what was shipped
- Query DEAD-ENDS.md to avoid re-investigating

---

## Step 7 — Refresh semantic index (v3)

The corpus the contradiction gate and `check_dead_end` read is only as current
as the last index build. `/close` writes to LEDGER/SHIPPED, so it is the natural
rebuild trigger:

```sh
PY=infra/.venv/bin/python; [ -x "$PY" ] || PY=python3
$PY infra/memory-router/backends/vector/build.py --check >/dev/null 2>&1 \
  || $PY infra/memory-router/backends/vector/build.py
```

Stale index → rebuild now so the *next* target's prior-art gate sees this finding.

## Step 8 — Hand off to /outcome (v3)

For a SHIPPED finding, the loop is not closed until the vendor responds. Print:

```
When the disclosure resolves (accept / reject / dup / CVE), run:
  /outcome <finding-id>
```

`/outcome` records the ground-truth verdict; a rejection becomes a DEAD-LEADS
refutation that sharpens the gate and verifier on every future target.

## CHAIN POLICY (terminal phase)

This is the **last** phase of the chain. Do NOT auto-invoke anything after.

On completion:
- Print a one-line summary: `Finding <id> closed — <SHIPPED|DEAD-END>. <LEDGER/DEAD-ENDS> updated.`
- Print: `Ready. /intake <next-target> when you have one.`
- STOP. The chain ends. The operator decides the next target.

---

## Implementation Notes

This command:
- Appends to LEDGER.md (append-only, chronological)
- Appends to PATTERNS.md if new pattern (note it; do not block on operator approval)
- Appends to DEAD-ENDS.md if ruled out (with reopen evidence)
- Calls `ExitWorktree(action="keep" | "remove")` based on state
- Calls `TaskUpdate(status="completed")`
- **Terminal**: does NOT auto-invoke another phase.
