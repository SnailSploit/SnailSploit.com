---
description: Build and execute empirical PoC from candidates
---

# `/poc` — PoC Building & Execution

Enter the **PoC Building** phase. Build executable PoC, run against target, capture run-log, determine verdict.

## What This Does

1. **Select harness**: Choose template (scripted-python, compiled-c, runtime-node, integration-docker, etc.)
2. **Select candidate**: From PATTERN-ANALYSIS.md, pick highest-confidence candidate
3. **Build PoC**: Use Harness Builder MCP to construct test
4. **Execute**: Run PoC against vulnerable instance, capture output
5. **Capture run-log**: Record execution with timestamps, output, verdict
6. **Determine verdict**: PASS / VULNERABLE / EXIT <code> / ERROR
7. **Write artifacts**:
   - `poc/legend-c<N>-poc.<ext>` (PoC source)
   - `poc/run-log.txt` (execution output + verdict)
8. **Update Task**: Move to POC-READY

## Harness Templates

Available templates:

```
scripted-python    Python script (subprocesses, network, files)
scripted-bash      Bash script (CLI targets)
compiled-c         C harness (gcc build, system calls)
runtime-node       Node.js (npm install + runtime)
runtime-python     Python (pip install + imports)
integration-docker Docker container isolation
integration-chrome Chrome/Chromium with CDP driver
```

## Execution Discipline

**Empirical = executed + captured.**

Your PoC must:
1. Be runnable (not pseudocode)
2. Target real code (not mocked)
3. Capture run-log with timestamps
4. Record verdict explicitly (PASS / VULNERABLE / EXIT 0)
5. Be reproducible (others can run it)

If PoC is theoretically sound but can't execute: mark as DEAD-END.

## Async Building

Long builds (Chrome, kernel, Docker) can use RemoteTrigger:

```
/poc --async
```

This submits build to `RemoteTrigger` and returns immediately. Check status later:

```
/status
```

## Output

```
Finding: [ID]
Harness: scripted-python
PoC source: poc/legend-c<N>-poc.py
Run-log: poc/run-log.txt
Verdict: VULNERABLE (confidence 0.95)
Task state: POC-READY
Next: /validate (5 human checks)
```

## Files Generated

```
finding-[ID]/poc/
├─ legend-c<N>-poc.py       (or .c, .js, etc.)
├─ run-log.txt              (timestamp, steps, verdict)
└─ notes/                   (setup notes, config)
```

---

## CHAIN POLICY

The operator does NOT approve subsequent phases.

On completion:
- **SUCCESS** (run-log captured with verdict VULNERABLE, state POC-READY) → **immediately invoke `/validate`**. No prompt.
- **DEAD-END** (PoC executed but verdict is PASS / EXIT 0 with no exploit / not reproducible) → invoke `/close` with `status=DEAD-END, reason="PoC did not reproduce — <one-line evidence>"`.
- **BLOCKED** (cannot build PoC due to missing tooling, unbuildable target, or infra outage) → STOP and report. Do NOT auto-close. Operator decides whether to fix the blocker or abandon.

---

## Implementation Notes

This command:
- Calls Harness Builder MCP tools (list_templates, fetch_template, build, run)
- For long builds, calls RemoteTrigger (don't block current session)
- Captures stdout/stderr to run-log with timestamps
- Parses verdict from run-log
- Calls `TaskUpdate(state="POC-READY")` when complete
- Commits poc/ directory
- Auto-invokes `/validate` on VULNERABLE verdict (no approval).
