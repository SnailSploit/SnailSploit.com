---
description: Record a shipped finding's vendor verdict — closes the ground-truth loop so rejections become future refutations
---

# `/outcome` — record the vendor verdict (ground-truth loop)

Run this when a disclosed finding resolves: the maintainer accepted it, rejected
it, called it a duplicate, won't-fix, or a CVE/GHSA landed. This is the only
**ground-truth** label in the system — every other signal (checker, verifier,
validate) is the model judging itself. Closing this loop is what lets the
pipeline learn from reality instead of from its own opinion.

> Not a guide. When you run `/outcome`, perform the steps with real tool calls.

## Step 1 — identify the finding

Take the finding id as `$ARGUMENTS`, or `finding_query(state="SHIPPED")` and ask
which one. Read it with `finding_get(id)` so you have its pattern(s) and anchor.

## Step 2 — record the outcome

Call `finding_record_outcome(finding_id, disposition, vendor_severity, cve, channel, note)`:
- `disposition`: `accepted | rejected | duplicate | wontfix | pending`
- `vendor_severity`: the maintainer's severity if they assigned one (for calibration vs your CVSS)
- `cve` / `channel`: identifiers if assigned
- `note`: one line of context

## Step 3 — on rejection, feed the corpus

If `disposition` is `rejected` or `wontfix-because-not-a-bug`, the verifier was
wrong to confirm it. Make that a future refutation:

1. Append a `pipeline/DEAD-LEADS.md` entry in the verifier's exact format:
   ```
   ## YYYY-MM-DD | <target> | <seam-id> | vendor-rejected
   **Claim**: what we reported
   **Reality**: why the vendor says it isn't exploitable (their words)
   **Why the agent was wrong**: the belief/reality step that was off
   **Recurrence prevention**: the pattern to refute next time
   ```
2. `finding_record_verdict(finding_id, pattern, "REFUTED", confidence=0, skill_used=<as recorded>, notes="vendor-rejected: <reason>")`
   so `finding_verdict_stats` reflects the real confirm rate, not the optimistic one.

This is what makes the contradiction gate (and the verifier's prior-FP corpus)
sharper on the next target — a maintainer's "no" becomes a cheap static signal
that kills the same mistake before any model touches it.

## Step 4 — on acceptance, mark calibration

If `accepted`, record it and compare `vendor_severity` to your assigned CVSS in
the note. Persistent over- or under-rating is a calibration signal for /validate
check 4.

## Output

```
Finding: <id>
Disposition: <accepted|rejected|...>  CVE: <id|none>
Outcome recorded. DEAD-LEADS updated: <yes|no>. Verdict stats refreshed.
```

## CHAIN POLICY

Terminal and standalone — `/outcome` does not auto-invoke another phase. It is
run out-of-band whenever a disclosure resolves, days or weeks after `/close`.
On completion print the summary and stop.
