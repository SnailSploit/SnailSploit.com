---
description: Gap-seeded analysis with per-gap sub-agents, M-pattern backstop on uncovered seams, early precision filter, and SAD review at decision points
---

# `/analyze` — Gap-Seeded Analysis

Enter the **Analysis** phase.

This command implements Layers 2-3 of the FLAWLESS architecture:
the Agent Layer (gap-seeded sub-agents + pattern backstop) and the
Early Precision Layer (hostile filter + SAD review).

> This is not a guide. When you run `/analyze`, you MUST perform the
> steps below with real tool calls. Do not print the plan and stop.

---

## Step 0 — Semantic Prior-Art Gate (mandatory)

Before any analysis, run the contradiction gate on the finding's BRG.

```sh
bash infra/lint/contradiction_gate.sh pipeline/DISCOVERED/<finding>
```

- exit 0: clear, proceed.
- exit 1: gap matches a recorded dead-end. STOP: add reopen evidence
  or `/close` with `status=DEAD-END, reason="semantic contradiction"`.
- exit 2: index stale/unbuilt (non-blocking). Note and proceed.

## Step 1 — Load Inputs and Extract Gaps

1. Find the active finding folder under `pipeline/DISCOVERED/`.
2. Read `SEAM-MAP.md` and `BRG.md`. If either is missing, stop and
   tell the operator to run `/discover` first.
3. **Extract the gaps.** From `BRG.md`, identify every seam where
   Belief differs from Reality and produced a concrete, anchored gap. Record:
   - seam ID
   - gap summary
   - anchor: `file:line:symbol`
   - suspected failure shape (if any — do not force a classification)
4. Count the gaps. Could be 0, could be 9. The count is dynamic.

## Step 1b — Write Agent Plan

Before dispatching any sub-agent, write `analysis/agent-plan.json`:

```json
{
  "finding_id": "<id>",
  "target_commit": "<40-char hash>",
  "stage_a": [
    {
      "seam_id": "S-001",
      "gap_id": "G-001",
      "agent": "<matched checker or generic>",
      "skill": "<routed skill name>",
      "reason": "<gap summary>",
      "anchor": "file:line:symbol"
    }
  ],
  "covered_seams": [],
  "stage_b": []
}
```

Stage B entries are added after Stage A completes. No subagent runs
unless it appears in this plan.

## Step 2 — Stage A: Per-Gap Sub-Agents (gap-seeded)

**The gaps drive the agents. The agents do not drive the gaps.**

For EACH gap extracted in Step 1:

1. **Route a fitting skill.** Call `skill_match(pattern=<gap_summary>,
   brg=<gap_text>)` via the skill-router MCP. Then `skill_get(name)`
   to load the technique into context.
2. **Dispatch a sub-agent** for this gap. The sub-agent receives:
   - the seam and its BRG
   - the source anchors
   - the relevant code context (the cloned target path)
   - the matched technique skill (in the sub-agent's context)
3. The sub-agent reads the code at the anchor, applies the technique,
   and returns a candidate or "no finding on this gap."

If Step 1 found zero gaps, Stage A produces zero candidates. That is
valid — proceed to Stage B.

Each sub-agent returns JSON:

```json
{
  "gap_id": "<seam_id>",
  "skill_used": "<skill_name or none>",
  "candidates": [
    {"location": "file:line:symbol", "claim": "...", "confidence": 0.9}
  ],
  "total_candidates": 0,
  "covered": true
}
```

Record which seams are now **covered** (Stage A produced a candidate).

## Step 3 — SAD Review: Stage A Output

Dispatch the `sad` sub-agent to review Stage A output.

SAD receives:
- each sub-agent's output
- the original BRG for that gap
- the skill that was used

SAD checks: does the output follow from the evidence and explanation,
or did the sub-agent fabricate a bridge?

SAD returns per candidate: `CONFIRM`, `REFUTE`, `DOWNGRADE`, or `NEEDS-EVIDENCE`.

- REFUTE: candidate dropped, appended to `dead-leads.md`.
- NEEDS-EVIDENCE: candidate blocked until evidence supplied.
- CONFIRM / DOWNGRADE: candidate proceeds.

## Step 4 — Stage B: M-Pattern Checkers on Uncovered Seams

Identify the **uncovered seams**: seams from `SEAM-MAP.md` where
Stage A did NOT produce a candidate (covered = false).

Dispatch the 18 pattern checkers **only over the uncovered seams**.

| #  | subagent_type                           | ID         |
|----|-----------------------------------------|------------|
| 1  | pattern-incomplete-fix-checker          | M1 / P5.S  |
| 2  | pattern-cross-protocol-checker          | M2 / P2    |
| 3  | pattern-fresh-feature-checker           | M3 / P5.FF |
| 4  | pattern-backport-gap-checker            | M4 / P5.BP |
| 5  | pattern-unassigned-cve-checker          | M5 / P5.UC |
| 6  | pattern-lossy-validation-checker        | M6 / P1    |
| 7  | pattern-dual-store-checker              | M7 / P4    |
| 8  | pattern-toctou-checker                  | M8 / P3    |
| 9  | pattern-implicit-contract-checker       | M9 / P1    |
| 10 | pattern-parsing-oracle-checker          | M10 / P2   |
| 11 | pattern-error-semantic-checker          | M12 / P6   |
| 12 | pattern-unsafe-deserialization-checker   | P7         |
| 13 | pattern-cryptographic-misuse-checker     | P8         |
| 14 | pattern-sandbox-escape-checker           | P9         |
| 15 | pattern-authority-context-checker         | M11 / P10  |
| 16 | pattern-canonicalization-drift-checker     | M13 / P2   |
| 17 | pattern-capability-lifetime-checker        | M14 / P3   |
| 18 | pattern-policy-composition-checker         | M15 / P11  |

Give each checker ONLY the uncovered seams (not the full seam map).
Each checker returns JSON candidates or zero results.

If ALL seams were covered by Stage A, Stage B is skipped entirely.

## Step 5 — SAD Review: Stage B Output

Dispatch SAD again to review Stage B candidates.
Same protocol as Step 3.

## Step 6 — Early Precision Filter

All surviving candidates (from Stages A and B, post-SAD) pass through
the Early Precision filter. Check each candidate in order:

1. **Unanchored** — no `file:line:symbol` -> drop.
2. **Stale anchor** — cited line no longer exists or symbol moved -> drop.
3. **Contradicted by source** — re-read the actual code at anchor;
   if it contradicts the claim -> drop.
4. **Known dead lead** — query memory-router; semantic match (>=0.80)
   against DEAD-LEADS -> drop.
5. **Maintainer-rejected pattern** — vendor previously rejected this
   pattern for this target -> drop.
6. **Framework-mitigated** — a framework defense blocks the issue
   (CSRF middleware, permissions decorator, schema validator) -> drop.
7. **Unreachable sink** — no attacker-controlled path reaches the
   vulnerable code -> drop.
8. **Hard barrier present** — seccomp, capability drop, sandbox,
   immutable fs blocks exploitation -> drop.

## Step 6b — Chain Builder (Layer 3B)

If MORE THAN ONE candidate survived the Early Precision filter, dispatch
the `chain-builder` sub-agent. A gap is a primitive; a finding is a
reachable chain from entry to oracle through one or more gaps.

Chain-builder composes surviving candidates into exploit paths:

```
E (entry) -> G+ (one or more gaps) -> T (transforms) -> S (sink) -> O (oracle)
```

and scores each chain:

```
ChainScore = (Reachability + Controllability + Impact + Proofability) - BarrierStrength
```

Terminal rules (override the score):
- B = 3 with no earlier gap bypassing it -> terminate.
- R = 0 (no attacker entry path) -> terminate.

Watch for **chain amplification**: weak gaps (e.g. M13 canonicalization +
M11 authority-context + M15 policy-composition) composing into one strong
finding (e.g. cross-tenant write).

Writes `<finding>/analysis/chains.md` with the path, scores, and a PoC
decision per chain (POC-WORTHY / HOLD / DEAD-END).

If a single candidate survived, chains.md is optional and the candidate's
own sink/oracle path is used.

## Step 7 — Dispatch Pattern-Verifier

For each candidate that survived the Early Precision filter, dispatch
the `pattern-verifier` sub-agent:

- Re-read the cited anchor verbatim (do not trust the checker's snippet).
- Check false-positive classes specific to the pattern.
- Cross-check against `pipeline/DEAD-LEADS.md` corpus.
- Call `skill_match` + `skill_get` if a technique skill has not been loaded.
- Return CONFIRMED or REFUTED.

REFUTED: append to `pipeline/DEAD-LEADS.md`, excluded from `/poc`.
CONFIRMED: eligible for `/poc`.

Record every verdict: call `finding_record_verdict(finding_id, pattern,
verdict, confidence, skill_used, notes)` via finding-store MCP.

## Step 8 — Merge and Update State

Write `<finding>/analysis/candidates.md` consolidating:
- all Stage A candidates (post-SAD, post-filter, post-verifier)
- all Stage B candidates (post-SAD, post-filter, post-verifier)
- for each: anchor, claim, gap source, pattern classification, skill used
- a ranked shortlist for `/poc`, ordered by ChainScore (from chains.md) when chains exist, else by candidate confidence

Update state:
- >=1 confirmed candidate -> state `CANDIDATE`.
- zero candidates -> state `DEAD-END`.

## Output

```
Finding: <id>
Stage A gaps: N (sub-agents dispatched: N, skills used: [list])
Stage B uncovered seams: M (checkers dispatched on M seams)
SAD reviews: X confirm, Y refute, Z needs-evidence
Early Precision filtered: F dropped
Verifier: C confirmed, R refuted
Candidates found: total
analysis/candidates.md written
State: CANDIDATE | DEAD-END
```

## Rules

- **Gap-seeded, not pattern-seeded.** The gaps from BRG drive Stage A.
  The patterns in Stage B are a backstop on uncovered seams only.
- **Real dispatch only.** Do not fabricate sub-agent output.
- **Anchored only.** Drop any candidate without `file:line:symbol`.
- **Semantic, not grep.** Reject keyword-only hits.
- **Record every verdict.** An unrecorded verdict is a signal thrown away.

## CHAIN POLICY

The operator does NOT approve subsequent phases.

On completion:
- **SUCCESS** (>=1 confirmed candidate, state CANDIDATE) ->
  **immediately invoke `/poc`** on the top-ranked candidate. No prompt.
- **DEAD-END** (zero candidates after all stages, filters, and verifier) ->
  invoke `/close` with `status=DEAD-END`.
