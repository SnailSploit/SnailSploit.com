# `/flawless` — Console Up

The console boot command. Brings up Flawless, shows where the pipeline stands, and tells the operator what the next move is.

## Execute in this exact order

### 1. Verify wiring

```sh
bash verify.sh
```

Expect: `ALL CHECKS PASSED (verify.sh prints the count)`. If anything fails, STOP and report which check broke.

### 2. Print the logo (the console is up)

Exactly this — no decorations, no extra prose around it:

```
    ███████╗██╗      █████╗ ██╗    ██╗██╗     ███████╗███████╗███████╗
    ██╔════╝██║     ██╔══██╗██║    ██║██║     ██╔════╝██╔════╝██╔════╝
    █████╗  ██║     ███████║██║ █╗ ██║██║     █████╗  ███████╗███████╗
    ██╔══╝  ██║     ██╔══██║██║███╗██║██║     ██╔══╝  ╚════██║╚════██║
    ██║     ███████╗██║  ██║╚███╔███╔╝███████╗███████╗███████║███████║
    ╚═╝     ╚══════╝╚═╝  ╚═╝ ╚══╝╚══╝ ╚══════╝╚══════╝╚══════╝╚══════╝
                    ◢◤ s e a m   r i p p e r ◢◤
              snailsploit research · vulnerability engine
```

### 3. Show pipeline state

Run:

```sh
/status
```

This prints the finding distribution, goal-200 progress, quality metrics, and active methodologies.

### 4. Tell the operator the next part

Pull current state and surface the right next-action — pick ONE based on what you see:

| If state shows... | Say |
|---|---|
| Open finding in `DISCOVERED/` | `Open finding: <id>. Next: /analyze` |
| Open finding in `CANDIDATE` | `Candidate ready: <id>. Next: /poc` |
| Open finding in `POC-READY` | `PoC captured: <id>. Next: /validate` |
| Open finding in `VALIDATED` | `Validated: <id>. Next: /ship` |
| No open findings | `No open finding. Next: intake <target> to begin.` |

Then output exactly:

```
Ready. <next-action>
```

### 5. STOP

Wait for the operator. Do not ask what the target is. Do not explain Flawless. Do not list methodologies, skills, MCPs. The status output already said it.

## Forbidden

- Asking "what is X?" about any operator-supplied target name (it's not your scope)
- Re-explaining what Flawless is
- Inventing commands or output formats
- Any prose beyond logo + status + one-line next-action
