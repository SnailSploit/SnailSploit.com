---
description: Show LEGEND headline state, recent LEDGER entries, and what to do next
---

Read and surface, in order:

1. The "Headline numbers" panel from `pipeline/STATE.md`.
2. The "Right now" line.
3. The "What to do next" ranked list.
4. The most recent 5 entries from `pipeline/LEDGER.md` (last 5
   lines of the table block).
5. Any uncommitted changes (`git status --short`).

Format the output as a single readable summary the user can act on
in 30 seconds.  Do not perform any other action; this is a read-only
status check.
