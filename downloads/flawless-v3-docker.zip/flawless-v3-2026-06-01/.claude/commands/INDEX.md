# Flawless v3 — Command Index

Seam-first semantic vulnerability-research engine.
Find where two components share state but disagree about it.

## Architecture — Seven Layers

```
Discovery -> Agent -> Early Precision -> PoC -> Validation -> Ship -> Outcome
```

Auto-chained: each advances on success or routes to /close DEAD-END.
No operator approval between steps.

## Pipeline Commands

### /intake <target>
Acquire the target. Agenda-less: no seam, pattern, or methodology named.
Checks prior work, clones source, registers finding. -> DISCOVERED.

### /discover
Layer 1 — Discovery. Enumerate >=6 boundary seams. Write Belief/Reality/Gap
per seam. Apply candidate quality gate. Low-surface targets proceed if
security-dense.
Output: seam-map.md, brg.md. -> DISCOVERED.

### /analyze
Layers 2-3 — Agent + Early Precision.
Step 0: contradiction gate (semantic prior-art check).
Stage A: per-gap sub-agents with routed skills (0-9, dynamic, gap-seeded).
SAD reviews Stage A output.
Stage B: 14 M-pattern checkers on UNCOVERED seams only (backstop).
SAD reviews Stage B output.
Early Precision filter: 8 hostile checks (unanchored, stale, contradicted,
dead-lead, maintainer-rejected, framework-mitigated, unreachable, hard-barrier).
Pattern-verifier per surviving candidate.
Output: analysis/candidates.md. -> CANDIDATE or DEAD-END.

### /poc
Layer 4 — PoC. Build and EXECUTE against real target code.
Oracle types: crash (ASan/UBSan), state, response, callback.
Requires: positive test + negative control + fresh run-log + anchor recheck.
Output: poc/ directory + run-log. -> POC-READY or DEAD-END.

### /validate
Layer 5 — Hostile Validation. 6 adversarial checks:
1. Disprove the claim
2. Wrong-reason PoC?
3. Hidden guard?
4. Sink reachable?
5. Duplicate / framework-handled?
6. Belief retrofitted?
Severity assigned after validation. SAD reviews outcome.
Output: validation-report.md. -> VALIDATED or DEAD-END.

### /ship
Layer 6 — Deterministic Ship Gate. 9 MECHANICAL checks (no LLM discretion):
1. Report exists  2. PoC exists  3. Run-log fresh  4. Verdict present
5. Anchors resolve  6. Commit pinned  7. No methodology leakage
8. Severity assigned  9. Content hash created
Output: -> SHIPPED or BLOCKED.

### /close
Terminal. Appends to LEDGER.md, records dead-end reasoning, rebuilds
semantic index, prints /outcome reminder. STOP — operator decides next.

### /outcome
Out-of-band. Records vendor verdict. Rejection -> DEAD-LEADS refutation.
Acceptance -> severity calibration. The ground-truth learning loop.

### /status
Read-only. Headline state + recent ledger. STATE.md/LEDGER.md generated
on first /close.

### /flawless
Boot: run `bash verify.sh`, then /status.

## Sub-Agents (20 total in .claude/agents/)

18 pattern checkers: M1 incomplete-fix, M2 cross-protocol, M3 fresh-feature,
M4 backport-gap, M5 unassigned-cve, M6 lossy-validation, M7 dual-store,
M8 toctou, M9 implicit-contract, M10 parsing-oracle, M12 error-semantic,
P7 unsafe-deser, P8 crypto-misuse, P9 sandbox-escape, M11 authority-context, M13 canonicalization-drift, M14 capability-lifetime, M15 policy-composition.
(Mapping: P1<-M9+M6, P2<-M10+M2, P3<-M8, P4<-M7, P5<-M1+M3+M4+M5, P6<-M12, P7/P8/P9 direct, P10<-M11, P11<-M15; M13->P2, M14->P3. 13 conceptual patterns.)

1 verifier: pattern-verifier (per candidate, post-filter).

1 reviewer: SAD — Skeptical Analysis Daemon (chain-wide, at decision points).

1 composer: chain-builder (Layer 3B — composes candidates into scored exploit chains).

## The FLAWLESS Law

A BRG gap is a candidate primitive.
A chain is an exploitability hypothesis.
A PoC is the physical test of the chain.
A shipped finding is a validated chain with a fresh oracle.

(A gap is NOT a finding. A finding is a reachable chain from entry to
oracle through one or more gaps.)

## MCP Servers

- finding-store: SQLite state machine, 8 tools.
- memory-router: semantic recall + contradiction gate.
- skill-router: description-matched technique routing.

## Key Rules

1. No static traces. Real execution only.
2. No findings without file:line:symbol anchors.
3. No ship with stale run-logs.
4. No LLM discretion in the ship gate.
5. No pattern-first discovery.
6. Refuted candidates go to DEAD-LEADS.
7. No step skipping.
8. No copied PoCs from the internet.
9. No claims without reproduction.
10. Each step produces an artifact and explanation.
11. SAD reviews every propagation decision.
12. Vendor report must not leak internal methodology.
13. Outcome data must update memory.
14. Vendor response outranks model confidence.
15. Recall is not claimed.
