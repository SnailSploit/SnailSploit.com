---
description: Deterministic ship gate — 9 mechanical checks before commit. No LLM discretion.
---

# `/ship` — Deterministic Ship Gate

Enter the **Shipped** phase. Run 9 mechanical checks on `git commit`.

This is Layer 6 of the FLAWLESS architecture.

**This is a mechanical gate. Not LLM judgment. Not opinion. Not subjective.**

The ship gate runs via the PreToolUse hook on `git commit`. It reads
files on disk and makes binary pass/fail decisions. The model cannot
argue past it, negotiate with it, or override it.

## The 9 Checks

### 1. Report Exists

The vendor-facing report must exist:

```
advisory/DISCLOSURE.md
```

### 2. PoC Exists

An executable PoC source file must exist in `poc/`.

### 3. Run-Log Fresher Than Latest PoC Edit

The run-log mtime must be newer than the PoC source mtime.

This proves the PoC was re-executed after the last code change.
A fabricated finding has no fresh run-log.

### 4. Expected Verdict Present

The run-log must contain a verdict line:

```
VULNERABLE | PASS | EXIT | NOT-REPRODUCIBLE
```

### 5. Anchors Resolve

Every cited `file:line:symbol` must point to actual code in the
target repository. Broken anchors block shipping.

### 6. Commit Pinned

The finding must reference a specific target commit hash.

Reports cannot cite `latest`, `main`, `master`, or `HEAD` without
the resolved commit hash.

### 7. No Internal Methodology Leakage

The disclosure report must not contain FLAWLESS-internal terminology:

Blocked terms include (not exhaustive):
- FLAWLESS, BRG, "Belief / Reality / Gap"
- SAD, pattern checker, gap-seeded
- M1, M2, M3 ... M12, P7, P8, P9
- DEAD-LEADS, pipeline state
- Any agent name or internal artifact name

The vendor report must read as independent vulnerability research.

### 8. Severity Assigned

The report must include a CVSS score (or equivalent severity rating)
with vector string.

### 9. Commitment Hash Created

A content hash of the finding folder is computed and stored.

This creates a tamper-evident record of what was shipped.

## What Happens After Ship

1. Commit succeeds (all 9 checks pass)
2. Finding moved to `pipeline/SHIPPED/<finding>/`
3. State: SHIPPED
4. Append to `pipeline/LEDGER.md`

## No Manual Override

If 9 checks pass, it ships. If any fails, the commit is blocked.

No "almost ship-grade" limbo.

## Output

```
Finding: [ID]
Check 1 (Report):        pass/fail
Check 2 (PoC):           pass/fail
Check 3 (Fresh run-log): pass/fail
Check 4 (Verdict):       pass/fail
Check 5 (Anchors):       pass/fail
Check 6 (Commit pinned): pass/fail
Check 7 (No leakage):    pass/fail
Check 8 (Severity):      pass/fail
Check 9 (Content hash):  pass/fail
State: SHIPPED | BLOCKED
```

## CHAIN POLICY

The operator does NOT approve subsequent phases.

On completion:
- **SUCCESS** (all 9 checks pass, commit succeeds, state SHIPPED) ->
  **immediately invoke `/close`**. No prompt.
- **BLOCKED** (any check fails) -> STOP. Report which check failed.
  Fix the issue. Retry `/ship`. Do NOT auto-close on block.
