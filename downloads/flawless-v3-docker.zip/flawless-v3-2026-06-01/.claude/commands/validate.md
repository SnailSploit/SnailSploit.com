---
description: Hostile validation gate — 6 adversarial checks that try to kill the finding
---

# `/validate` — Hostile Validation Gate

Enter the **Validation** phase. Adversarially try to destroy the finding
through six checks. All six must pass. The validator cannot create new
findings — it can only confirm, downgrade, or destroy existing ones.

This is Layer 5 of the FLAWLESS architecture.

> The validator wears the adversarial hat. Your job is to find reasons
> NOT to ship. If you cannot destroy it, it ships.

## Input

A candidate with:
- claim and impact
- source anchors (`file:line:symbol`)
- BRG chain (from seam-map.md and brg.md)
- PoC source and run-log
- oracle evidence
- execution trace or path explanation

## The 6 Checks

### 1. Disprove the Claim

Read the code again from scratch.

- Does the vulnerability exist as described?
- Is the belief accurate?
- Is the reality accurate?
- Is the gap actually a gap?
- Did the analysis omit a relevant guard?

If the claim does not survive rereading, terminate.

**Verdict**: claim stands / claim disproved

### 2. Wrong-Reason PoC

Determine whether the PoC passed for the claimed reason.

A PoC may trigger an oracle through a different bug, harness artifact,
test shortcut, or unrelated path. The validator must retrace execution:

- Does the PoC reach the cited seam?
- Does the observed oracle depend on the claimed gap?
- Does the negative control avoid the gap?
- Is the evidence accidental?

If the PoC passes for the wrong reason, terminate or downgrade.

**Verdict**: correct reason / wrong reason

### 3. Hidden Guard Present

Search for defenses the analysis missed.

Examples: authentication middleware, permissions check, type guard,
schema validator, integrity check, capability boundary, rate limit,
WAF rule, sandbox profile, build flag, deployment default.

If a production-relevant guard blocks exploitation, terminate or downgrade.

**Verdict**: no guard / guard found

### 4. Sink Reachability

Trace from attacker-controlled entry points to the sink.

The vulnerable code may exist and be locally triggerable but still
unreachable by an attacker in realistic deployment.

Identify:
- entry point
- attacker-controlled state
- path to seam
- path from seam to sink
- required privileges
- required configuration
- deployment assumptions

If no attacker-controlled path reaches the sink, terminate as theoretical.

**Verdict**: reachable / unreachable

### 5. Duplicate / Framework-Handled

Check:
- DEAD-ENDS.md and DEAD-LEADS.md
- LEDGER.md
- GHSA / CVE / NVD
- vendor advisories and issue tracker
- framework documentation
- prior maintainer responses

If duplicate, mark duplicate. If framework mitigation is sufficient,
terminate.

**Verdict**: novel / duplicate / framework-handled

### 6. Belief Retrofitted

Check whether the belief existed in the original `brg.md`.

If the analysis worked backward from the PoC and invented a belief
to fit the observed behavior, the reasoning chain is suspect.

A valid finding must preserve lineage:

```
seam-map.md -> brg.md -> candidate -> PoC -> validation
```

If the belief was not discovered during the seam audit, either:
- downgrade the finding
- send it back to Discovery
- terminate as unsupported

**Verdict**: belief predates PoC / belief retrofitted

## SAD Review

After all 6 checks, dispatch SAD to review the validation outcome.
SAD checks whether the validation was thorough or whether it
rubber-stamped a weak candidate.

## Severity Assignment

Severity is assigned after validation, not before.

The shipped severity must be based on:
- validated impact
- attacker prerequisites
- affected confidentiality/integrity/availability
- deployment assumptions
- exploit reliability
- scope change

Use CVSS or equivalent. Severity is a calibrated estimate, not ground truth.
Outcome data later updates calibration.

## Output

```
Finding: [ID]
Check 1 (Claim):       verdict
Check 2 (Wrong-Reason): verdict
Check 3 (Hidden Guard): verdict
Check 4 (Reachability): verdict
Check 5 (Duplicate):    verdict
Check 6 (Retrofitted):  verdict
Severity: CVSS X.X
validation-report.md written
State: VALIDATED | DEAD-END
```

## CHAIN POLICY

The operator does NOT approve subsequent phases.

On completion:
- **SUCCESS** (all 6 checks pass, state VALIDATED) ->
  **immediately invoke `/ship`**. No prompt.
- **DEAD-END** (any check fails) ->
  invoke `/close` with `status=DEAD-END, reason="<failed-check>: <evidence>"`.
