#!/usr/bin/env bash
# Flawless v3 — PostToolUse provenance logger.
# Reads stdin JSON from the hook, logs tool usage to pipeline/provenance.jsonl.
# Does NOT store full tool input/output — hashes only.
set -u

PHASE_FILE="pipeline/.phase"
LOG_FILE="pipeline/provenance.jsonl"
phase=""
[ -f "$PHASE_FILE" ] && phase=$(cat "$PHASE_FILE" 2>/dev/null | tr -d '[:space:]')

# Parse hook input
raw=$(cat 2>/dev/null || true)

if command -v jq >/dev/null 2>&1 && [ -n "$raw" ]; then
    tool=$(echo "$raw" | jq -r '.tool_name // "unknown"' 2>/dev/null)
    input_hash=$(echo "$raw" | jq -r '.tool_input // {}' 2>/dev/null | sha256sum | cut -c1-16)
    status=$(echo "$raw" | jq -r '.tool_status // "observed"' 2>/dev/null)
else
    tool="unknown"
    input_hash="no-jq"
    status="observed"
fi

timestamp=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
session_id="${FLAWLESS_SESSION_ID:-$(hostname)-$$}"
cwd=$(pwd)

# Append to provenance log
mkdir -p pipeline
echo "{\"timestamp\":\"$timestamp\",\"session_id\":\"$session_id\",\"phase\":\"$phase\",\"tool\":\"$tool\",\"input_hash\":\"$input_hash\",\"cwd\":\"$cwd\",\"status\":\"$status\"}" \
    >> "$LOG_FILE"

exit 0
