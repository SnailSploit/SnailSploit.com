#!/usr/bin/env bash
# Flawless v3 — PreCompact hook. On a long target the context compacts and the
# memory-router's in-process working scope evaporates. This snapshots the active
# finding's state + open candidates to disk first, so post-compaction the
# session can recall where it was. Fail-open.
set -u
ROOT="${CLAUDE_PROJECT_DIR:-$(cd "$(dirname "$0")/../.." && pwd)}"
SNAP="$ROOT/pipeline/.precompact-snapshot.md"
{
  echo "# pre-compact snapshot — $(date -u +%FT%TZ)"
  echo
  if [ -f "$ROOT/pipeline/.phase" ]; then echo "active phase: $(cat "$ROOT/pipeline/.phase")"; fi
  for d in DISCOVERED CANDIDATE POC-READY VALIDATED; do
    if [ -d "$ROOT/pipeline/$d" ]; then
      found=$(ls "$ROOT/pipeline/$d" 2>/dev/null)
      [ -n "$found" ] && { echo; echo "## $d"; echo "$found"; }
    fi
  done
  echo
  echo "(recall this file after compaction to resume; it is regenerated each compaction.)"
} > "$SNAP" 2>/dev/null
echo "[flawless] working state snapshotted to pipeline/.precompact-snapshot.md"
exit 0
