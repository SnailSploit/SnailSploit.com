#!/usr/bin/env bash
# Flawless v3 — SessionStart hook. stdout is injected into Claude's context at
# boot (and on resume, source=resume). This is the un-skippable replacement for
# v1's manual `bash verify.sh`. It tells a fresh session the ground truth ON
# DISK before the model acts: checker count, semantic-index freshness,
# Claude-Red presence. Fail-open: never blocks a session.
set -u
ROOT="${CLAUDE_PROJECT_DIR:-$(cd "$(dirname "$0")/../.." && pwd)}"
PY="$ROOT/infra/.venv/bin/python"; [ -x "$PY" ] || PY=python3

echo "=== FLAWLESS v3 boot ==="
N=$(ls "$ROOT/.claude/agents"/pattern-*-checker.md 2>/dev/null | wc -l | tr -d ' ')
echo "pattern checkers on disk: $N (analyze dispatches this many; the verifier runs 1/candidate)"

bash "$ROOT/infra/lint/check-checker-count.sh" >/dev/null 2>&1 \
  && echo "count guard: prose matches disk" \
  || echo "count guard: WARNING — a prose file disagrees with disk ($N); trust disk"

# semantic index staleness (memory-router). Non-blocking warn.
if [ -f "$ROOT/infra/memory-router/backends/vector/build.py" ]; then
  if "$PY" "$ROOT/infra/memory-router/backends/vector/build.py" --check >/dev/null 2>&1; then
    echo "semantic index: fresh"
  else
    echo "semantic index: STALE or unbuilt — contradict/dead-end checks degraded until you run:"
    echo "  $PY infra/memory-router/backends/vector/build.py"
  fi
fi

# skill-router / Claude-Red presence
"$PY" - <<PYEOF 2>/dev/null || echo "skill-router: not importable yet (run install.sh)"
import sys; sys.path.insert(0,"$ROOT/infra/skill-router-mcp")
import server as r
st=r.router_status()
print(f"skill-router: {st['skills_discovered']} skills under {st['roots'] or '(no roots found — set CLAUDE_SKILLS_DIR / clone Claude-Red)'}")
PYEOF
echo "next: /flawless"
