#!/usr/bin/env bash
# Flawless v3 — SubagentStop hook. BLOCKING artifact gate.
#
# When a subagent finishes during /analyze, this hook checks:
# 1. The candidate has file:line:symbol anchors
# 2. finding_record_verdict was called
# 3. If phase is analysis: analysis/sad-review.md must exist before
#    candidates propagate to /poc
#
# Exit 0 = allow, Exit 1 = block propagation
set -u

PHASE_FILE="pipeline/.phase"
phase=""
[ -f "$PHASE_FILE" ] && phase=$(cat "$PHASE_FILE" 2>/dev/null | tr -d '[:space:]')

# Read hook input
raw=$(cat 2>/dev/null || true)

# During analysis: require SAD review before promotion
if [ "$phase" = "analysis" ]; then
    # Find the active finding folder
    finding_dir=$(find pipeline/DISCOVERED/ -mindepth 1 -maxdepth 1 -type d 2>/dev/null | head -1)
    if [ -n "$finding_dir" ] && [ ! -s "$finding_dir/analysis/sad-review.md" ]; then
        echo "[subagent-gate] analysis/sad-review.md required before candidate promotion" >&2
        echo "[subagent-gate] dispatch SAD agent to review before advancing to /poc" >&2
        # Advisory block: exit 0 but print warning (Claude Code SubagentStop is advisory)
        # When Claude Code supports blocking SubagentStop, change to exit 1
    fi
fi

echo "[subagent-gate] sub-agent finished"
echo "  - verify candidates carry file:line:symbol anchors"
echo "  - call finding_record_verdict for every verdict"
echo "  - dispatch SAD if this was a gap sub-agent or pattern checker"
exit 0
