---
name: flawless-engine
description: Agenda-less semantic vulnerability discovery on a single target. Audits boundary seams — join points where two components share state but hold divergent, unstated assumptions — using the Belief/Reality/Gap method. Use when hunting CVEs in open-source code, auditing a repo for security bugs, running the FLAWLESS pipeline, or when the operator says "intake", "discover", "analyze a target", "find vulns", "assumption audit", or "B/R/G". Pairs with Claude-Red technique skills (offensive-toctou, offensive-unsafe-deserialization, offensive-sandbox-escape, etc.) which load on demand per pattern.
---

# Flawless Engine — agenda-less semantic vulnerability discovery

A vulnerability is the gap between what a component's code **assumes** and what
the runtime **actually does**. Find the assumption, characterize the reality,
and the hole sits in the difference. This is not a scanner and not a CVE
matcher — it reasons about misplaced belief at trust boundaries.

## Core principle — agenda-less seam mapping

Do **not** name a bug class or pick a methodology up front. Entry IS discovery:

1. Open the target.
2. Map every boundary seam semantically (trace control/state flow across trust boundaries).
3. Write Belief / Reality / Gap for each seam.
4. Let patterns attach *after*, emerging from what the seams reveal.

The per-pattern checker agents each carry a focused agenda; the operator does not.
Treat all agent output as hypotheses, not verdicts.

## Belief / Reality / Gap

- **Belief** — a proposition the surrounding code's correctness depends on,
  inferred from how data is *used* (not from comments). **Always anchored** to
  `file:line:symbol`. An unanchored belief is speculation and is dropped, not softened.
- **Reality** — a model of the state space the component actually encounters at
  the moment the belief is relied upon, under adversarial input. Characterized
  from runtime spec, adjacent producing code, deployment topology, attacker reach.
- **Gap** — states permitted by Reality but forbidden by Belief. A non-empty gap
  is a candidate. Then ask: **Reachable? Consequential? Exploitable?**

The Gap is the candidate seed. The pattern is only the lens that makes it concrete.

## The pipeline (auto-chained)

`/intake → /discover → /analyze → /poc → /validate → /ship → /close`
plus `/outcome` (ground-truth loop, run when a disclosure resolves).

- **discover** — enumerate ALL seams (usually 8–15); write `SEAM-MAP.md` + `BRG.md`.
- **analyze** — dispatch **14** pattern-checker subagents (the v2 P1–P9 taxonomy,
  carried under legacy M-ids for the 198 pre-refactor findings) in parallel, then
  the `pattern-verifier` once per candidate. See `references/patterns.md`.
- **poc** — build a runnable PoC, execute against the real target, capture run-log.
  Memory-corruption → ASAN/UBSAN/MSAN oracle. Logic bug → assertion/callback oracle.
- **validate** — 5 adversarial checks (re-anchor, attack belief/pattern, stress
  reality, CVSS sanity, dedup).
- **ship** — mechanical commit gate (folder/PoC/run-log freshness/anchor resolve).
- **close** — record to LEDGER; rebuild the semantic index if stale.
- **outcome** — record the vendor's verdict; a rejection becomes a future refutation.

## Verify, don't trust the checkers

Checker agents are confident-sounding but error-prone. Before promoting a
candidate, **read the cited anchor and verify the claim**. Recurring false
positives (from real sessions): claiming `global` reaches the host realm in a
sandbox that injects `var global = {}`; claiming `new char[len+1]` wraps on
64-bit where `len` widens to `size_t`; claiming a uint32 overflow yields OOB
writes when the consumer loop bound uses the same truncated count. The verifier
checks these per pattern; the operator confirms.

## Real PoCs only

A PoC must **execute the vulnerable path and observe the bug occur** — sanitizer
report for memory corruption, observed side-effect for logic bugs, a runtime mock
loading the actual production module for server-side logic. **Forbidden:**
static-trace PoCs that assert the bug by inspection. If a runtime PoC is hard,
build the harness; do not claim VULNERABLE on a code read.

## Technique depth comes from skills, on demand

When a pattern is live on a seam, pull the matching Claude-Red technique skill
via the skill-router MCP (`skill_match` to find it, `skill_get` to load it) — or
let it load by description-match. The engine carries the *method*; the technique
skills carry the *how-to-exploit*. See `references/claude-red-map.md`.

## Invariants

1. Anchored hypotheses only — `file:line:symbol` or dropped.
2. No exfiltration — target source/findings never leave allowed domains.
3. Real PoCs only — execution, not inspection.
4. Verifier is mandatory before any candidate ships.
5. One observability surface — every tool call logs one line to `pipeline/provenance.jsonl`.
6. Empties are useful — a checker returning zero candidates rules out a class; finding nothing is a valid result.
7. Patterns are gap classes, never static CVE templates.
8. Disk is authoritative — prose counts (CLAUDE.md, this file) must match the agent files; the SessionStart hook asserts it.
