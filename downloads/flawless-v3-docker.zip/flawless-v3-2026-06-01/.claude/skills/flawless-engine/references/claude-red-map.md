# Pattern → Claude-Red technique skill map

When a pattern is live on a seam, the skill-router (`skill_match`) ranks the
Claude-Red skills whose description fits; `skill_get` pulls the body. The router
is description-driven, so this map is a guide, not a hardcode — it works against
whatever skills are present under CLAUDE_SKILLS_DIR.

| FLAWLESS pattern | Likely Claude-Red skill(s) |
|------------------|----------------------------|
| P3 TOCTOU | offensive-toctou, offensive-business-logic (race) |
| P4 Dual-Store | offensive-business-logic, offensive-toctou |
| P7 Unsafe-Deserialization | offensive-unsafe-deserialization (deser/object-injection) |
| P8 Cryptographic-Misuse | offensive crypto skill (jwt / alg-confusion / timing) |
| P9 Sandbox-Escape | offensive-sandbox-escape, offensive-windows-boundaries (where relevant) |
| P1/P2/P6 | usually checker-only; pull a skill only if a sink type (SQLi, SSRF, injection) is concretely in play |

Install Claude-Red and point the router at it:
  git clone https://github.com/SnailSploit/Claude-Red ~/.claude/skills/claude-red
  export CLAUDE_SKILLS_DIR=~/.claude/skills
