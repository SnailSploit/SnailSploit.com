# Patterns (v2 taxonomy — 9 core)

Loaded on demand by the engine skill. Authoritative taxonomy lives in
`pipeline/METHODOLOGIES.md`; this is the analyze-time quick reference.

| ID | Name | One-line shape |
|----|------|----------------|
| P1 | Invariant-Not-Enforced | Validator/docs/types promise a property the implementation doesn't enforce. |
| P2 | Parsing-Disagreement | Two parsers see the same bytes differently; a security decision rides on one. |
| P3 | TOCTOU | Property checked at T1, used at T2, attacker-reachable state change between. |
| P4 | Dual-Store | Same value in two stores; a writer updates one; a reader trusts the stale one. |
| P5 | Fix-Did-Not-Propagate | A known fix isn't applied here. Subtypes: SIBLING, FRESH-FEATURE, BACKPORT, UNASSIGNED-CVE. |
| P6 | Error-Semantic | Two components disagree on an error's meaning; the lenient side carries a security decision. |
| P7 | Unsafe-Deserialization | Turing-complete decoder (pickle, marshal, YAML, ObjectInputStream) on bytes that cross a trust boundary. |
| P8 | Cryptographic-Misuse | Wrong primitive, predictable IV, weak RNG, non-constant-time compare, alg-confusion, key reuse. |
| P9 | Sandbox-Escape | Code in a sandbox primitive (vm2, isolated-vm, V8 isolate, pyodide, eBPF) reaches the host realm. |

The 14 checker agents map to these: P5 fans into the four fix-propagation
subtypes (4 checkers), the rest are 1:1, plus the legacy M-numbered files kept
for the 198 pre-refactor findings. The verifier runs once per candidate
regardless of pattern.
