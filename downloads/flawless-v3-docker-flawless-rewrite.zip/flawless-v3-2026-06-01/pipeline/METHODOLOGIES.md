# FLAWLESS Methodologies

FLAWLESS uses 18 checker agents mapped to 13 conceptual patterns. The BRG audit leads; checkers classify and backstop uncovered seams.

## Checker agents

M1 incomplete-fix / sibling
M2 cross-protocol
M3 fresh-feature
M4 backport-gap
M5 unassigned-cve
M6 lossy-validation
M7 dual-store
M8 toctou
M9 implicit-contract
M10 parsing-oracle
M11 authority-context-confusion
M12 error-semantic
M13 canonicalization-drift
M14 capability-lifetime-drift
M15 policy-composition-failure
P7 unsafe-deserialization
P8 cryptographic-misuse
P9 sandbox-boundary-failure

## Conceptual map

P1 Invariant Failure: M6, M9
P2 Interpretation Disagreement: M2, M10, M13
P3 Temporal Divergence: M8, M14
P4 State Duplication Divergence: M7
P5 Fix Propagation Failure: M1, M3, M4, M5
P6 Error Semantic Divergence: M12
P7 Unsafe Deserialization: P7
P8 Crypto Misuse: P8
P9 Sandbox Boundary Failure: P9
P10 Authority Context Failure: M11
P11 Policy Composition Failure: M15
P12 Chain Amplification: Layer 3B chain-builder
P13 Proof / Oracle Failure: Validation and ship gate

## Dispatch rule

Stage A dispatches one subagent per BRG gap. Stage B dispatches checker agents only on uncovered seams listed in `analysis/agent-plan.json`.

No full-surface checker swarm.
