#!/usr/bin/env bash
# hash-finding-folder.sh — compute or verify deterministic SHA-256 over a finding folder.
set -euo pipefail
mode=write
if [ "${1:-}" = "--check" ]; then mode=check; shift; fi
if [ $# -lt 1 ]; then echo "usage: $0 [--check] <finding-folder>" >&2; exit 2; fi
DIR="$1"
[ -d "$DIR" ] || { echo "$0: $DIR is not a directory" >&2; exit 2; }
HASHFILE="$DIR/FINDING.sha256"
compute_hash() {
  find "$DIR" -type f ! -name 'FINDING.sha256' -print0 | sort -z | xargs -0 sha256sum | sha256sum | awk '{print $1}'
}
HASH="$(compute_hash)"
if [ "$mode" = check ]; then
  [ -s "$HASHFILE" ] || { echo "missing FINDING.sha256" >&2; exit 1; }
  STORED="$(awk '{print $1}' "$HASHFILE" | head -1)"
  [ "$STORED" = "$HASH" ] || { echo "stale FINDING.sha256: stored=$STORED current=$HASH" >&2; exit 1; }
  echo "FINDING.sha256 fresh: $HASH"
  exit 0
fi
echo "$HASH" > "$HASHFILE"
echo "FINDING.sha256: $HASH"
