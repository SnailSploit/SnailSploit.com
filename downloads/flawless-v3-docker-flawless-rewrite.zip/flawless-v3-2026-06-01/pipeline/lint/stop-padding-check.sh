#!/usr/bin/env bash
# FLAWLESS Stop hook — anti-padding check.
set -euo pipefail
ROOT="${CLAUDE_PROJECT_DIR:-$(pwd)}"
PHASE_FILE="$ROOT/pipeline/.phase"
[ -f "$PHASE_FILE" ] || exit 0
phase="$(tr -d '[:space:]' < "$PHASE_FILE")"
[ -n "$phase" ] || exit 0
find_active(){ for base in "$ROOT/pipeline/DISCOVERED" "$ROOT/pipeline/CANDIDATE" "$ROOT/pipeline/VALIDATED" "$ROOT/pipeline/READY-TO-SHIP"; do [ -d "$base" ] || continue; find "$base" -mindepth 1 -maxdepth 1 -type d 2>/dev/null | sort | head -1; done | head -1; }
dir="$(find_active)"
[ -n "$dir" ] || exit 0
missing=""
case "$phase" in
  discovery) [ -s "$dir/seam-map.md" ] || missing="$missing seam-map.md"; [ -s "$dir/brg.md" ] || missing="$missing brg.md" ;;
  analysis|precision) [ -s "$dir/analysis/agent-plan.json" ] || missing="$missing analysis/agent-plan.json" ;;
  poc) [ -s "$dir/poc/run-log.md" ] || missing="$missing poc/run-log.md" ;;
  validation) [ -s "$dir/validation-report.md" ] || missing="$missing validation-report.md" ;;
  ship) [ -s "$dir/FINDING.sha256" ] || missing="$missing FINDING.sha256" ;;
esac
[ -z "$missing" ] || { echo "[stop-gate] BLOCKED: phase '$phase' missing:$missing" >&2; exit 2; }
exit 0
