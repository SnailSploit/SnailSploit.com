#!/usr/bin/env python3
"""Block writes to FLAWLESS control files unless phase is maintenance."""
import json, os, sys
ROOT=os.path.abspath(os.environ.get('CLAUDE_PROJECT_DIR') or os.getcwd())
PHASE=os.path.join(ROOT,'pipeline','.phase')
PROTECTED=['.claude/settings.json','.claude/policy.yaml','.claude/hooks','.claude/agents','pipeline/lint','pipeline/.phase']
WRITE_TOOLS={'Write','Edit','MultiEdit','NotebookEdit','Bash'}

def phase():
    try: return open(PHASE).read().strip()
    except FileNotFoundError: return ''

def norm(p):
    return os.path.abspath(p if os.path.isabs(p) else os.path.join(ROOT,p))

def is_protected(p):
    n=norm(p)
    for rel in PROTECTED:
        q=norm(rel)
        if n==q or n.startswith(q+os.sep): return True
    return False

def deny(msg):
    print('[protected-path] BLOCKED: '+msg, file=sys.stderr)
    sys.exit(1)

def main():
    try: payload=json.loads(sys.stdin.read() or '{}')
    except Exception: sys.exit(0)
    tool=payload.get('tool_name','')
    inp=payload.get('tool_input',{}) or {}
    if tool not in WRITE_TOOLS: sys.exit(0)
    if phase()=='maintenance': sys.exit(0)
    path=inp.get('file_path') or inp.get('path') or ''
    if path and is_protected(path): deny('cannot modify '+repr(path)+' outside maintenance')
    if tool=='Bash':
        cmd=str(inp.get('command',''))
        if any(rel in cmd for rel in PROTECTED) and any(x in cmd for x in ['>','rm ','mv ','cp ','chmod ','chown ','tee ','sed ','perl ','python']):
            deny('bash command appears to modify protected control files')
    sys.exit(0)
if __name__=='__main__': main()
