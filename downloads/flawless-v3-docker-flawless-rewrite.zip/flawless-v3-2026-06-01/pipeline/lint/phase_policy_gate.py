#!/usr/bin/env python3
"""FLAWLESS phase-policy gate. Active phases default-deny."""
import json, os, re, sys
try:
    import yaml
except Exception:
    sys.exit(0)

ROOT=os.environ.get('CLAUDE_PROJECT_DIR') or os.getcwd()
PHASE_FILE=os.path.join(ROOT,'pipeline','.phase')
POLICY_FILE=os.path.join(ROOT,'.claude','policy.yaml')

def read_payload():
    try:
        p=json.loads(sys.stdin.read() or '{}')
        return str(p.get('tool_name','')), p.get('tool_input',{}) or {}
    except Exception:
        sys.exit(0)

def first_bash_token(cmd):
    cmd=(cmd or '').strip()
    if not cmd: return ''
    # If a shell wrapper is used, inspect the wrapped string roughly.
    m=re.match(r'^(?:[A-Za-z_][A-Za-z0-9_]*=\S+\s+)*(?:sudo\s+|env\s+|command\s+)?(?:bash|sh)\s+-(?:c|lc)\s+["\']?([^"\']+)', cmd)
    if m: cmd=m.group(1).strip()
    m=re.match(r'^(?:[A-Za-z_][A-Za-z0-9_]*=\S+\s+)*(?:sudo\s+|env\s+|command\s+)?([^\s;&|()]+)', cmd)
    if not m: return ''
    return os.path.basename(m.group(1))

def tokens(tool, inp):
    if tool != 'Bash':
        return [tool]
    first=first_bash_token(str(inp.get('command','')))
    out=[]
    if first: out.append('Bash:'+first)
    out.extend(['Bash','Bash:*'])
    return out

def deny(msg):
    print('[phase-gate] DENIED: '+msg, file=sys.stderr)
    sys.exit(1)

def main():
    tool, inp=read_payload()
    try:
        phase=open(PHASE_FILE).read().strip()
    except FileNotFoundError:
        sys.exit(0)
    if not phase: sys.exit(0)
    try:
        policy=yaml.safe_load(open(POLICY_FILE)) or {}
    except Exception:
        sys.exit(0)
    phases=policy.get('phases') or {}
    if phase not in phases:
        sys.exit(0)
    cfg=phases.get(phase) or {}
    allowed=set(cfg.get('allowed_tools') or [])
    blocked=set(cfg.get('blocked_tools') or [])
    toks=tokens(tool, inp)
    if '*' in allowed or any(t in allowed for t in toks):
        sys.exit(0)
    if '*' in blocked or any(t in blocked for t in toks):
        deny(repr(tool)+' blocked in phase '+repr(phase)+' tokens='+repr(toks))
    deny(repr(tool)+' not allowed in phase '+repr(phase)+' tokens='+repr(toks))

if __name__ == '__main__':
    main()
