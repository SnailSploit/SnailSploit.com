#!/usr/bin/env bash
# FLAWLESS precommit ship gate. Blocks git commit when staged READY-TO-SHIP findings fail lint.
set -euo pipefail
input=$(cat)
command -v jq >/dev/null 2>&1 || { echo "[ship-gate] jq missing; cannot lint commit" >&2; exit 0; }
cmd=$(echo "$input" | jq -r '.tool_input.command // ""')
cwd=$(echo "$input" | jq -r '.cwd // ""')
echo "$cmd" | grep -Eq '(^|[;&|()[:space:]])git[[:space:]]+commit([[:space:]]|$)' || exit 0
if [ -n "$cwd" ] && [ -d "$cwd" ]; then repo_root=$(cd "$cwd" && git rev-parse --show-toplevel 2>/dev/null || true); else repo_root=$(git rev-parse --show-toplevel 2>/dev/null || true); fi
[ -n "$repo_root" ] || exit 0
[ -d "$repo_root/pipeline/lint" ] || exit 0
staged=$(cd "$repo_root" && git diff --cached --name-only 2>/dev/null || true)
finding_folders=$(echo "$staged" | grep -oE '^pipeline/READY-TO-SHIP/[a-z0-9][a-z0-9-]*-[0-9]{14}/' | sort -u || true)
[ -n "$finding_folders" ] || exit 0
failed=""; messages=""
for folder in $finding_folders; do
  [ -d "$repo_root/$folder" ] || continue
  if ! out=$(cd "$repo_root" && pipeline/lint/check-finding-folder.sh "$folder" 2>&1); then
    failed="$failed $folder"
    messages="$messages
$out"
  fi
done
[ -z "$failed" ] && exit 0
reason="FLAWLESS ship-gate: lint failures in:$failed

$messages

Fix the listed Layer 6 failures before committing."
jq -n --arg reason "$reason" '{hookSpecificOutput:{hookEventName:"PreToolUse",permissionDecision:"deny",permissionDecisionReason:$reason}}'
exit 0
