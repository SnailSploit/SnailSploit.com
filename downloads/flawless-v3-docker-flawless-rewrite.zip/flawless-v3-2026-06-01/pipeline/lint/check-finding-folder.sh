#!/usr/bin/env bash
# check-finding-folder.sh — FLAWLESS v3 ship gate.
# Validates a finding folder against the 9 canonical ship checks + 2 extras.
# Called by precommit-ship-gate.sh and by hand.
#
# The 9+2 checks:
#   1. advisory/DISCLOSURE.md exists and is non-empty.
#   2. poc/ contains executable PoC source.
#   3. poc/run-log.md exists and is non-empty.
#   4. poc/run-log.md mtime is newer than newest PoC source mtime.
#   5. poc/run-log.md contains a verdict line.
#   6. All internal anchors resolve.
#   7. Disclosure contains a pinned 40-char target commit hash.
#   8. Disclosure contains severity.
#   9. Finding folder has a stored content hash (FINDING.sha256).
#  10. run-log names the oracle type.
#  11. run-log documents a negative control.
#
# Returns 0 on pass, 1 on fail.

set -euo pipefail

FAIL=0
note() { echo "  [FAIL] $*" >&2; FAIL=1; }
pass() { echo "  [ ok ] $*"; }

if [ $# -lt 1 ]; then echo "usage: $0 <finding-folder>" >&2; exit 2; fi
DIR="$1"
[ -d "$DIR" ] || { echo "$0: $DIR is not a directory" >&2; exit 2; }

echo "ship-gate lint: $DIR"

# Portable mtime
if stat -c '%Y' / >/dev/null 2>&1; then
    _mtime() { stat -c '%Y' "$1"; }
else
    _mtime() { stat -f '%m' "$1"; }
fi

# --- Check 1: advisory/DISCLOSURE.md ---
if [ -s "$DIR/advisory/DISCLOSURE.md" ]; then
    pass "1. advisory/DISCLOSURE.md present"
else
    note "1. missing or empty advisory/DISCLOSURE.md"
fi

# --- Check 2: PoC source ---
poc_sources=$(find "$DIR/poc" -maxdepth 1 -type f \
    \( -name '*.py' -o -name '*.go' -o -name '*.rb' -o -name '*.js' -o -name '*.ts' \
       -o -name '*.sh' -o -name '*.rs' -o -name '*.c' -o -name '*.cpp' -o -name '*.java' \
       -o -name '*.php' -o -name '*.pl' -o -name '*.zig' -o -name '*.mjs' \) \
    2>/dev/null | grep -v 'run-log\|README' || true)
if [ -n "$poc_sources" ]; then
    pass "2. PoC source present ($(echo "$poc_sources" | wc -l | tr -d ' ') file(s))"
else
    note "2. no PoC source file under poc/"
fi

# --- Check 3: poc/run-log.md (exact path, no fuzzy) ---
RUNLOG="$DIR/poc/run-log.md"
if [ -s "$RUNLOG" ]; then
    pass "3. poc/run-log.md present"
else
    note "3. missing or empty poc/run-log.md (exact path required)"
fi

# --- Check 4: run-log.md mtime newer than PoC source ---
if [ -s "$RUNLOG" ] && [ -n "$poc_sources" ]; then
    newest_poc_t=0
    for f in $poc_sources; do
        t=$(_mtime "$f" 2>/dev/null || echo 0)
        [ "$t" -gt "$newest_poc_t" ] && newest_poc_t=$t
    done
    log_t=$(_mtime "$RUNLOG" 2>/dev/null || echo 0)
    if [ "$newest_poc_t" -gt 0 ] && [ "$log_t" -gt 0 ]; then
        if [ "$newest_poc_t" -gt "$log_t" ]; then
            note "4. PoC source modified AFTER run-log.md (re-run needed)"
        else
            pass "4. run-log.md newer than PoC source"
        fi
    fi
fi

# --- Check 5: verdict line in run-log ---
if [ -s "$RUNLOG" ]; then
    if grep -Eq '\bVULNERABLE\b|\bPASS\b|\bEXIT 0\b|\bNOT-REPRODUCIBLE\b' "$RUNLOG"; then
        pass "5. verdict line found in run-log.md"
    else
        note "5. run-log.md missing verdict line (VULNERABLE/PASS/EXIT 0)"
    fi
fi

# --- Check 6: anchors resolve ---
unresolved=0
if [ -s "$DIR/advisory/DISCLOSURE.md" ]; then
    cites=$(grep -oE '[a-zA-Z0-9_/.-]+\.[a-z]{1,4}:[0-9]+' "$DIR/advisory/DISCLOSURE.md" | sort -u || true)
    for cite in $cites; do
        path="${cite%:*}"
        line="${cite##*:}"
        for prefix in "" "$DIR/" "pipeline/recon/"; do
            if [ -f "${prefix}${path}" ]; then
                total=$(wc -l < "${prefix}${path}")
                if [ "$line" -gt "$total" ]; then
                    note "6. anchor $cite past EOF ($total lines)"
                    unresolved=$((unresolved+1))
                fi
                break
            fi
        done
    done
fi
[ "$unresolved" -eq 0 ] && pass "6. internal anchors resolve"

# --- Check 7: pinned 40-char target commit hash ---
if [ -s "$DIR/advisory/DISCLOSURE.md" ]; then
    if grep -Eq '\b[0-9a-f]{40}\b' "$DIR/advisory/DISCLOSURE.md"; then
        pass "7. target commit hash pinned"
    else
        note "7. no 40-char commit hash in advisory/DISCLOSURE.md"
    fi
fi

# --- Check 8: severity assigned ---
if [ -s "$DIR/advisory/DISCLOSURE.md" ]; then
    if grep -Eiq '\bCVSS\b|Severity:[[:space:]]*(Critical|High|Medium|Low|Informational)' \
        "$DIR/advisory/DISCLOSURE.md"; then
        pass "8. severity assigned"
    else
        note "8. no CVSS or severity rating in advisory/DISCLOSURE.md"
    fi
fi

# --- Check 9: FINDING.sha256 exists ---
if [ -s "$DIR/FINDING.sha256" ]; then
    if pipeline/lint/hash-finding-folder.sh --check "$DIR" >/dev/null 2>&1; then
        pass "9. content hash present and fresh (FINDING.sha256)"
    else
        note "9. FINDING.sha256 is stale or unverifiable (run hash-finding-folder.sh)"
    fi
else
    note "9. missing FINDING.sha256 (run hash-finding-folder.sh)"
fi

# --- Check 10: oracle type named ---
if [ -s "$RUNLOG" ]; then
    if grep -Eiq 'oracle:[[:space:]]*(crash|state|response|callback)' "$RUNLOG"; then
        pass "10. oracle type named in run-log"
    else
        note "10. run-log does not name oracle type (oracle: crash|state|response|callback)"
    fi
fi

# --- Check 11: negative control documented ---
if [ -s "$RUNLOG" ]; then
    if grep -Eiq 'negative control|negative test|control input|should not trigger' "$RUNLOG"; then
        pass "11. negative control documented in run-log"
    else
        note "11. run-log does not document a negative control"
    fi
fi

# --- Methodology leakage check (bonus, uses denylist) ---
DENYLIST="pipeline/lint/METHODOLOGY_LEAKAGE_DENYLIST.txt"
if [ -s "$DIR/advisory/DISCLOSURE.md" ] && [ -f "$DENYLIST" ]; then
    leaked=""
    while IFS= read -r term || [ -n "$term" ]; do
        [ -z "$term" ] && continue
        [[ "$term" =~ ^# ]] && continue
        if grep -Fiq "$term" "$DIR/advisory/DISCLOSURE.md"; then
            leaked="$leaked '$term'"
        fi
    done < "$DENYLIST"
    if [ -n "$leaked" ]; then
        note "LEAKAGE: internal terms in DISCLOSURE.md:$leaked"
    else
        pass "no internal methodology leakage"
    fi
fi

echo ""
if [ "$FAIL" -ne 0 ]; then
    echo "ship-gate: $DIR -> BLOCKED ($FAIL check(s) failed)"
    exit 1
fi
echo "ship-gate: $DIR -> PASS (all 11 checks)"
exit 0
