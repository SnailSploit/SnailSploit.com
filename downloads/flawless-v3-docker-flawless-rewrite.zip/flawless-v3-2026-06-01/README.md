# FLAWLESS v3 Docker

Agenda-less semantic vulnerability engine. FLAWLESS audits boundary seams with Belief / Reality / Gap, dispatches gap-seeded subagents, uses pattern checkers only on uncovered seams, composes surviving gaps into exploitability chains, builds real executable PoCs, and ships through a deterministic gate.

This package includes the FLAWLE$$ architecture update:

- **18 checker agents total**: M1-M15 plus P7/P8/P9.
- **Layer 3B Chain Builder** with `ChainScore`.
- **11 ship checks** including named oracle and negative control.
- **READY-TO-SHIP staging** before `SHIPPED`.
- **Default-deny phase policy** while `pipeline/.phase` is active.
- **Protected-path gate** for hooks, policy, agents, and lint scripts.
- **SAD as an artifact gate**, not a reminder.

Full architecture: `docs/ARCHITECTURE.md`.

## Install

```sh
bash install.sh
bash verify.sh
```

Then open this directory in Claude Code and run `/flawless`.

## Layout

- `docs/ARCHITECTURE.md` — full architecture.
- `CLAUDE.md` — boot file and operational invariants.
- `.claude/agents/` — 18 checker agents, `chain-builder`, `pattern-verifier`, `sad`.
- `.claude/commands/` — pipeline commands.
- `.claude/hooks/` — lifecycle hooks.
- `pipeline/lint/` — deterministic gates.
- `infra/` — MCP servers, memory router, skill router, and drift checks.

## Core law

```text
A seam is where state crosses a boundary.
A gap is where belief and reality diverge.
A chain is a reachable path through one or more gaps to a sink.
A finding is a validated chain with a fresh oracle.
```

Built by Kai Aizen (SnailSploit).
