# FLAWLE$$ / FLAWLESS — Architecture Paper

**Find where two components share state but disagree about it.**

*Kai Aizen / SnailSploit · Adversarial Research*

## Core thesis

FLAWLESS is a seam-first semantic vulnerability-research engine. It does not begin with bug classes. It begins with boundary seams: places where two components share state while carrying possibly divergent assumptions.

> A vulnerability is the gap between what code believes is true and what is actually true at runtime.

## Core law

```text
A seam is where state crosses a boundary.
A gap is where belief and reality diverge.
A chain is a reachable path through one or more gaps to a sink.
A finding is a validated chain with a fresh oracle.
```

Pipeline:

```text
Discovery -> Agent -> Early Precision -> Chain Builder -> PoC -> Validation -> Ship -> Outcome
```

State machine:

```text
DISCOVERED -> CANDIDATE -> POC-READY -> VALIDATED -> READY-TO-SHIP -> SHIPPED -> CLOSED
```

Any phase can route to `DEAD-END`; temporary states are `BLOCKED` and `STOP`.

Workflow phases are separate from states:

```text
intake, discovery, analysis, precision, poc, validation, ship, outcome, maintenance
```

## Shared state

Shared state includes any value, fact, identity, capability, policy decision, lock, token, context, path, interpretation, or invariant relied on by more than one component: request parameters, file paths, URLs, tenant IDs, sessions, authorization results, capabilities, caches, database rows, serialized objects, parser outputs, error codes, sandbox policies, file descriptors, repository slugs, workspace IDs, configuration values, and feature flags.

A seam only exists for pipeline purposes if it anchors to `file:line:symbol`.

## Belief / Reality / Gap

At each seam:

```text
Belief: what this code assumes another component has guaranteed.
Reality: what runtime actually permits.
Gap: where Belief differs from Reality.
```

No anchor, no candidate. No execution, no finding.

## Layer 1 — Discovery

Discovery enumerates seams, writes `seam-map.md` and `brg.md`, and keeps only falsifiable, anchored, source-supported, security-relevant gaps. Targets with fewer than six seams are treated as low-surface; they proceed only with explicit security-density justification.

## Layer 2 — Agent

FLAWLESS is gap-seeded, not pattern-seeded.

Stage A dispatches one subagent per BRG gap. Stage B dispatches checker agents only on seams left uncovered by Stage A. Before any subagent runs, `/analyze` writes `analysis/agent-plan.json`. No subagent may run unless it appears in that plan.

## Checker set

FLAWLESS uses 18 checker agents: 15 M-checkers and 3 domain hazard checkers.

```text
M1  incomplete-fix / sibling
M2  cross-protocol
M3  fresh-feature
M4  backport-gap
M5  unassigned-cve
M6  lossy-validation
M7  dual-store
M8  toctou
M9  implicit-contract
M10 parsing-oracle
M11 authority-context-confusion
M12 error-semantic
M13 canonicalization-drift
M14 capability-lifetime-drift
M15 policy-composition-failure
P7  unsafe-deserialization
P8  cryptographic-misuse
P9  sandbox-boundary-failure
```

Conceptual map:

```text
P1  Invariant Failure: M6, M9
P2  Interpretation Disagreement: M2, M10, M13
P3  Temporal Divergence: M8, M14
P4  State Duplication Divergence: M7
P5  Fix Propagation Failure: M1, M3, M4, M5
P6  Error Semantic Divergence: M12
P7  Unsafe Deserialization: P7
P8  Crypto Misuse: P8
P9  Sandbox Boundary Failure: P9
P10 Authority Context Failure: M11
P11 Policy Composition Failure: M15
P12 Chain Amplification: Layer 3B chain-builder
P13 Proof / Oracle Failure: Validation + ship gate
```

M11 catches authorization in context A with execution in context B. M13 catches checked and consumed representations that canonicalize into different objects. M14 catches capabilities that outlive revocation, expiry, or context change. M15 catches locally safe policies composing into unsafe allow.

## Layer 3 — Early Precision

Early Precision kills cheap false positives: unanchored, stale anchor, contradicted by source, known dead lead, maintainer-rejected pattern, framework-mitigated, unreachable sink, and hard barrier present.

## SAD — Skeptical Analysis Daemon

SAD is a chain-wide reviewer. It checks whether outputs follow from evidence. Valid verdicts are `CONFIRM`, `REFUTE`, `DOWNGRADE`, and `NEEDS-EVIDENCE`. SAD produces `analysis/sad-review.md`. If required SAD review is missing, propagation is blocked.

## Layer 3B — Chain Builder

Chain Builder composes surviving candidates into exploitability chains:

```text
E -> G+ -> S -> O
```

Where `E` is entry, `G+` is one or more gaps, `S` is sink, and `O` is oracle. Transforms and barriers may appear between them.

Scoring:

```text
ChainScore = (Reachability + Controllability + Impact + Proofability) - BarrierStrength
```

Hard rule: if `BarrierStrength = 3` and no earlier gap bypasses it, terminate regardless of score. Chain Builder writes `analysis/chains.md` when multiple candidates survive.

## Layer 4 — PoC

No static traces. Real execution only. The PoC must include a positive test, a negative control, a named oracle (`crash`, `state`, `response`, or `callback`), a fresh exact `poc/run-log.md`, and anchor recheck.

## Layer 5 — Validation

Validation tries to kill the finding with six checks: disprove the claim, wrong-reason PoC, hidden guard, sink reachability, duplicate/framework-handled, and belief retrofitted.

## Layer 6 — Ship

A validated finding enters `pipeline/READY-TO-SHIP/` before the gate and `pipeline/SHIPPED/` only after the gate passes.

The ship gate enforces 11 checks:

1. `advisory/DISCLOSURE.md` exists.
2. PoC source exists.
3. Exact `poc/run-log.md` exists.
4. Run-log is fresher than PoC source.
5. Verdict line exists.
6. Internal anchors resolve.
7. Target commit hash is pinned.
8. Vendor disclosure contains no internal methodology leakage.
9. Severity is assigned.
10. `FINDING.sha256` is present and fresh.
11. Run-log names oracle type and documents negative control.

No manual override exists.

## Layer 7 — Outcome

Vendor outcome is ground truth. Rejection becomes a DEAD-LEADS refutation. Acceptance calibrates severity and checker priors. Duplicate records prior-art failure. Outcome closes the loop.

## One-line mission

Find boundary seams. Extract the gap. Compose the chain. Prove the oracle. Ship clean. Learn from reality. Repeat.
