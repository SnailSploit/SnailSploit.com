#!/usr/bin/env bash
# FLAWLESS v3 verification — lightweight local drift and gate checks.
set -u
cd "$(dirname "$0")"
PY=python3
pass=0
fail=0
ok(){ echo "  [PASS] $1"; pass=$((pass+1)); }
no(){ echo "  [FAIL] $1"; fail=$((fail+1)); }

printf '%s\n' '===================================================' ' FLAWLESS v3 VERIFICATION' '==================================================='

$PY - <<'PYEOF' >/dev/null 2>&1
import json, yaml
json.load(open('.mcp.json'))
json.load(open('.claude/settings.json'))
yaml.safe_load(open('.claude/policy.yaml'))
PYEOF
[ $? -eq 0 ] && ok 'JSON/YAML config parses' || no 'JSON/YAML config parse failed'

N=$(find .claude/agents -maxdepth 1 -name 'pattern-*-checker.md' | wc -l | tr -d ' ')
[ "$N" = "18" ] && ok '18 checker agents on disk' || no "expected 18 checker agents, found $N"
[ -f .claude/agents/chain-builder.md ] && ok 'chain-builder agent present' || no 'chain-builder agent missing'
[ -f .claude/agents/pattern-verifier.md ] && ok 'pattern-verifier present' || no 'pattern-verifier missing'
[ -f .claude/agents/sad.md ] && ok 'SAD agent present' || no 'SAD agent missing'

bash infra/lint/check-checker-count.sh >/dev/null 2>&1 && ok 'checker-count drift guard passes' || no 'checker-count drift guard failed'
bash infra/lint/check-state-drift.sh >/dev/null 2>&1 && ok 'state/doc drift guard passes' || no 'state/doc drift guard failed'

echo validation > pipeline/.phase
printf '{"tool_name":"Read","tool_input":{}}' | timeout 5 $PY pipeline/lint/phase_policy_gate.py >/dev/null 2>&1
read_rc=$?
printf '{"tool_name":"Bash","tool_input":{"command":"python3 x.py"}}' | timeout 5 $PY pipeline/lint/phase_policy_gate.py >/dev/null 2>&1
bash_rc=$?
rm -f pipeline/.phase
if [ "$read_rc" -eq 0 ] && [ "$bash_rc" -ne 0 ]; then ok 'phase policy default-deny works'; else no "phase policy failed (Read=$read_rc Bash=$bash_rc)"; fi

echo analysis > pipeline/.phase
printf '{"tool_name":"Write","tool_input":{"file_path":".claude/settings.json"}}' | timeout 5 $PY pipeline/lint/protected_path_gate.py >/dev/null 2>&1
prot_rc=$?
rm -f pipeline/.phase
[ "$prot_rc" -ne 0 ] && ok 'protected-path gate blocks control-file writes' || no 'protected-path gate failed to block settings write'

hk=0
for h in sessionstart-boot subagentstop-enforce precompact-save-memory posttooluse-provenance; do
  [ -x ".claude/hooks/$h.sh" ] && hk=$((hk+1))
done
[ "$hk" -eq 4 ] && ok '4 hook scripts executable' || no "expected 4 executable hook scripts, found $hk"

sl=0
for s in check-finding-folder.sh hash-finding-folder.sh phase_policy_gate.py protected_path_gate.py precommit-ship-gate.sh check-agent-plan.sh check-chain-lineage.sh check-sad-review.sh stop-padding-check.sh; do
  [ -x "pipeline/lint/$s" ] && sl=$((sl+1))
done
[ "$sl" -eq 9 ] && ok '9 pipeline lint scripts executable' || no "expected 9 lint executables, counted $sl"

tmp=$(mktemp -d)
mkdir -p "$tmp/poc" "$tmp/advisory" "$tmp/analysis"
echo x > "$tmp/poc/poc.py"
echo 'verdict: VULNERABLE' > "$tmp/poc/run-log.md"
pipeline/lint/hash-finding-folder.sh "$tmp" >/dev/null 2>&1
pipeline/lint/hash-finding-folder.sh --check "$tmp" >/dev/null 2>&1
[ $? -eq 0 ] && ok 'finding hash write/check works' || no 'finding hash check failed'
rm -rf "$tmp"

printf '%s\n' '---------------------------------------------------'
if [ "$fail" -eq 0 ]; then
  echo " RESULT: ALL $pass CHECKS PASSED — FLAWLESS v3 package is internally consistent."
  printf '%s\n' '==================================================='
  exit 0
else
  echo " RESULT: $fail FAILED, $pass passed."
  printf '%s\n' '==================================================='
  exit 1
fi
