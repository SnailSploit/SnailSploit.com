# FLAWLESS v3 — boot file

Disk is authoritative. If prose and lint disagree, trust the hook/lint output and fix the prose.

## What FLAWLESS is

FLAWLESS is a seam-first vulnerability-research engine. It audits boundary seams: places where two components share state and each carries possibly divergent assumptions. The primitive is Belief / Reality / Gap.

## Core law

```text
A seam is where state crosses a boundary.
A gap is where belief and reality diverge.
A chain is a reachable path through one or more gaps to a sink.
A finding is a validated chain with a fresh oracle.
```

## Flow

```text
/intake <target> -> /discover -> /analyze -> /poc -> /validate -> /ship -> /close
```

`/outcome <finding-id>` runs later when the vendor responds.

Architecture:

```text
Discovery -> Agent -> Early Precision -> Chain Builder -> PoC -> Validation -> Ship -> Outcome
```

## Canonical phases

```text
intake discovery analysis precision poc validation ship outcome maintenance
```

## Canonical states

```text
DISCOVERED CANDIDATE POC-READY VALIDATED READY-TO-SHIP SHIPPED CLOSED DEAD-END BLOCKED STOP
```

States and phases are not the same thing.

## Analysis rule

Analysis is gap-seeded, not pattern-seeded. Stage A runs one subagent per BRG gap. Stage B runs checker agents only on seams left uncovered by Stage A.

Required before any subagent dispatch:

```text
analysis/agent-plan.json
```

## Checker inventory

There are **18 checker agents**:

```text
M1 incomplete-fix / sibling
M2 cross-protocol
M3 fresh-feature
M4 backport-gap
M5 unassigned-cve
M6 lossy-validation
M7 dual-store
M8 toctou
M9 implicit-contract
M10 parsing-oracle
M11 authority-context-confusion
M12 error-semantic
M13 canonicalization-drift
M14 capability-lifetime-drift
M15 policy-composition-failure
P7 unsafe-deserialization
P8 cryptographic-misuse
P9 sandbox-boundary-failure
```

## Chain Builder

After Early Precision, surviving candidates are composed into chains:

```text
E -> G+ -> S -> O
```

Ranking uses:

```text
ChainScore = (Reachability + Controllability + Impact + Proofability) - BarrierStrength
```

## SAD

SAD is the Skeptical Analysis Daemon. It checks whether outputs follow from evidence. Required artifact:

```text
analysis/sad-review.md
```

Valid verdicts: `CONFIRM`, `REFUTE`, `DOWNGRADE`, `NEEDS-EVIDENCE`.

## PoC rules

Required run-log:

```text
poc/run-log.md
```

It must include target commit, command, timestamp, candidate ID, seam ID, chain ID when applicable, positive test, negative control, oracle type, observed oracle, and verdict. Oracle types: `crash`, `state`, `response`, `callback`.

No static traces. Real execution only.

## Ship gate

`/ship` stages under `pipeline/READY-TO-SHIP/`. Only after the gate passes does a finding move to `pipeline/SHIPPED/`.

The ship gate enforces **11 checks**: report, PoC, exact run-log, fresh run-log, verdict, anchors, pinned commit, no methodology leakage, severity, fresh content hash, and oracle plus negative control.

No LLM discretion exists in the ship gate.

## First command

```sh
bash verify.sh
```
