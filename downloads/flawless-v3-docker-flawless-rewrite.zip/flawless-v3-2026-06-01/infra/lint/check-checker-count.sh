#!/usr/bin/env bash
# FLAWLESS checker-count drift guard. Disk is authoritative.
set -u
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
AGENTS="$ROOT/.claude/agents"
N=$(find "$AGENTS" -maxdepth 1 -name 'pattern-*-checker.md' | wc -l | tr -d ' ')
rc=0
echo "checkers on disk: $N"
[ "$N" -ge 1 ] || { echo "  [FAIL] no pattern-*-checker.md files in $AGENTS"; exit 1; }
FILES=(
  "$ROOT/.claude/commands/analyze.md"
  "$ROOT/.claude/commands/INDEX.md"
  "$ROOT/.claude/skills/flawless-engine/references/patterns.md"
  "$ROOT/pipeline/METHODOLOGIES.md"
  "$ROOT/docs/ARCHITECTURE.md"
  "$ROOT/CLAUDE.md"
  "$ROOT/README.md"
)
for f in "${FILES[@]}"; do
  [ -f "$f" ] || continue
  bn="${f#$ROOT/}"
  if grep -Eq "\b$N\b" "$f"; then
    echo "  [ ok ] $bn references $N"
  else
    echo "  [FAIL] $bn does not reference $N checker agents"
    rc=1
  fi
  if grep -qiE 'there is no M11|14 checker|14 pattern|9 conceptual|9 core' "$f" 2>/dev/null; then
    echo "  [FAIL] $bn contains a stale checker-count claim"
    rc=1
  fi
done
exit $rc
