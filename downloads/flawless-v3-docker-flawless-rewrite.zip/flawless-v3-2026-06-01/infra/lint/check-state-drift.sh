#!/usr/bin/env bash
# check-state-drift.sh — detect deprecated state/phase language across docs/config.
set -euo pipefail
FAIL=0
note() { echo "  [drift] $*" >&2; FAIL=1; }
FILES=(CLAUDE.md README.md docs/ARCHITECTURE.md .claude/commands/*.md .claude/policy.yaml pipeline/lint/*.sh .claude/hooks/*.sh)
PATTERN='LEGEND|READY_TO_SHIP|feasibility|closure phase|Shipped phase|shipped phase|14 pattern checkers|14 checker|7/7|9 mechanical checks|There is no M11|M11 \(never assigned\)'
echo "state-drift: scanning docs/config..."
for f in ${FILES[@]}; do
  [ -f "$f" ] || continue
  case "$f" in *check-state-drift.sh|*check-checker-count.sh) continue ;; esac
  hits=$(grep -Ein "$PATTERN" "$f" 2>/dev/null || true)
  if [ -n "$hits" ]; then
    while IFS= read -r line; do note "$f: $line"; done <<< "$hits"
  fi
done
[ "$FAIL" -eq 0 ] && echo "state-drift: clean"
exit $FAIL
