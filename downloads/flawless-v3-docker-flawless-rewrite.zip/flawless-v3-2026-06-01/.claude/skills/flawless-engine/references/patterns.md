# FLAWLESS Patterns — 18 Checker Agents / 13 Conceptual Patterns

This is the analyze-time quick reference. Full architecture: `docs/ARCHITECTURE.md`.

| ID | Checker | Shape |
|---|---|---|
| M1 | incomplete-fix / sibling | A fix or guard exists in one sibling path but not another. |
| M2 | cross-protocol | Protocol layers interpret shared state differently. |
| M3 | fresh-feature | A new feature reopens a previously fixed seam. |
| M4 | backport-gap | A fix exists upstream but is absent or partial in a supported branch. |
| M5 | unassigned-cve | A known security shape exists outside the advisory boundary. |
| M6 | lossy-validation | Validation checks a reduced representation and drops sink-relevant state. |
| M7 | dual-store | One security fact lives in two stores that can diverge. |
| M8 | toctou | State checked at T1 is used at T2 after attacker-influenced change. |
| M9 | implicit-contract | Code relies on an unenforced API, type, docs, or caller contract. |
| M10 | parsing-oracle | Two parsers read the same input differently. |
| M11 | authority-context | Authorization binds context A while execution uses context B. |
| M12 | error-semantic | Components disagree about what an error means. |
| M13 | canonicalization-drift | Validation and sink canonicalize the same value into different objects. |
| M14 | capability-lifetime | Authority outlives the condition that justified it. |
| M15 | policy-composition | Locally safe policies compose into a globally unsafe allow path. |
| P7 | unsafe-deserialization | Powerful decoder consumes attacker-controlled bytes. |
| P8 | cryptographic-misuse | Correct primitive used with unsafe semantics. |
| P9 | sandbox-escape | Sandboxed code reaches host-side capability. |

Conceptual map: P1 invariant, P2 interpretation, P3 temporal, P4 state duplication, P5 fix propagation, P6 error semantic, P7 unsafe deserialization, P8 crypto misuse, P9 sandbox boundary, P10 authority context, P11 policy composition, P12 chain amplification, P13 proof/oracle failure.

Patterns fill seams left uncovered by the BRG pass. They are not a full-surface swarm.
