---
description: Build and execute empirical PoC from the highest-ranked candidate or chain
---

# `/poc` — PoC Building and Execution

Enter the **poc** phase. Build an executable PoC, run it against real target code, capture `poc/run-log.md`, and determine the verdict.

## Input

Use the highest-ranked chain from `analysis/chains.md` when present; otherwise use the top confirmed candidate from `analysis/candidates.md`.

## Required work

1. Select candidate or chain.
2. Build a runnable PoC source file under `poc/`.
3. Execute against real target code, not a mock.
4. Run a positive test that should trigger the oracle.
5. Run a negative control that should not trigger the oracle.
6. Record oracle type: `crash`, `state`, `response`, or `callback`.
7. Write exact run-log path: `poc/run-log.md`.
8. Recheck source anchors.
9. Move state to `POC-READY` only when reproduced.

## Required run-log fields

```text
timestamp
target commit
command executed
environment summary
candidate ID
seam ID
chain ID when applicable
positive test
negative control
oracle: crash|state|response|callback
observed oracle
verdict: VULNERABLE|NOT-REPRODUCIBLE|PASS|EXIT
```

## Output

```text
finding-<id>/poc/
├── poc.<ext>
└── run-log.md
```

## Chain policy

- `VULNERABLE` with specific oracle and negative control -> immediately invoke `/validate`.
- `NOT-REPRODUCIBLE`, nonspecific oracle, or positive/negative controls both triggering -> `/close` as `DEAD-END` with evidence.
- Tooling or infrastructure blocker -> `STOP`. Do not auto-close.
