---
description: Show FLAWLESS state, recent ledger entries, active phase, and next action
---

# `/status` — FLAWLESS Status

Report the current workflow phase, active finding folder, state database summary, recent LEDGER entries, and next required command.

Read from disk first:

```text
pipeline/.phase
pipeline/DISCOVERED/
pipeline/CANDIDATE/
pipeline/VALIDATED/
pipeline/READY-TO-SHIP/
pipeline/SHIPPED/
pipeline/LEDGER.md
pipeline/DEAD-ENDS.md
pipeline/provenance.jsonl
```

Disk is authoritative. Do not infer state from conversation prose.
