---
description: Deterministic ship gate — 11 mechanical checks before commit. No LLM discretion.
---

# `/ship` — Deterministic Ship Gate

Enter the **ship** phase. Stage a validated finding under `pipeline/READY-TO-SHIP/`. Only after the mechanical gate passes does it move to `pipeline/SHIPPED/`.

## The 11 checks

1. `advisory/DISCLOSURE.md` exists and is non-empty.
2. PoC source exists under `poc/`.
3. Exact `poc/run-log.md` exists and is non-empty.
4. `poc/run-log.md` is newer than newest PoC source.
5. Run-log contains a verdict line.
6. Internal anchors resolve.
7. Disclosure contains a pinned 40-character target commit hash.
8. Disclosure contains no internal methodology leakage.
9. Disclosure contains severity or CVSS-equivalent rationale.
10. `FINDING.sha256` exists and is fresh.
11. Run-log names oracle type and documents negative control.

## Required commands before commit

```sh
pipeline/lint/hash-finding-folder.sh pipeline/READY-TO-SHIP/<finding>
pipeline/lint/check-finding-folder.sh pipeline/READY-TO-SHIP/<finding>
```

The PreToolUse ship hook reruns the gate on staged READY-TO-SHIP folders.

## No manual override

If the checks pass, ship. If any check fails, state is `BLOCKED`. Fix the failed artifact and retry. Do not auto-close a blocked finding.
