#!/usr/bin/env bash
# FLAWLESS SubagentStop hook — SAD artifact gate.
# Exit 0 = allow. Exit 2 = block with feedback.
set -euo pipefail
ROOT="${CLAUDE_PROJECT_DIR:-$(pwd)}"
PHASE_FILE="$ROOT/pipeline/.phase"
phase=""
[ -f "$PHASE_FILE" ] && phase="$(tr -d '[:space:]' < "$PHASE_FILE")"
raw="$(cat 2>/dev/null || true)"
find_active() {
  for base in "$ROOT/pipeline/DISCOVERED" "$ROOT/pipeline/CANDIDATE" "$ROOT/pipeline/VALIDATED" "$ROOT/pipeline/READY-TO-SHIP"; do
    [ -d "$base" ] || continue
    find "$base" -mindepth 1 -maxdepth 1 -type d 2>/dev/null | sort | head -1
  done | head -1
}
block(){ echo "[subagent-gate] BLOCKED: $*" >&2; exit 2; }
dir="$(find_active)"
[ -n "$dir" ] || exit 0
sad="$dir/analysis/sad-review.md"
case "$phase" in
  analysis)
    [ -s "$dir/analysis/candidates.md" ] && [ ! -s "$sad" ] && block "analysis/candidates.md exists but analysis/sad-review.md is missing" ;;
  precision)
    [ -s "$dir/analysis/candidates.md" ] && [ ! -s "$sad" ] && block "precision requires SAD review before PoC selection" ;;
  validation)
    [ -s "$dir/validation-report.md" ] && ! grep -qi 'Validation Outcome' "$sad" 2>/dev/null && block "validation outcome lacks SAD review" ;;
  ship)
    ! grep -qi 'Ship Readiness' "$sad" 2>/dev/null && block "ship phase requires SAD Ship Readiness review" ;;
esac
exit 0
