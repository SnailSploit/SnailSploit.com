#!/usr/bin/env bash
# FLAWLESS PostToolUse provenance logger. Hash-only, no full payload.
set -euo pipefail
ROOT="${CLAUDE_PROJECT_DIR:-$(pwd)}"
LOG_FILE="$ROOT/pipeline/provenance.jsonl"
PHASE_FILE="$ROOT/pipeline/.phase"
raw="$(cat 2>/dev/null || true)"
phase=""
[ -f "$PHASE_FILE" ] && phase="$(tr -d '[:space:]' < "$PHASE_FILE")"
tool="unknown"; status="observed"
if command -v jq >/dev/null 2>&1 && [ -n "$raw" ]; then
  tool="$(printf '%s' "$raw" | jq -r '.tool_name // "unknown"' 2>/dev/null || echo unknown)"
  status="$(printf '%s' "$raw" | jq -r '.tool_status // "observed"' 2>/dev/null || echo observed)"
fi
timestamp="$(date -u +"%Y-%m-%dT%H:%M:%SZ")"
session_id="${FLAWLESS_SESSION_ID:-${CLAUDE_SESSION_ID:-$(hostname)-$$}}"
input_hash="$(printf '%s' "$raw" | sha256sum | awk '{print $1}' | cut -c1-16)"
mkdir -p "$(dirname "$LOG_FILE")"
if command -v jq >/dev/null 2>&1; then
  jq -n --arg timestamp "$timestamp" --arg session_id "$session_id" --arg phase "$phase" --arg tool "$tool" --arg input_hash "$input_hash" --arg cwd "$(pwd)" --arg status "$status" '{timestamp:$timestamp,session_id:$session_id,phase:$phase,tool:$tool,input_hash:$input_hash,cwd:$cwd,status:$status}' >> "$LOG_FILE"
else
  printf '{"timestamp":"%s","session_id":"%s","phase":"%s","tool":"%s","input_hash":"%s","cwd":"%s","status":"%s"}\n' "$timestamp" "$session_id" "$phase" "$tool" "$input_hash" "$(pwd)" "$status" >> "$LOG_FILE"
fi
